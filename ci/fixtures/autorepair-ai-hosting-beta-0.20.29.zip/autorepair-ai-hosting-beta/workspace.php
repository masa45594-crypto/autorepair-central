<?php
if(!defined('ABSPATH')){exit;}
final class AAIHB_Workspace {
    public static function hero($screen) {
        $map=[
            'ops'=>['TAKE ACTION',__('次の対応を、迷わず。', 'autorepair-ai-hosting-beta'),__('担当・期限・状況をそろえて、対応漏れを減らしましょう。', 'autorepair-ai-hosting-beta'),'01',__('案件を選ぶ → 担当を決める → 対応内容を残す', 'autorepair-ai-hosting-beta')],
            'value'=>['MEASURE YOUR IMPACT',__('減らせた時間を、見える価値に。', 'autorepair-ai-hosting-beta'),__('使う前と使った後の作業時間を比べます。まずは1件の記録から。', 'autorepair-ai-hosting-beta'),'02',__('作業時間を記録 → 従来の時間と比較 → 月次結果を確認', 'autorepair-ai-hosting-beta')],
            'connect'=>['CONNECT YOUR SITES',__('つなぐ準備は、ここから。', 'autorepair-ai-hosting-beta'),__('この画面は「まとめて管理する側」と「診断される側」で使います。', 'autorepair-ai-hosting-beta'),'03',__('対象サイトで接続情報を発行 → 管理側に登録 → 診断', 'autorepair-ai-hosting-beta')],
        ];$d=$map[$screen];
        echo '<header class="aaihb-work-hero work-'.$screen.'"><div><p class="aaihb-eyebrow">'.$d[0].'</p><h1>'.esc_html($d[1]).'</h1><p>'.esc_html($d[2]).'</p><div class="aaihb-actions">';
        if($screen==='ops'){foreach([__('自分の担当を見る', 'autorepair-ai-hosting-beta')=>'&owner='.get_current_user_id(),__('期限超過を見る', 'autorepair-ai-hosting-beta')=>'&overdue=1'] as $label=>$query){echo '<a class="aaihb-primary" href="'.esc_url(admin_url('admin.php?page=aaihb-ops'.$query)).'">'.esc_html($label).' →</a>';}}
        elseif($screen==='value'){echo __('<a class="aaihb-primary" data-open="value-work" href="#value-work">＋ 作業時間を記録する</a><a class="aaihb-ghost" data-open="value-report" href="#value-report">今月の結果を見る</a>', 'autorepair-ai-hosting-beta');}
        else {echo __('<a class="aaihb-primary" data-open="connect-register" href="#connect-register">管理する側：サイトを追加</a><a class="aaihb-ghost" data-open="connect-agent" href="#connect-agent">診断される側：接続情報を発行</a>', 'autorepair-ai-hosting-beta');}
        echo '</div><p class="aaihb-work-path">'.esc_html($d[4]).'</p></div><div class="aaihb-work-number" aria-hidden="true">'.$d[3].'</div></header>';
    }
    public static function metrics($metrics) {
        echo __('<section class="aaihb-metric-grid" aria-label="状況のまとめ">', 'autorepair-ai-hosting-beta');
        foreach($metrics as $label=>$v){$tag=isset($v[2])?'a':'div';echo '<'.$tag.' class="aaihb-metric"'.(isset($v[2])?' href="'.esc_url($v[2]).'"':'').'><span>'.esc_html($label).'</span><strong>'.esc_html($v[0]).'</strong><small>'.esc_html($v[1]).'</small></'.$tag.'>';}
        echo '</section>';
    }
}
