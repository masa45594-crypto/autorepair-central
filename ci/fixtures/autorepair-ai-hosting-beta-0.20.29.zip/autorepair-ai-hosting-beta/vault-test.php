<?php
if(!defined('ABSPATH'))exit;
final class AAIHB_RestoreTest {
 const CHECKS=['files','database','homepage','wordpress','cleanup'];
 public static function record($dir,$data){$json=json_encode($data,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);AAIHB_VaultIO::write($dir.'/restore-test.json',$json);AAIHB_VaultIO::write($dir.'/restore-test.mac',hash_hmac('sha256',$json,AAIHB_VaultIO::key()));}
 public static function result($dir,$manifest){
  if(!is_file($dir.'/restore-test.json'))return ['status'=>'untested'];
  try{$json=file_get_contents($dir.'/restore-test.json');$mac=@file_get_contents($dir.'/restore-test.mac');if(!is_string($mac)||!hash_equals(hash_hmac('sha256',$json,AAIHB_VaultIO::key()),$mac))return ['status'=>'invalid'];$r=json_decode($json,true,512,JSON_THROW_ON_ERROR);
   if(($r['source']??'')!==hash_file('sha256',$dir.'/manifest.json')||($r['id']??'')!==$manifest['id'])return ['status'=>'invalid'];
   if(($r['status']??'')==='passed')foreach(self::CHECKS as $check)if(($r['checks'][$check]??false)!==true)return ['status'=>'invalid'];
   return $r;
  }catch(Throwable $e){return ['status'=>'invalid'];}
 }
 public static function accept($raw,$nonce){
  $r=json_decode($raw,true);if(!is_array($r)||($r['nonce']??'')!==$nonce||!in_array($r['status']??'', ['passed','failed','unavailable'],true))throw new RuntimeException(__('テスト結果を認証できません。', 'autorepair-ai-hosting-beta'));
  if($r['status']==='passed')foreach(self::CHECKS as $c)if(($r['checks'][$c]??false)!==true)throw new RuntimeException(__('必須確認が不足しているため合格にできません。', 'autorepair-ai-hosting-beta'));
  // Never persist subprocess output, credentials, page bodies or arbitrary errors.
  return ['status'=>$r['status'],'checks'=>array_intersect_key($r['checks']??[],array_flip(self::CHECKS)),'stage'=>preg_replace('/[^a-z_]/','',substr($r['stage']??'unknown',0,60)),'failure_class'=>preg_replace('/[^a-z_]/','',substr($r['failure_class']??'',0,40))];
 }
 public static function run($id){
  [$dir,$m]=AAIHB_VaultIO::point($id);if($m['kind']!=='full')throw new RuntimeException(__('サイト全体の保存ポイントを指定してください。', 'autorepair-ai-hosting-beta'));
 $lock=AAIHB_VaultIO::lock();$r=['id'=>$id,'source'=>hash_file('sha256',$dir.'/manifest.json'),'at'=>gmdate('c'),'status'=>'running','checks'=>[],'resources'=>'aaihb-test-'.bin2hex(random_bytes(8))];
  try{self::record($dir,$r);if(class_exists('AAIHB_RecoveryEvidence'))AAIHB_RecoveryEvidence::event('recovery_test_started',$id);if(!function_exists('proc_open'))throw new RuntimeException(__('proc_openが利用できません。', 'autorepair-ai-hosting-beta'));
   $nonce=bin2hex(random_bytes(24));$command=['python3',__DIR__.'/restore-test/runner.py'];
   $pipes=[];$process=proc_open($command,[0=>['pipe','r'],1=>['pipe','w'],2=>['file',$dir.'/runner-stderr.log','a']],$pipes);
   if(!is_resource($process))throw new RuntimeException(__('テスト実行環境を起動できません。', 'autorepair-ai-hosting-beta'));
   $input=json_encode(['dir'=>$dir,'manifest'=>$m,'nonce'=>$nonce,'resources'=>$r['resources']],JSON_THROW_ON_ERROR);$written=fwrite($pipes[0],$input);fclose($pipes[0]);$raw=stream_get_contents($pipes[1],1048576);fclose($pipes[1]);$exit=proc_close($process);
   if($written!==strlen($input))throw new RuntimeException(__('テスト入力の転送が完了しませんでした。', 'autorepair-ai-hosting-beta'));$result=self::accept($raw,$nonce);if($exit!==0&&$result['status']==='passed')throw new RuntimeException(__('実行結果が不整合です。', 'autorepair-ai-hosting-beta'));$r=array_merge($r,$result);$r['finished_at']=gmdate('c');self::record($dir,$r);if(class_exists('AAIHB_RecoveryEvidence'))AAIHB_RecoveryEvidence::event($r['status']==='passed'?'recovery_test_passed':'recovery_test_failed',$id);return $r;
  }catch(Throwable $e){$r['status']='failed';$r['stage']='runner';$r['finished_at']=gmdate('c');self::record($dir,$r);if(class_exists('AAIHB_RecoveryEvidence'))AAIHB_RecoveryEvidence::event('recovery_test_failed',$id);throw $e;}
  finally{AAIHB_VaultIO::unlock($lock);}
 }
 public static function label($r){return ['untested'=>__('保存成功／復元テスト未実行', 'autorepair-ai-hosting-beta'),'running'=>__('保存成功／復元テスト実行中・中断時は未完了', 'autorepair-ai-hosting-beta'),'passed'=>__('復元テスト合格（隔離環境）', 'autorepair-ai-hosting-beta'),'failed'=>__('保存成功／復元テスト不合格', 'autorepair-ai-hosting-beta'),'unavailable'=>__('保存成功／テスト環境未準備', 'autorepair-ai-hosting-beta'),'invalid'=>__('保存成功／テスト記録を確認できません', 'autorepair-ai-hosting-beta')][$r['status']??'invalid']??__('判定不明', 'autorepair-ai-hosting-beta');}
 public static function stage_label($stage){return ['preflight'=>__('実行前の確認', 'autorepair-ai-hosting-beta'),'files'=>__('バックアップのファイル照合', 'autorepair-ai-hosting-beta'),'isolation'=>__('隔離環境の準備', 'autorepair-ai-hosting-beta'),'database_start'=>__('検証用DBの起動', 'autorepair-ai-hosting-beta'),'database'=>__('DBの復元・照合', 'autorepair-ai-hosting-beta'),'homepage'=>__('トップページとWordPress起動の確認', 'autorepair-ai-hosting-beta'),'cleanup'=>__('検証環境の後片付け', 'autorepair-ai-hosting-beta'),'complete'=>__('すべての確認完了', 'autorepair-ai-hosting-beta'),'runner'=>__('テスト実行環境の起動', 'autorepair-ai-hosting-beta'),'input'=>__('テスト入力の確認', 'autorepair-ai-hosting-beta')][''.$stage]??__('確認段階を特定できません', 'autorepair-ai-hosting-beta');}
 public static function failure_label($failure){return ['php_parse'=>__('復元後のPHP構文エラーの可能性', 'autorepair-ai-hosting-beta'),'php_syntax'=>__('復元後のPHP構文エラーの可能性', 'autorepair-ai-hosting-beta'),'php_fatal'=>__('復元後のPHP致命的エラーの可能性', 'autorepair-ai-hosting-beta'),'memory'=>__('PHPメモリ不足の可能性', 'autorepair-ai-hosting-beta'),'connection'=>__('検証環境の接続失敗', 'autorepair-ai-hosting-beta'),'timeout'=>__('検証処理の時間切れ', 'autorepair-ai-hosting-beta'),'other'=>__('詳細を公開せず管理者が追加調査する必要があります。', 'autorepair-ai-hosting-beta')][''.$failure]??__('詳細を公開せず管理者が追加調査する必要があります。', 'autorepair-ai-hosting-beta');}
 public static function next_action($failure,$stage){$f=''.$failure;$s=''.$stage;if(in_array($f,['php_parse','php_syntax','php_fatal'],true))return __('次にすること：更新直後のプラグイン・テーマを確認し、緊急モードから保存ポイントを選んでください。', 'autorepair-ai-hosting-beta');if($f==='memory')return __('次にすること：PHPメモリ上限とバックアップ容量を確認してください。', 'autorepair-ai-hosting-beta');if($f==='connection'||in_array($s,['database_start','database'],true))return __('次にすること：検証用DBの起動状態と接続設定を確認してください。', 'autorepair-ai-hosting-beta');if($f==='timeout')return __('次にすること：サーバーの実行時間・空き容量を確認して、時間帯を変えて再実行してください。', 'autorepair-ai-hosting-beta');return __('次にすること：保管先の権限・容量・検証環境を確認してください。', 'autorepair-ai-hosting-beta');}
 public static function checks_html($r){$labels=['files'=>__('バックアップのファイル照合', 'autorepair-ai-hosting-beta'),'database'=>__('DBの復元・照合', 'autorepair-ai-hosting-beta'),'homepage'=>__('トップページ HTTP 200 と HTML', 'autorepair-ai-hosting-beta'),'wordpress'=>__('WordPress起動の証明', 'autorepair-ai-hosting-beta'),'cleanup'=>__('検証環境の後片付け', 'autorepair-ai-hosting-beta')];$html='<ul class="aaihb-restore-checks">';foreach($labels as $id=>$label){$ok=($r['checks'][$id]??false)===true;$html.='<li class="'.($ok?'is-ok':'is-pending').'">'.($ok?__('確認済み', 'autorepair-ai-hosting-beta'):__('未確認', 'autorepair-ai-hosting-beta')).'：'.esc_html($label).'</li>';}$html.='</ul>';return $html;}
}
