<?php
if(!defined('ABSPATH'))exit;
final class AAIHB_RestoreTest {
 const CHECKS=['files','database','homepage','wordpress','cleanup'];
 public static function record($dir,$data){$json=json_encode($data,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);AAIHB_VaultIO::write($dir.'/restore-test.json',$json);AAIHB_VaultIO::write($dir.'/restore-test.mac',hash_hmac('sha256',$json,AAIHB_VaultIO::key()));}
 public static function result($dir,$manifest){
  if(!is_file($dir.'/restore-test.json'))return ['status'=>'untested'];
  try{$json=file_get_contents($dir.'/restore-test.json');$mac=@file_get_contents($dir.'/restore-test.mac');if(!is_string($mac)||!hash_equals(hash_hmac('sha256',$json,AAIHB_VaultIO::key()),$mac))return ['status'=>'invalid'];$r=json_decode($json,true,512,JSON_THROW_ON_ERROR);
   if(($r['source']??'')!==hash_file('sha256',$dir.'/manifest.json')||($r['id']??'')!==$manifest['id'])return ['status'=>'invalid'];
   if(($r['status']??'')==='passed')foreach(self::CHECKS as $check)if(($r['checks'][$check]??false)!==true)return ['status'=>'invalid'];
   return $r;
  }catch(Throwable $e){return ['status'=>'invalid'];}
 }
 public static function accept($raw,$nonce){
  $r=json_decode($raw,true);if(!is_array($r)||($r['nonce']??'')!==$nonce||!in_array($r['status']??'', ['passed','failed','unavailable'],true))throw new RuntimeException('テスト結果を認証できません。');
  if($r['status']==='passed')foreach(self::CHECKS as $c)if(($r['checks'][$c]??false)!==true)throw new RuntimeException('必須確認が不足しているため合格にできません。');
  // Never persist subprocess output, credentials, page bodies or arbitrary errors.
  return ['status'=>$r['status'],'checks'=>array_intersect_key($r['checks']??[],array_flip(self::CHECKS)),'stage'=>preg_replace('/[^a-z_]/','',substr($r['stage']??'unknown',0,60))];
 }
 public static function run($id){
  [$dir,$m]=AAIHB_VaultIO::point($id);if($m['kind']!=='full')throw new RuntimeException('サイト全体の保存ポイントを指定してください。');
  $lock=AAIHB_VaultIO::lock();$r=['id'=>$id,'source'=>hash_file('sha256',$dir.'/manifest.json'),'at'=>gmdate('c'),'status'=>'running','checks'=>[],'resources'=>'aaihb-test-'.bin2hex(random_bytes(8))];
  try{self::record($dir,$r);if(!function_exists('proc_open'))throw new RuntimeException('proc_openが利用できません。');
   $nonce=bin2hex(random_bytes(24));$command=['python3',__DIR__.'/restore-test/runner.py'];
   $pipes=[];$process=proc_open($command,[0=>['pipe','r'],1=>['pipe','w'],2=>['file',$dir.'/runner-stderr.log','a']],$pipes);
   if(!is_resource($process))throw new RuntimeException('テスト実行環境を起動できません。');
   $input=json_encode(['dir'=>$dir,'manifest'=>$m,'nonce'=>$nonce,'resources'=>$r['resources']],JSON_THROW_ON_ERROR);$written=fwrite($pipes[0],$input);fclose($pipes[0]);$raw=stream_get_contents($pipes[1],1048576);fclose($pipes[1]);$exit=proc_close($process);
   if($written!==strlen($input))throw new RuntimeException('テスト入力の転送が完了しませんでした。');$result=self::accept($raw,$nonce);if($exit!==0&&$result['status']==='passed')throw new RuntimeException('実行結果が不整合です。');$r=array_merge($r,$result);$r['finished_at']=gmdate('c');self::record($dir,$r);return $r;
  }catch(Throwable $e){$r['status']='failed';$r['stage']='runner';$r['finished_at']=gmdate('c');self::record($dir,$r);throw $e;}
  finally{AAIHB_VaultIO::unlock($lock);}
 }
 public static function label($r){return ['untested'=>'保存成功／復元テスト未実行','running'=>'保存成功／復元テスト実行中・中断時は未完了','passed'=>'復元テスト合格（隔離環境）','failed'=>'保存成功／復元テスト不合格','unavailable'=>'保存成功／テスト環境未準備','invalid'=>'保存成功／テスト記録を確認できません'][$r['status']??'invalid']??'判定不明';}
}
