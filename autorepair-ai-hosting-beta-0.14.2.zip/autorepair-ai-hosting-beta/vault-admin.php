<?php
if(!defined('ABSPATH'))exit;
final class AAIHB_VaultAdmin {
 public static function boot(){
  add_action('admin_menu',function(){add_submenu_page('aaihb-home','バックアップ・復元','バックアップ・復元','manage_options','aaihb-vault',[__CLASS__,'page']);});
  add_action('aaihb_local_daily',function(){if(!get_option('aaihb_local_daily_enabled'))return;$r=AAIHB_Beta::agent_scan();if(!is_wp_error($r))update_option('aaihb_local_report',$r->get_data(),false);});
  add_action('admin_post_aaihb_vault',[__CLASS__,'save']);
 }
 private static function form($op,$label,$id=''){
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="aaihb_vault"><input type="hidden" name="op" value="'.esc_attr($op).'"><input type="hidden" name="id" value="'.esc_attr($id).'">';wp_nonce_field('aaihb_vault');
  if($op==='restore')echo '<label><input type="checkbox" name="ack" value="1" required> このサイトの対象プラグインのファイルを戻す（DBは戻りません）</label> ';
  submit_button($label,'secondary','submit',false);echo '</form>';
 }
 public static function save(){
  if(!current_user_can('manage_options'))wp_die('権限がありません。',403);check_admin_referer('aaihb_vault');
  try{$op=sanitize_key($_POST['op']??'');$id=sanitize_text_field(wp_unslash($_POST['id']??''));
   if($op==='enable'){AAIHB_VaultIO::root();update_option('aaihb_guard_enabled',true,false);$message='更新前保護を有効にしました。非対応プラグインの更新は停止します。';}
   elseif($op==='disable'){update_option('aaihb_guard_enabled',false,false);$message='更新前保護を停止しました。保存済みデータは残ります。';}
   elseif($op==='snapshot'){$message='保存しました：'.AAIHB_PluginGuard::snapshot($id);}
   elseif($op==='restore'){if(empty($_POST['ack']))throw new RuntimeException('復元対象の確認が必要です。');$message='ファイルを戻しました。直前のファイル退避ID：'.AAIHB_PluginGuard::restore($id);}
   elseif($op==='loader'){$v=AAIHB_VaultIO::root();foreach(['vault-command.php','vault-io.php','vault-db.php','vault-full.php','vault-test.php'] as $f)AAIHB_VaultIO::write($v.'/'.$f,file_get_contents(__DIR__.'/'.$f));$helper=$v.'/restore-test';if(!is_dir($helper)&&!mkdir($helper,0700))throw new RuntimeException('検証ツールの配置先を作成できません。');foreach(['runner.py','import.php','Dockerfile'] as $f)AAIHB_VaultIO::write($helper.'/'.$f,file_get_contents(__DIR__.'/restore-test/'.$f));$message='公開領域外に復元・検証コマンドを保存しました。';}
   elseif($op==='daily'){wp_clear_scheduled_hook('aaihb_local_daily');$ok=wp_schedule_event(time()+60,'daily','aaihb_local_daily',[],true);if(is_wp_error($ok)||!$ok)throw new RuntimeException('予約を作成できません。');update_option('aaihb_local_daily_enabled',true,false);$message='このサイトの毎日診断を予約し直しました。WP-Cronの実行状況に依存します。';}
   elseif($op==='daily_off'){update_option('aaihb_local_daily_enabled',false,false);wp_clear_scheduled_hook('aaihb_local_daily');$message='毎日診断を停止しました。';}
   elseif($op==='cache'){wp_cache_flush();$message='オブジェクトキャッシュの削除を要求しました。CDNやページキャッシュは対象外です。';}
   elseif($op==='updates'){require_once ABSPATH.'wp-admin/includes/update.php';wp_clean_update_cache();$message='更新情報キャッシュを削除しました。更新画面で再取得してください。';}
   else throw new RuntimeException('不明な操作です。');
  }catch(Throwable $e){$message='処理を完了できません：'.$e->getMessage();}
  set_transient('aaihb_vault_message_'.get_current_user_id(),$message,120);wp_safe_redirect(admin_url('admin.php?page=aaihb-vault'));exit;
 }
 public static function page(){
  if(!current_user_can('manage_options'))return;
  echo '<div class="wrap aaihb-app">';AAIHB_Dashboard::nav('aaihb-vault');
  echo '<div class="aaihb-vault-hero"><span>RECOVERY VAULT · 0.14.2</span><h1>更新の前に、戻れる準備を。</h1><p>プラグインの退避から、サイト全体の復元まで。保存範囲を選んで操作します。</p></div>';
  $message=get_transient('aaihb_vault_message_'.get_current_user_id());if($message){echo '<div class="notice notice-info"><p>'.esc_html($message).'</p></div>';delete_transient('aaihb_vault_message_'.get_current_user_id());}
  $ready=false;try{$v=AAIHB_VaultIO::root();$ready=true;}catch(Throwable $e){echo '<section class="aaihb-vault-card"><h2>最初に：バックアップの保管場所を設定</h2><p>'.esc_html($e->getMessage()).'</p><p>公開フォルダーの外に専用ディレクトリ（権限0700）を作り、wp-config.phpに2つの実パスを指定してください。パスはサーバーごとに異なります。</p><pre>define(\'AAIHB_VAULT_DIR\', \'/private/autorepair-vault\');<br>define(\'AAIHB_PUBLIC_ROOT\', \'/var/www/public\');</pre><p>サーバー設定が必要です。設定後、このページを再表示してください。</p></section>';}
  echo '<div class="aaihb-vault-grid"><section class="aaihb-vault-card"><h2>01 · 更新失敗に備える</h2><p>更新前のプラグインファイルを保存。単独更新の前がHTTP 2xxで、直後に2回続けて5xxになった場合にファイルを戻します。</p><strong>'.(get_option('aaihb_guard_enabled')?'保護：有効':'保護：停止中').'</strong><p>DBの変更は戻りません。一括更新は保存のみ。単一ファイル形式とHosting Beta自身は対象外で、有効中はその更新を停止します。</p>';
  if($ready)self::form(get_option('aaihb_guard_enabled')?'disable':'enable',get_option('aaihb_guard_enabled')?'保護を停止':'更新前保護を有効にする');
  $last=get_option('aaihb_guard_last',[]);if($last)echo '<p>直近：'.esc_html($last['plugin'].' — '.$last['message']).'</p>';
  echo '</section><section class="aaihb-vault-card"><h2>02 · サイト全体を保存・復元</h2><p>WordPress本体・プラグイン・テーマ・画像・wp-config.phpと、同じ接頭辞のDBテーブルを保存します。</p><p><strong>同じサイトへの復元専用／WP-CLIで実行</strong><br>書き込みを止めてから実行してください。全体復元の前には、現状のバックアップも作ります。</p><p>MySQL 8.x／InnoDB・単一サイト・通常のフォルダー構成のみ。5万項目／ファイル合計2GiB／DB合計2GiBまで。MySQLでの通し復元は未検証のため、まず複製環境で確認してください。</p>';
  if($ready){self::form('loader','復元コマンドを保管場所へ配置');echo '<pre>'.esc_html('wp --skip-plugins --skip-themes --require='.$v.'/vault-command.php aaihb-vault backup --ack-quiesced').'</pre><p>復元コマンドと停止・復旧手順は同梱の VAULT-GUIDE-JA.md を参照してください。</p>';}
  echo '</section></div><section class="aaihb-vault-card"><h2>03 · 手動でプラグインを保存する</h2>';
  if($ready){require_once ABSPATH.'wp-admin/includes/plugin.php';foreach(get_plugins() as $slug=>$data){if(strpos($slug,'/')===false||explode('/',$slug)[0]===basename(__DIR__))continue;echo '<p><strong>'.esc_html($data['Name']).'</strong></p>';self::form('snapshot','このプラグインを保存',$slug);}}
  echo '</section><section class="aaihb-vault-card"><h2>保存済みポイント</h2><p>署名と内容を検証できたポイントを表示します。未完成・破損した保存は復元候補にしません。直前の退避データは保管領域に残ります。</p>';
  $count=0;if($ready){$dirs=glob($v.'/[0-9]*',GLOB_ONLYDIR)?:[];rsort($dirs);foreach(array_slice($dirs,0,100) as $d){try{[$path,$point]=AAIHB_VaultIO::point(basename($d));}catch(Throwable $e){continue;}$count++;echo '<hr><p><strong>'.esc_html($point['kind']==='full'?'サイト全体':$point['plugin']).'</strong><br>'.esc_html($point['id']).'</p>';if($point['kind']==='plugin')self::form('restore','この時点のファイルに戻す',$point['id']);else {$test=AAIHB_RestoreTest::result($path,$point);echo '<p><strong>'.esc_html(AAIHB_RestoreTest::label($test)).'</strong></p>';if(isset($test['at']))echo '<p>開始（UTC）：'.esc_html($test['at']).' ／ 確認段階：'.esc_html($test['stage']??'準備中').'</p>';echo '<p>復元テストは本番を変更せず、隔離した複製環境で実行します。初回はDocker環境の設定が必要です。</p><pre>'.esc_html('wp --skip-plugins --skip-themes --require='.$v.'/vault-command.php aaihb-vault verify '.$point['id']).'</pre><p>合格範囲：ファイル照合・DB内容照合・トップページHTTP 200とHTML・WordPress起動・後片付け。MUプラグイン・DB/キャッシュdrop-inは無効化し、接続設定は検証用に置き換えます。購入やフォーム送信、外部連携、本番への復元は確認していません。詳しくは RESTORE-TEST-JA.md。</p>';}}}
  if(!$count)echo '<p>まだ検証済みの保存ポイントはありません。</p>';
  echo '</section><section class="aaihb-vault-card"><h2>補助メンテナンス</h2><p>キャッシュと更新情報の再取得を支援します。これらは削除後に再生成される情報で、元に戻す操作はありません。</p>';echo '<p>このサイトの毎日診断：'.(get_option('aaihb_local_daily_enabled')?'有効':'停止中').'</p>';self::form('daily','毎日診断を有効化・予約し直す');if(get_option('aaihb_local_daily_enabled'))self::form('daily_off','毎日診断を停止');self::form('cache','オブジェクトキャッシュを削除');self::form('updates','更新情報を取り直す');echo '</section></div>';
 }
}
