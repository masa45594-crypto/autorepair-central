# 0.14.1 検証記録

復元テスト機能を実装しましたが、この開発環境にはDocker Engineがなく、実Docker・実MySQL・実WordPressを組み合わせた通し試験は未実行です。顧客バックアップの復元合格実績を示すものではありません。

- Python実行制御：10テスト合格。Docker応答を模擬。必須確認が揃う場合のみ合格、DB/HTTP/WordPress起動の確認失敗、後片付け失敗、イメージ・Docker欠落、破損、パス逸脱を確認。ファイル展開とコピーは実際の一時ファイルを使用。
- WordPress Playground 6.8 / PHP 8.3：15項目合格。未検証・実行中・環境未準備・合格の区別、必須項目欠落の拒否、nonce、署名、保存元の変更による結果無効化、管理画面表示を確認。合格データは判定処理を試すための人工的なテスト入力です。
- Dockerのない実環境でrunnerを起動し、unavailableとなり、files/database/homepage/wordpressをtrueにしないことを確認。
- PHP構文：25ファイルを構文パーサーで確認（本体23＋追加インポーター・テスト）。
- Chromium：管理画面HTMLの1440px/390px表示、実行時エラー・横はみ出しなし。画像はテストデータによる画面見本。

未検証：実Docker起動、MySQL 8.4の実インポート、コンテナー間Unixソケット、実バックアップからのWordPress起動、プロセス強制終了、実運用容量・処理時間、WordPress/PHPの他バージョン。

0.13.0由来の検証記録はvalidationの旧ファイルに残しますが、0.14.1ですべて再実施した意味ではありません。今回の生の結果はrestore-runner-tests.txtとrestore-test-php.txtです。
