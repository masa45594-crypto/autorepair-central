# 0.14.1 差分

隔離PHPをCLIと同じUID/GIDで実行する修正を追加しました。実Docker/MySQLの通し検証は未実施です。同梱のGitHub Actions検証パックで実行してください。購入・独自フォームの試験は対象設定が必要です。

# AutoRepair AI Hosting Beta 0.14.1

復元テストの自動実行・判定表示を追加しました。最初に **RESTORE-TEST-JA.md** をお読みください。実Docker/MySQLでの通し実行は未検証です。

# AutoRepair AI Hosting Beta 0.13.0

AutoRepair AI本体が不要な独立プラグインです。

バックアップ・復元と更新前保護を追加しました。新機能の範囲、サーバー設定、WP-CLIの手順、未検証事項は **VAULT-GUIDE-JA.md** を先にお読みください。サイト全体復元は実MySQLでの通し検証が残る試作です。

旧機能の説明を以下に残します。過去版の「バックアップ未実装」は0.12.0以前の説明です。

---

# Hosting Beta 0.12.0 — 限定修復・変更復元版

AutoRepair AI本体は不要です。独立診断に加え、URLルール再生成・古い標準メンテナンスファイル解除・その変更の復元を内蔵しました。サイト全体のバックアップ・復元ではありません。START-HERE-JA.mdを参照してください。
