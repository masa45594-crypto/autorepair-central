<?php
/**
 * Uninstall routine for AutoRepair AI Hosting Beta.
 *
 * Runs only when the plugin is deleted from the Plugins screen (WordPress
 * defines WP_UNINSTALL_PLUGIN in that request). It removes what this plugin
 * stored and nothing else:
 *
 *   - every option / transient whose name starts with "aaihb_"
 *   - the plugin's own table {prefix}aaihb_sites
 *   - the plugin's scheduled events
 *   - on multisite, the same cleanup for every site on the network, plus the
 *     network-wide options
 *
 * Deactivating the plugin does not run this file; data is kept until deletion.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }

if (!function_exists('aaihb_uninstall_site')) {
	/** Clean up one site (the current blog). */
	function aaihb_uninstall_site() {
		global $wpdb;

		$like_patterns = [
			$wpdb->esc_like('aaihb_') . '%',
			$wpdb->esc_like('_transient_aaihb_') . '%',
			$wpdb->esc_like('_transient_timeout_aaihb_') . '%',
			$wpdb->esc_like('_site_transient_aaihb_') . '%',
			$wpdb->esc_like('_site_transient_timeout_aaihb_') . '%',
		];
		foreach ($like_patterns as $like) {
			$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like));
		}

		$table = $wpdb->prefix . 'aaihb_sites';
		$wpdb->query("DROP TABLE IF EXISTS `{$table}`");

		foreach ([
			'aaihb_value_tick',
			'aaihb_central_tick',
			'aaihb_central_drain',
			'aaihb_recovery_tick',
			'aaihb_local_daily',
			'aaihb_fleet_tick',
			'aaihb_rehearsal_weekly',
		] as $hook) {
			wp_clear_scheduled_hook($hook);
		}
	}
}

if (is_multisite()) {
	$blog_ids = get_sites(['fields' => 'ids', 'number' => 0]);
	if (is_array($blog_ids)) {
		foreach ($blog_ids as $blog_id) {
			switch_to_blog((int) $blog_id);
			aaihb_uninstall_site();
			restore_current_blog();
		}
	}
	global $wpdb;
	$like = $wpdb->esc_like('aaihb_') . '%';
	$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s", $like));
} else {
	aaihb_uninstall_site();
}
