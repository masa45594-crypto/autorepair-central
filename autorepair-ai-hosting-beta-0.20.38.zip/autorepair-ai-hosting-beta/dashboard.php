<?php
if (!defined('ABSPATH')) { exit; }
final class AAIHB_Dashboard {
    public static function boot() {
        add_action('admin_menu', [__CLASS__, 'menu'], 9);
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);
    }
    public static function menu() {
        add_menu_page(__('AutoRepair AI 運用', 'autorepair-ai-hosting-beta'), __('AI運用ホーム', 'autorepair-ai-hosting-beta'), AAIHB_Operations::CAP, 'aaihb-home', [__CLASS__, 'page'], 'dashicons-shield-alt', 30);
    }
    public static function assets() {
        $page = isset($_GET['page']) && is_string($_GET['page']) ? sanitize_key($_GET['page']) : '';
        if (!in_array($page, ['aaihb-home','aaihb-ops','aaihb','aaihb-value','aaihb-fleet','aaihb-history','aaihb-notify','aaihb-partner','aaihb-start','aaihb-buy','aaihb-help','aaihb-license','aaihb-recovery','aaihb-vault','aaihb-protect','aaihb-respond','aaihb-grow','aaihb-emergency','aaihb-verification','aaihb-get-started'],true)) {return;}
        wp_enqueue_style('aaihb-dashboard', plugins_url('dashboard.css',__FILE__), [], AAIHB_VERSION);
        wp_enqueue_style('aaihb-workspace',plugins_url('workspace.css',__FILE__),['aaihb-dashboard'],AAIHB_VERSION);
        wp_enqueue_script('aaihb-workspace',plugins_url('workspace.js',__FILE__),[],AAIHB_VERSION,true);
        if(in_array($page,['aaihb-start','aaihb-buy','aaihb-help','aaihb-license','aaihb-recovery','aaihb-protect','aaihb-respond','aaihb-grow','aaihb-emergency','aaihb-verification','aaihb-get-started'],true)){wp_enqueue_style('aaihb-selfserve',plugins_url('selfserve.css',__FILE__),['aaihb-dashboard'],AAIHB_VERSION);wp_enqueue_script('aaihb-selfserve',plugins_url('selfserve.js',__FILE__),[],AAIHB_VERSION,true);
        wp_localize_script('aaihb-selfserve', 'aaihbSelfserveL10n', ['copied'=>__('コピーしました。貼り付け先へ進んでください。','autorepair-ai-hosting-beta'), 'copyFailed'=>__('自動コピーできませんでした。選択された文字をコピーしてください。','autorepair-ai-hosting-beta'), 'preview'=>__('接続予定：','autorepair-ai-hosting-beta'), 'previewSuffix'=>__('）／登録時に接続を検証します。','autorepair-ai-hosting-beta'), 'invalid'=>__('情報を読み取れません。対象サイトでコピーした内容をそのまま貼り付けてください。','autorepair-ai-hosting-beta'), 'processing'=>__('処理中…','autorepair-ai-hosting-beta'), 'found'=>__('件の案内があります','autorepair-ai-hosting-beta'), 'none'=>__('該当する案内がありません。短い言葉で検索するか、下の確認用メモをご利用ください。','autorepair-ai-hosting-beta')]);}
        if ($page === 'aaihb-home') {
            wp_enqueue_script('aaihb-dashboard',plugins_url('dashboard.js',__FILE__),[],AAIHB_VERSION,true);
            wp_localize_script('aaihb-dashboard','AAIHB_HOME',['url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('aaihb_scan'),'canScan'=>current_user_can('manage_options')]);
        }
        if ($page === 'aaihb-value') {
            wp_enqueue_script('aaihb-timer',plugins_url('timer.js',__FILE__),[],AAIHB_VERSION,true);
        }
        if ($page === 'aaihb') {
            wp_enqueue_script('aaihb-connect',plugins_url('connect.js',__FILE__),['aaihb-workspace'],AAIHB_VERSION,true);
        }
    }
    public static function nav($active) {
        $links=['aaihb-home'=>(__('全体を見る','autorepair-ai-hosting-beta')),'aaihb-protect'=>(__('① 守る','autorepair-ai-hosting-beta')),'aaihb-respond'=>(__('② 対応する','autorepair-ai-hosting-beta')),'aaihb-grow'=>(__('③ 広げる','autorepair-ai-hosting-beta'))];
        if(current_user_can('manage_options')) {$links+=['aaihb-get-started'=>(__('はじめる','autorepair-ai-hosting-beta')),'aaihb-emergency'=>(__('緊急モード','autorepair-ai-hosting-beta')),'aaihb-verification'=>(__('最新検証結果','autorepair-ai-hosting-beta')),'aaihb-recovery'=>(__('自動修復・復元','autorepair-ai-hosting-beta')),'aaihb-vault'=>(__('バックアップ・復元','autorepair-ai-hosting-beta')),'aaihb-license'=>(__('利用数と料金','autorepair-ai-hosting-beta')),'aaihb-start'=>(__('かんたん接続','autorepair-ai-hosting-beta')),'aaihb-buy'=>(__('購入・契約管理','autorepair-ai-hosting-beta')),'aaihb-help'=>(__('困ったとき','autorepair-ai-hosting-beta')),'aaihb-value'=>(__('効果を確認','autorepair-ai-hosting-beta')),'aaihb'=>(__('接続設定','autorepair-ai-hosting-beta')),'aaihb-notify'=>(__('通知設定','autorepair-ai-hosting-beta')),'aaihb-partner'=>(__('パートナーAPI','autorepair-ai-hosting-beta')),'aaihb-ops'=>(__('対応案件','autorepair-ai-hosting-beta')),'aaihb-fleet'=>(__('グループ・予約','autorepair-ai-hosting-beta')),'aaihb-history'=>(__('診断履歴','autorepair-ai-hosting-beta'))];}
        echo ('<nav class="aaihb-nav" aria-label="'.esc_html__('AutoRepair AIの画面','autorepair-ai-hosting-beta').'">');
        foreach($links as $slug=>$label){echo '<a '.($slug===$active?'aria-current="page"':'').' href="'.esc_url(admin_url('admin.php?page='.$slug)).'">'.esc_html($label).'</a>';}
        echo '</nav>';
    }
    public static function classification($s) {
        if(!empty($s['fleet_paused']) || !empty($s['error']) || empty($s['report']) || strtotime($s['report']['generated_at']) < time()-172800) {return 'unknown';}
        $status='healthy';
        foreach($s['report']['checks'] as $c){if($c['status']==='critical')return 'critical';if($c['status']==='warning')$status='warning';}
        return $status;
    }
    public static function labels() {return ['critical'=>__('重大な異常', 'autorepair-ai-hosting-beta'),'warning'=>__('確認が必要', 'autorepair-ai-hosting-beta'),'healthy'=>__('診断項目は正常', 'autorepair-ai-hosting-beta'),'unknown'=>__('状態を確認できず', 'autorepair-ai-hosting-beta')];}
    /** 画面ごとの操作マニュアル。$key は home / protect / respond。 */
    const MANUAL_CSS = '.aaihb-manual{margin:16px 0 26px;padding:18px 20px;border:1px solid #dcdcde;border-left:4px solid #2271b1;border-radius:8px;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.04)}.aaihb-manual>h2{margin:0 0 6px;font-size:16px;line-height:1.4}.aaihb-manual__lead{margin:0 0 14px;color:#50575e;font-size:13px;line-height:1.7}.aaihb-manual details{border:1px solid #e2e4e7;border-radius:6px;margin:0 0 8px;background:#fbfbfc}.aaihb-manual details:last-child{margin-bottom:0}.aaihb-manual summary{cursor:pointer;padding:10px 12px;font-weight:600;font-size:13px}.aaihb-manual details[open] summary{border-bottom:1px solid #e2e4e7}.aaihb-manual__body{padding:10px 12px}.aaihb-manual__body p{margin:0 0 8px;font-size:13px;line-height:1.7}.aaihb-manual__body ol,.aaihb-manual__body ul{margin:0 0 0 18px;padding:0}.aaihb-manual__body ol li,.aaihb-manual__body ul li{font-size:13px;line-height:1.7;margin:0 0 6px}.aaihb-manual__warn{background:#fff8e5;border:1px solid #f0c33c;border-radius:6px;padding:10px 12px}.aaihb-manual__warn ul{margin:0 0 0 18px}';
    public static function manual($key) {
        static $styled = false;
        $books = [
            'home' => [
                'title' => '「全体を見る」の使い方',
                'lead'  => '接続したサイトの状態を一覧で確認し、異常のあるサイトから順に対応を進める画面です。ここでの診断は状態の確認だけで、修復や更新は実行しません。',
                'steps' => [
                    '画面上部の「▶ 全サイトを診断する」を押します。進み具合は下のバーに表示され、「停止する」で途中停止できます。',
                    '診断が終わると、4つの件数（重大な異常／確認が必要／診断項目は正常／状態を確認できず）が更新されます。件数のボタンを押すと、その状態のサイトだけに絞り込めます。',
                    '1サイトだけ確認したいときは、サイトのカードにある「このサイトを診断」を押します。',
                    '「診断項目を見る」を開くと、項目ごとの 正常／注意／重大 が確認できます。',
                    '対応が必要なサイトは「対応を見る →」から対応案件へ進みます。',
                    'サイトが多いときは「サイトを探す」にサイト名の一部を入力すると絞り込めます。',
                ],
                'terms' => [
                    ['重大な異常', '診断項目に「重大」が1つ以上ある状態です。対応案件を開き、対象と影響範囲を確認してください。'],
                    ['確認が必要', '診断項目に「注意」があります。すぐに停止は不要ですが、内容を確認してください。'],
                    ['診断項目は正常', '診断した項目に問題は見つかりませんでした。サイト全体の安全を保証する表示ではありません。'],
                    ['状態を確認できず', '未診断、前回の診断から48時間以上経過、接続エラー、診断を停止中のいずれかです。'],
                    ['診断スコア', '0〜100の目安です。100が満点ですが、これも診断項目の範囲での評価です。'],
                    ['判定日時（UTC）', '最後に診断結果を取得した時刻です。日本時間とは9時間の差があります。'],
                    ['定期診断', 'フッターに「有効／無効」と最終実行時刻（UTC）を表示します。無効のときは手動で診断してください。'],
                ],
                'warns' => [
                    ['「新しい診断が必要です」と出る', '前回の診断から48時間以上経過しています。「このサイトを診断」を押してください。'],
                    ['「診断を停止中です」と出る', 'そのサイトの定期診断を止めています。「グループ・予約」で再開できます。'],
                    ['接続エラーの文言が出る', '「かんたん接続」で接続情報を確認し、「困ったとき」の手順を参照してください。'],
                    ['サイトが1件も表示されない', '「接続設定」または「かんたん接続」でサイトを登録してください。'],
                    ['スコアだけ見て判断してしまう', 'スコアは目安です。「診断項目を見る」で中身を確認してから判断してください。'],
                ],
                'links' => [['対応案件', 'aaihb-ops'], ['かんたん接続', 'aaihb-start'], ['困ったとき', 'aaihb-help'], ['グループ・予約', 'aaihb-fleet']],
            ],
            'protect' => [
                'title' => '「守る」の使い方',
                'lead'  => '更新や復元に備えて、いま復元できる状態かを確認する画面です。ここで確認してから更新作業に入ると、障害時の復旧が速くなります。',
                'steps' => [
                    'まず「更新リスク」の表示を確認します。3つの状態のどれかを示します。',
                    '「復旧リハーサルを開始する」を押して、隔離環境での復元テストを実行します。',
                    'テストが終わると「復元信頼度スコア」が更新されます。スコアが高いほど、復元手順が確認できています。',
                    'WordPress本体・テーマ・プラグインの通常の更新を行うと、「更新前後の変更記録」に自動で記録されます。',
                    '障害が起きたときは、変更記録で直前の変更を確認してから「緊急モードを開く」へ進みます。',
                ],
                'terms' => [
                    ['復元確認済み', '直近のリハーサルが成功しており、更新前の安全確認が済んでいます。'],
                    ['再確認が必要', '前回の確認から時間が経っているか、内容に変更があります。更新前に再実行してください。'],
                    ['未確認・失敗あり', 'まだリハーサルをしていないか、失敗しています。更新前に必ず実行してください。'],
                    ['復元信頼度スコア', '0〜100の目安です。復元手順がどこまで確認できたかを表します。'],
                    ['更新前後の変更記録', '日時（UTC）・対象（WordPress／テーマ／プラグイン）・変更前後のバージョンを記録します。ファイルの中身やパスワードなどの秘密情報は保存しません。'],
                    ['（差分なし）', '更新は実行されましたが、バージョンの変化がなかったことを示します。'],
                    ['セーフティゲート', '更新前に必要な確認が済んでいるかを判定する仕組みです。「セーフティゲートを設定する」から調整できます。'],
                ],
                'warns' => [
                    ['「未確認・失敗あり」と出る', '「復旧リハーサルを開始する」を実行してください。Dockerが使えない環境ではテストを実行できないため、その旨が表示されます。'],
                    ['スコアが低い', 'リハーサルを再実行し、失敗した項目を確認してください。'],
                    ['変更記録が空', 'まだ更新履歴がないだけです。記録は更新時に自動で追加されます。'],
                    ['更新直後に障害が出た', '変更記録で直前の変更を特定し、「緊急モードを開く」へ進んでください。'],
                    ['リハーサルが実行できない', 'この環境では隔離テストに必要な機能が使えません。実行できるサーバーで確認するか、未確認のまま進める判断をしてください。'],
                ],
                'links' => [['バックアップ・復元', 'aaihb-vault'], ['緊急モード', 'aaihb-emergency'], ['自動修復・復元', 'aaihb-recovery']],
            ],
            'respond' => [
                'title' => '「対応する」の使い方',
                'lead'  => '障害が起きたときと、復旧が終わったあとに使う画面です。上から順番に進めれば、必要な操作だけを行えます。',
                'steps' => [
                    '障害が起きたら「緊急モードを開く」を押し、表示される順番どおりに進めます。',
                    '復旧が終わったら「復旧後の自動チェックを実行」を押します。',
                    '自動確認の結果（トップページ／管理画面／DB）を確認します。',
                    '自動で確認できない項目（メール送信・フォーム送信）を実際に試し、チェックを入れて「手動チェック結果を記録」を押します。',
                    '記録した内容は「復旧履歴を見る」から確認できます。',
                ],
                'terms' => [
                    ['緊急モード', '保存ポイントの確認・作成 → 直前の保存ポイント（隔離復元テスト）の確認 → 本番復元 → 復旧後チェック、の順に進みます。'],
                    ['復旧後の自動チェック', 'トップページのHTTP応答、現在の管理権限、DB接続を自動で確認します。メールとフォームは送信しません。'],
                    ['自動確認の表示', '「確認済み（HTTP 200）」「未確認」の形で表示されます。実行日時はUTCです。'],
                    ['手動で確認する項目', 'トップページ（HTTP 200）／管理画面にログイン／DBの表示・保存／メール送信／フォーム送信の5項目です。'],
                    ['最終手動記録', '最後に手動チェックを記録した日時です。まだ記録がないときは「未記録」と表示します。'],
                    ['隔離復元テストの対象外', '購入処理・フォーム送信・外部連携は自動テストの確認対象外です。実サイトで個別に確認してください。'],
                ],
                'warns' => [
                    ['自動チェックで「未確認」が残る', '対象の項目を実際に操作してから、もう一度実行してください。'],
                    ['トップページが200番台以外', '直前の保存ポイントを確認し、必要なら復元してください。'],
                    ['DBが「未確認」', 'データベース接続に問題がある可能性があります。復元手順を確認してください。'],
                    ['メール・フォームが未確認のまま', 'テスト送信を実際に行い、チェックを入れて記録してください。自動では確認できません。'],
                    ['どこから手を付けるか分からない', '「緊急モードを開く」を押してください。必要な操作だけが順番に表示されます。'],
                ],
                'links' => [['緊急モード', 'aaihb-emergency'], ['対応案件', 'aaihb-ops'], ['バックアップ・復元', 'aaihb-vault']],
            ],
        ];
        if (!isset($books[$key])) { return; }
        $b = $books[$key];
        if (!$styled) { $styled = true; echo '<style>' . self::MANUAL_CSS . '</style>'; }
        $id = 'aaihb-manual-' . $key;
        echo '<section class="aaihb-manual" aria-labelledby="' . esc_attr($id) . '">';
        echo '<h2 id="' . esc_attr($id) . '">' . esc_html($b['title']) . '</h2>';
        echo '<p class="aaihb-manual__lead">' . esc_html($b['lead']) . '</p>';
        echo '<details open><summary>手順</summary><div class="aaihb-manual__body"><ol>';
        foreach ($b['steps'] as $s) { echo '<li>' . esc_html($s) . '</li>'; }
        echo '</ol></div></details>';
        echo '<details><summary>用語と状態の意味</summary><div class="aaihb-manual__body"><ul>';
        foreach ($b['terms'] as $t) { echo '<li><strong>' . esc_html($t[0]) . '</strong>：' . esc_html($t[1]) . '</li>'; }
        echo '</ul></div></details>';
        echo '<details><summary>警告が出たときの対応</summary><div class="aaihb-manual__body"><div class="aaihb-manual__warn"><ul>';
        foreach ($b['warns'] as $w) { echo '<li><strong>' . esc_html($w[0]) . '</strong> → ' . esc_html($w[1]) . '</li>'; }
        echo '</ul></div></div></details>';
        echo '<details><summary>関連する画面</summary><div class="aaihb-manual__body"><ul>';
        foreach ($b['links'] as $l) { echo '<li><a href="' . esc_url(admin_url('admin.php?page=' . $l[1])) . '">' . esc_html($l[0]) . '</a></li>'; }
        echo '</ul></div></details>';
        echo '</section>';
    }
    public static function page() {
        AAIHB_Operations::allowed();nocache_headers();
        $sites=AAIHB_Beta::sites();$counts=array_fill_keys(array_keys(self::labels()),0);
        foreach($sites as $id=>&$entry){$entry['fleet_paused']=AAIHB_Fleet::paused($id);}unset($entry);
        foreach($sites as $s){$counts[self::classification($s)]++;}
        $admin=current_user_can('manage_options');$settings=AAIHB_Beta::settings();
        echo '<div class="wrap aaihb-app aaihb-home" style="--blue:'.esc_attr($settings['accent']).'"><header class="aaihb-brand">'.($settings['hide_branding']?'':'<div><span class="aaihb-mark" aria-hidden="true">✦</span><strong>AutoRepair AI</strong><span class="aaihb-edition">HOSTING / '.AAIHB_VERSION.'</span></div>').'<span>'.esc_html($settings['company']?:__('サイト運用ワークスペース', 'autorepair-ai-hosting-beta')).'</span></header>';
        self::nav('aaihb-home');
        self::manual('home');
        if($admin){$on=AAIHB_Onboarding::steps();$remaining=0;foreach($on as $step)if(!$step['ok'])$remaining++;if($remaining)echo __('<section class="aaihb-first-run"><div><small>GET STARTED · 残り ', 'autorepair-ai-hosting-beta').(int)$remaining.__('項目</small><h2>AutoRepair AI を始めましょう</h2><p>最初は5つの設定だけです。次にすることを1つずつ案内します。</p></div><a class="button button-primary" href="', 'autorepair-ai-hosting-beta').esc_url(admin_url('admin.php?page=aaihb-get-started')).__('">導入を開始する</a></section>', 'autorepair-ai-hosting-beta');}
        echo __('<section class="aaihb-route" aria-label="運用の入口"><a href="', 'autorepair-ai-hosting-beta').esc_url(admin_url('admin.php?page=aaihb-protect')).__('"><b>①</b><span><strong>守る</strong><small>バックアップ・復元テスト</small></span></a><a href="', 'autorepair-ai-hosting-beta').esc_url(admin_url('admin.php?page=aaihb-respond')).__('"><b>②</b><span><strong>対応する</strong><small>障害・更新・復旧履歴</small></span></a><a href="', 'autorepair-ai-hosting-beta').esc_url(admin_url('admin.php?page=aaihb-grow')).__('"><b>③</b><span><strong>広げる</strong><small>接続サイト・チーム・料金</small></span></a></section>', 'autorepair-ai-hosting-beta');
        if($admin){$v=AAIHB_Verification::remote();$vs=AAIHB_Verification::summary($v);echo __('<section class="aaihb-verify-home"><div><small>PRODUCT VERIFICATION</small><h2>最新検証結果</h2><p>✓ ', 'autorepair-ai-hosting-beta').(int)$vs['passed'].__('件確認済み　△ ', 'autorepair-ai-hosting-beta').(int)$vs['pending'].__('件未検証　○ ', 'autorepair-ai-hosting-beta').(int)$vs['preparing'].__('件準備中</p></div><a class="button button-primary" href="', 'autorepair-ai-hosting-beta').esc_url(admin_url('admin.php?page=aaihb-verification')).__('">検証結果を見る</a></section>', 'autorepair-ai-hosting-beta');}
        echo __('<section class="aaihb-hero"><div><p class="aaihb-eyebrow">YOUR SITES. ONE VIEW.</p><h1>サイトの状態を、<br>ひと目で。</h1><p>まず診断。気になるサイトから確認しましょう。</p><div class="aaihb-actions">', 'autorepair-ai-hosting-beta');
        if($admin && $sites){echo __('<button type="button" class="aaihb-primary" id="aaihb-home-scan">▶ 全サイトを診断する</button><button type="button" class="aaihb-ghost" id="aaihb-home-stop" disabled>停止する</button>', 'autorepair-ai-hosting-beta');}
        elseif($admin){echo '<a class="aaihb-primary" href="'.esc_url(admin_url('admin.php?page=aaihb-start')).__('">＋ 最初のサイトを接続する</a>', 'autorepair-ai-hosting-beta');}
        else {echo '<a class="aaihb-primary" href="'.esc_url(admin_url('admin.php?page=aaihb-ops&owner='.get_current_user_id())).__('">自分の担当案件を見る →</a>', 'autorepair-ai-hosting-beta');}
        echo '</div><p class="aaihb-hero-note">'.($admin?__('診断は状態の確認です。修復や更新は実行しません。', 'autorepair-ai-hosting-beta'):__('診断・接続の設定は管理者が行います。', 'autorepair-ai-hosting-beta')).__('</p></div><div class="aaihb-orbit"><div class="aaihb-orbit-inner"><span>管理しているサイト</span><strong>', 'autorepair-ai-hosting-beta').count($sites).'</strong><span>SITES CONNECTED</span></div></div></section>';
        echo '<div class="aaihb-progress-panel"><div id="aaihb-home-progress" role="status" aria-live="polite">'.($sites?__('診断を開始すると、ここに進み具合を表示します。', 'autorepair-ai-hosting-beta'):__('接続設定でサイトを登録すると、この画面に表示されます。', 'autorepair-ai-hosting-beta')).'</div><progress id="aaihb-home-meter" value="0" max="'.max(1,count($sites)).__('" aria-label="診断の進み具合"></progress></div>', 'autorepair-ai-hosting-beta');
        echo __('<section class="aaihb-stats" aria-label="サイトの状態別件数">', 'autorepair-ai-hosting-beta');
        $symbols=['critical'=>'!','warning'=>'△','healthy'=>'✓','unknown'=>'?'];
        foreach(self::labels() as $key=>$label){echo '<button type="button" class="aaihb-stat tone-'.$key.'" data-filter="'.$key.'" aria-pressed="false"><span class="aaihb-stat-top"><span class="aaihb-symbol" aria-hidden="true">'.$symbols[$key].'</span>'.esc_html($label).'</span><strong data-count="'.$key.'">'.$counts[$key].__('<small>サイト</small></strong><span>クリックして絞り込む →</span></button>', 'autorepair-ai-hosting-beta');}
        echo __('</section><section class="aaihb-route" aria-label="使い方"><div><b>01</b><span><strong>診断する</strong><small>登録サイトを順番に確認</small></span></div><div><b>02</b><span><strong>異常を見る</strong><small>色付きカードから対象を選ぶ</small></span></div><div><b>03</b><span><strong>対応を進める</strong><small>担当・期限・状況を記録</small></span></div></section>', 'autorepair-ai-hosting-beta');
        echo __('<section class="aaihb-sites"><div class="aaihb-section-head"><div><h2>サイト一覧</h2><p>正常は診断対象の項目についての判定です。サイト全体の安全を保証する表示ではありません。</p></div><a class="aaihb-link" href="', 'autorepair-ai-hosting-beta').esc_url(admin_url('admin.php?page=aaihb-ops')).__('">対応案件を開く →</a></div><div class="aaihb-toolbar"><label>サイトを探す <input type="search" id="aaihb-home-search" placeholder="サイト名を入力"></label><button class="button" type="button" data-filter="all" aria-pressed="true">すべて表示</button><span id="aaihb-home-visible" aria-live="polite"></span></div><div class="aaihb-site-grid">', 'autorepair-ai-hosting-beta');
        uasort($sites,function($a,$b){$rank=['critical'=>0,'warning'=>1,'unknown'=>2,'healthy'=>3];return $rank[self::classification($a)]<=>$rank[self::classification($b)];});
        foreach($sites as $id=>$s){$type=self::classification($s);$r=$s['report'];
            echo '<article class="aaihb-site tone-'.$type.'" data-site="'.esc_attr($id).'" data-name="'.esc_attr($s['name']).'" data-state="'.$type.'"><div class="aaihb-site-heading"><span class="aaihb-site-icon" aria-hidden="true">▣</span><h3>'.esc_html($s['name']).'</h3></div><span class="aaihb-status">'.esc_html(self::labels()[$type]).'</span><div class="aaihb-site-body"><strong class="aaihb-site-score">'.($type==='unknown'?'—':(int)$r['score']).'</strong><span class="aaihb-score-caption">'.($type==='unknown'?__('新しい診断が必要です', 'autorepair-ai-hosting-beta'):__('/ 100　診断スコア', 'autorepair-ai-hosting-beta')).'</span></div><p class="aaihb-site-message">'.esc_html(!empty($s['fleet_paused'])?__('診断を停止中です。グループ・予約で再開できます。', 'autorepair-ai-hosting-beta'):($s['error']?:($type==='unknown'?__('未診断、または前回の結果が48時間以上前です。', 'autorepair-ai-hosting-beta'):__('判定日時（UTC）：', 'autorepair-ai-hosting-beta').$r['generated_at']))).'</p><div class="aaihb-site-actions">';
            if($admin){echo '<button class="button aaihb-home-one" type="button" data-id="'.esc_attr($id).__('">このサイトを診断</button>', 'autorepair-ai-hosting-beta');}
            echo '<a class="aaihb-link" href="'.esc_url(add_query_arg(['page'=>'aaihb-ops','search'=>$s['name']],admin_url('admin.php'))).__('">対応を見る →</a></div><details><summary>診断項目を見る</summary><div class="aaihb-checks">', 'autorepair-ai-hosting-beta');
            if($r){foreach($r['checks'] as $c){echo '<p>'.esc_html(AAIHB_Value::guide($c['id'])[0]).'<span>'.esc_html(['healthy'=>__('正常', 'autorepair-ai-hosting-beta'),'warning'=>__('注意', 'autorepair-ai-hosting-beta'),'critical'=>__('重大', 'autorepair-ai-hosting-beta')][$c['status']]).'</span></p>';}}else{echo __('<p>まだ診断結果がありません。</p>', 'autorepair-ai-hosting-beta');}
            echo '</div></details></article>';
        }
        echo '</div><p id="aaihb-home-empty" '.($sites?'hidden':'').__('>表示するサイトがありません。', 'autorepair-ai-hosting-beta').($admin?__('「接続設定」で対象サイトを登録してください。', 'autorepair-ai-hosting-beta'):__('管理者に対象サイトの登録を依頼してください。', 'autorepair-ai-hosting-beta')).__('</p></section><footer class="aaihb-footer"><span>定期診断：', 'autorepair-ai-hosting-beta').(get_option('aaihb_auto_scan')?__('有効', 'autorepair-ai-hosting-beta'):__('無効', 'autorepair-ai-hosting-beta')).__(' ／ 最終実行（UTC）：', 'autorepair-ai-hosting-beta').esc_html(get_option('aaihb_tick_at',__('未実行', 'autorepair-ai-hosting-beta'))).'</span><span>Powered by AutoRepair AI</span></footer></div>';
    }
}
