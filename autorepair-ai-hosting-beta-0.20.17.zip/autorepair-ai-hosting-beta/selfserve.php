<?php
if(!defined('ABSPATH'))exit;
final class AAIHB_Selfserve {
    const SETTINGS='aaihb_store';
    public static function boot(){add_action('admin_menu',[__CLASS__,'menu']);add_action('admin_post_aaihb_selfserve',[__CLASS__,'save']);add_action('admin_post_aaihb_stripe_test_checkout',[__CLASS__,'stripe_test_checkout']);add_action('admin_post_aaihb_stripe_test_portal',[__CLASS__,'stripe_test_portal']);}
    public static function menu(){foreach(['aaihb-start'=>__( 'かんたん接続', 'autorepair-ai-hosting-beta' ),'aaihb-buy'=>__( '購入・契約管理', 'autorepair-ai-hosting-beta' ),'aaihb-help'=>__( '困ったとき', 'autorepair-ai-hosting-beta' )] as $slug=>$label)add_submenu_page('aaihb-home',$label,$label,'manage_options',$slug,[__CLASS__,'page']);}
    public static function store(){return wp_parse_args(get_option(self::SETTINGS,[]),['checkout'=>'','portal'=>'','description'=>'','ready'=>false]);}
    public static function link($url){if($url==='')return '';if(strlen($url)>2000||!wp_http_validate_url($url)||wp_parse_url($url,PHP_URL_SCHEME)!=='https'||wp_parse_url($url,PHP_URL_USER)||wp_parse_url($url,PHP_URL_FRAGMENT))throw new RuntimeException((__('公開HTTPSのURLを入力してください。','autorepair-ai-hosting-beta')));return esc_url_raw($url,['https']);}
    public static function configure($checkout,$portal,$description,$ready){AAIHB_Beta::allowed();$c=self::link($checkout);$p=self::link($portal);$d=sanitize_textarea_field($description);if(strlen($d)>3000)throw new RuntimeException((__('案内は3000バイト以内で入力してください。','autorepair-ai-hosting-beta')));if($ready&&(!$c||!$d))throw new RuntimeException((__('購入先とプラン説明を設定してください。','autorepair-ai-hosting-beta')));update_option(self::SETTINGS,['checkout'=>$c,'portal'=>$p,'description'=>$d,'ready'=>(bool)$ready],false);}
    public static function parse($raw){
        if(!is_string($raw)||strlen($raw)>4096)throw new RuntimeException((__('接続情報を4096バイト以内で貼り付けてください。','autorepair-ai-hosting-beta')));
        $d=json_decode(trim($raw),true);if(!is_array($d)||($d['format']??'')!=='aaihb-connect-1'||!is_string($d['endpoint']??null)||!is_string($d['token']??null)||!is_string($d['name']??null))throw new RuntimeException((__('対象サイトでコピーした接続情報を、そのまま貼り付けてください。','autorepair-ai-hosting-beta')));
        $url=AAIHB_Beta::endpoint($d['endpoint']);if(!$url||!preg_match('/^[a-f0-9]{64}$/D',$d['token']))throw new RuntimeException((__('公開HTTPSの接続先と64桁のトークンが必要です。','autorepair-ai-hosting-beta')));
        return ['endpoint'=>$url,'token'=>$d['token'],'name'=>wp_html_excerpt(sanitize_text_field($d['name']),80,'')];
    }
    public static function connect($raw,$replace){
        AAIHB_Beta::allowed();if(!is_ssl())throw new RuntimeException((__('管理側もHTTPSで開いてください。','autorepair-ai-hosting-beta')));$d=self::parse($raw);$id=hash('sha256',$d['endpoint']);
        if(!add_option('aaihb_registry_lock',time(),'',false))throw new RuntimeException((__('別の登録が処理中です。少し待ってください。','autorepair-ai-hosting-beta')));
        try{
            AAIHB_Billing::meter();
            if(AAIHB_Beta::sites_exists($id)&&!$replace)throw new RuntimeException((__('登録済みです。更新する場合は「既存の接続情報を置き換える」にチェックしてください。','autorepair-ai-hosting-beta')));
            AAIHB_Billing::assert_registration($id);
            $token=AAIHB_Beta::crypt($d['token']);AAIHB_Beta::site_put($id,['name'=>$d['name']?:(__('登録サイト','autorepair-ai-hosting-beta')),'endpoint'=>$d['endpoint'],'token'=>$token,'report'=>null,'error'=>'','attempt'=>'']);
            $stored=AAIHB_Beta::site($id);if(!$stored||$stored['token']!==$token)throw new RuntimeException((__('登録を保存できませんでした。データベースを確認してください。','autorepair-ai-hosting-beta')));
            do_action('aaihb_registry_saved',AAIHB_Beta::sites_count());
        }finally{delete_option('aaihb_registry_lock');}
        $r=AAIHB_Beta::scan_site($id);return ['id'=>$id,'ok'=>!is_wp_error($r),'message'=>is_wp_error($r)?$r->get_error_message():(__('登録・診断データの取得が完了しました。','autorepair-ai-hosting-beta')),'help'=>is_wp_error($r)?self::category($r->get_error_message()):''];
    }
    public static function category($error){if(preg_match('/HTTP\s+(\d+)/',$error,$m)){return ['403'=>'auth','429'=>'wait','503'=>'dependency','404'=>'url'][$m[1]]??'network';}if(strpos($error,'停止中')!==false||stripos($error,'paused')!==false)return 'paused';if(strpos($error,'形式')!==false||stripos($error,'format')!==false)return 'format';if(strpos($error,'トークン')!==false||stripos($error,'token')!==false)return 'auth';return 'network';}
    public static function guides(){return [
        'auth'=>[(__('403・認証できない','autorepair-ai-hosting-beta')),(__('対象サイトで接続が有効か確認します。接続情報を再発行した場合は、管理側へ新しい情報を貼り付けて更新します。WAFによる拒否でも403になるため、認証だけが原因とは限りません。','autorepair-ai-hosting-beta'))],
        'wait'=>[(__('429・診断が混み合っている','autorepair-ai-hosting-beta')),(__('同じサイトの前回診断から60秒以上待ちます。定期診断や別の画面で診断している場合は、重ねて実行しないでください。','autorepair-ai-hosting-beta'))],
        'dependency'=>[(__('503・対象サイトの準備を確認','autorepair-ai-hosting-beta')),(__('対象サイトのHosting Betaを0.11.0以降へ更新します。旧版の対象サイトではAutoRepair AI本体が必要です。新しい版は内蔵診断を使用します。','autorepair-ai-hosting-beta'))],
        'url'=>[(__('404・接続先が見つからない','autorepair-ai-hosting-beta')),(__('診断対象の「かんたん接続」で発行した接続情報を使います。公開ページのURLや管理画面のURLをそのまま入力しないでください。','autorepair-ai-hosting-beta'))],
        'network'=>[(__('接続・SSL・DNSのエラー','autorepair-ai-hosting-beta')),(__('両方のWordPressを公開HTTPSで開けるか確認します。証明書、DNS、WAF、外向き通信制限を確認します。SSL検証を無効にして回避しないでください。ローカル専用URLや内部IPは対象外です。','autorepair-ai-hosting-beta'))],
        'paused'=>[(__('診断を停止中','autorepair-ai-hosting-beta')),(__('「グループ・予約」で対象サイトを選び、診断を再開してから実行します。','autorepair-ai-hosting-beta'))],
        'format'=>[(__('診断データの形式が違う','autorepair-ai-hosting-beta')),(__('対象サイトの両プラグインのバージョンと、WAFやログイン画面が応答に混ざっていないか確認します。','autorepair-ai-hosting-beta'))],
        'token'=>[(__('コピーした接続情報が見つからない','autorepair-ai-hosting-beta')),(__('接続情報は発行直後の画面に一度だけ表示されます。再発行すると古いトークンは失効します。再発行後は接続済みの管理側も更新してください。','autorepair-ai-hosting-beta'))],
        'cron'=>[(__('画面を閉じると診断が進まない','autorepair-ai-hosting-beta')),(__('ホームの手動診断は画面を開いておきます。閉じて進めたい場合は「グループ・予約」を使います。予約にはWP-Cronの実行が必要です。','autorepair-ai-hosting-beta'))],
        'billing'=>[(__('購入したのに表示が変わらない','autorepair-ai-hosting-beta')),(__('現在は中央集計の検証モードです。「利用数と料金」で試算を確認できます。購入受付・実請求は開始していません。以前の契約は購入先で確認してください。','autorepair-ai-hosting-beta'))],
        'report'=>[(__('報告書をPDFにしたい','autorepair-ai-hosting-beta')),(__('顧客向け報告書を開き、ブラウザーの印刷で「PDFに保存」を選択します。社内の対応メモが載るため、内容を確認してから渡してください。','autorepair-ai-hosting-beta'))],
        'repair'=>[(__('異常があるのに自動修復されない','autorepair-ai-hosting-beta')),(__('「自動修復・復元」で限定修復を利用できます。自動修復は初期OFFで、空の内部URLルールだけが対象です。修復の計画・承認ボタンは記録用です。','autorepair-ai-hosting-beta'))]
    ];}
    private static function form($op){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="aaihb_selfserve"><input type="hidden" name="op" value="'.esc_attr($op).'">';wp_nonce_field('aaihb_selfserve');}
    public static function save(){
        AAIHB_Beta::allowed();check_admin_referer('aaihb_selfserve');$page='aaihb-start';$result=[];
        try{
            $op=AAIHB_Beta::input('op');
            if($op==='issue'){
                if(!is_ssl())throw new RuntimeException((__('HTTPSでこの画面を開いてください。','autorepair-ai-hosting-beta')));
                if(AAIHB_Beta::input('confirm')!=='1')throw new RuntimeException((__('再発行で古い接続情報が失効することを確認してください。','autorepair-ai-hosting-beta')));
                $token=bin2hex(random_bytes(32));$s=AAIHB_Beta::settings();$s['agent']=1;$s['hash']=hash('sha256',$token);update_option(AAIHB_Beta::SETTINGS,$s,false);if(AAIHB_Beta::settings()['hash']!==$s['hash'])throw new RuntimeException((__('接続情報を保存できませんでした。再度お試しください。','autorepair-ai-hosting-beta')));
                set_transient('aaihb_pack_'.get_current_user_id(),wp_json_encode(['format'=>'aaihb-connect-1','name'=>get_bloginfo('name'),'endpoint'=>rest_url('aaihb/v1/scan'),'token'=>$token],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),120);
                $result=['message'=>(__('接続情報を発行しました。下の欄をコピーして管理側へ貼り付けてください。','autorepair-ai-hosting-beta'))];
            }elseif($op==='connect'){$result=self::connect(AAIHB_Beta::input('pack'),AAIHB_Beta::input('replace')==='1');}
            elseif($op==='store'){$page='aaihb-buy';self::configure(AAIHB_Beta::input('checkout'),AAIHB_Beta::input('portal'),AAIHB_Beta::input('description'),AAIHB_Beta::input('ready')==='1');$result=['message'=>(__('購入導線の設定を保存しました。','autorepair-ai-hosting-beta'))];}
            else throw new RuntimeException((__('操作が不正です。','autorepair-ai-hosting-beta')));
        }catch(Throwable $e){$result=['message'=>$e->getMessage()];}
        set_transient('aaihb_flow_result_'.get_current_user_id(),$result,120);wp_safe_redirect(admin_url('admin.php?page='.$page));exit;
    }
    public static function stripe_test_checkout(){
        AAIHB_Beta::allowed();check_admin_referer('aaihb_stripe_test_checkout');
        try{
            $base=admin_url('admin.php');$success=add_query_arg(['page'=>'aaihb-buy','aaihb_checkout'=>'success'],$base);$cancel=add_query_arg(['page'=>'aaihb-buy','aaihb_checkout'=>'cancel'],$base);
            $url=AAIHB_Central::test_checkout_url($success,$cancel);wp_redirect($url,302);exit;
        }catch(Throwable $e){set_transient('aaihb_flow_result_'.get_current_user_id(),['message'=>$e->getMessage()],120);wp_safe_redirect(admin_url('admin.php?page=aaihb-buy'));exit;}
    }
    public static function stripe_test_portal(){
        AAIHB_Beta::allowed();check_admin_referer('aaihb_stripe_test_portal');
        try{
            $return=admin_url('admin.php?page=aaihb-buy');$url=AAIHB_Central::stripe_test_portal_url($return);wp_redirect($url,302);exit;
        }catch(Throwable $e){set_transient('aaihb_flow_result_'.get_current_user_id(),['message'=>$e->getMessage()],120);wp_safe_redirect(admin_url('admin.php?page=aaihb-buy'));exit;}
    }
    public static function page(){
        AAIHB_Beta::allowed();nocache_headers();$page=isset($_GET['page'])&&is_string($_GET['page'])?sanitize_key($_GET['page']):'aaihb-start';
        $titles=['aaihb-start'=>['CONNECT IN THREE STEPS',(__('貼り付けて、つなぐ。','autorepair-ai-hosting-beta')),(__('診断されるサイトで発行 → 管理側へ貼り付け → 結果を確認','autorepair-ai-hosting-beta'))], 'aaihb-buy'=>['YOUR PLAN',(__('購入・契約を、迷わず確認。','autorepair-ai-hosting-beta')),(__('購入先の条件を確認してから、お手続きください。','autorepair-ai-hosting-beta'))],'aaihb-help'=>['SELF SERVICE HELP',(__('困ったときは、ここから。','autorepair-ai-hosting-beta')),(__('表示されたエラーや、やりたいことから手順を探せます。','autorepair-ai-hosting-beta'))]];$title=$titles[$page]??$titles['aaihb-start'];
        echo '<div class="wrap aaihb-app aaihb-selfserve"><header class="ss-hero"><small>'.$title[0].'</small><h1>'.$title[1].'</h1><p>'.$title[2].'</p></header>';AAIHB_Dashboard::nav($page);
        $r=get_transient('aaihb_flow_result_'.get_current_user_id());delete_transient('aaihb_flow_result_'.get_current_user_id());
        if($r){echo '<section class="ss-result" role="status"><strong>'.esc_html($r['message']).'</strong>';if(isset($r['ok']))echo '<p>'.($r['ok']?(__('接続テスト成功。異常の有無は「全体を見る」で確認してください。','autorepair-ai-hosting-beta')):(__('登録は保存済みですが、診断は完了していません。','autorepair-ai-hosting-beta'))).'</p>';if(!empty($r['help']))echo '<a class="button" href="'.esc_url(admin_url('admin.php?page=aaihb-help#help-'.$r['help'])).('">'.esc_html__('このエラーの解決手順 →','autorepair-ai-hosting-beta').'</a>');echo '<p><a href="'.esc_url(admin_url('admin.php?page=aaihb')).('">'.esc_html__('接続設定・再診断を開く','autorepair-ai-hosting-beta').'</a></p></section>');}
        if($page==='aaihb-buy')self::buy();elseif($page==='aaihb-help')self::help();else self::start();echo '</div>';
    }
    private static function start(){
        AAIHB_Diagnostics::panel();
        $pack=get_transient('aaihb_pack_'.get_current_user_id());delete_transient('aaihb_pack_'.get_current_user_id());
        echo ('<div class="ss-grid"><section class="ss-card"><span class="ss-number">01</span><h2>'.esc_html__('診断されるサイトで操作','autorepair-ai-hosting-beta').'</h2><p>'.esc_html__('対象サイトにもHosting Betaを設置し、この画面を開きます。接続情報には認証トークンが含まれます。管理者以外に渡さないでください。','autorepair-ai-hosting-beta').'</p><ul class="ss-checks"><li>').(is_ssl()?'✓':(__('要確認','autorepair-ai-hosting-beta'))).(esc_html__(' HTTPSの管理画面','autorepair-ai-hosting-beta').'</li><li>').(class_exists('AAIHB_Diagnostics')?'✓':(__('要確認','autorepair-ai-hosting-beta'))).(esc_html__(' Hosting Beta内蔵診断（本体不要）','autorepair-ai-hosting-beta').'</li></ul>');
        if($pack){echo ('<label for="ss-pack">'.esc_html__('今回だけ表示する接続情報','autorepair-ai-hosting-beta').'</label><textarea id="ss-pack" readonly autocomplete="off" spellcheck="false">').esc_textarea($pack).('</textarea><button type="button" class="button button-primary" data-copy="ss-pack">'.esc_html__('接続情報をまとめてコピー','autorepair-ai-hosting-beta').'</button><p>'.esc_html__('画面を閉じる前にコピーしてください。ブラウザー内に自動保存しません。','autorepair-ai-hosting-beta').'</p>');}
        self::form('issue');echo ('<p><label><input required type="checkbox" name="confirm" value="1">'.esc_html__('発行すると古い接続情報が失効することを確認しました','autorepair-ai-hosting-beta').'</label></p>');submit_button((__('接続情報を発行する','autorepair-ai-hosting-beta')),'secondary');echo ('</form></section><section class="ss-card"><span class="ss-number">02</span><h2>'.esc_html__('まとめて管理する側で操作','autorepair-ai-hosting-beta').'</h2><p>'.esc_html__('対象サイトでコピーした情報を、下の欄へ一度だけ貼り付けます。URLとトークンを別々に入力する必要はありません。','autorepair-ai-hosting-beta').'</p>');
        self::form('connect');echo ('<label for="ss-import">'.esc_html__('対象サイトの接続情報','autorepair-ai-hosting-beta').'</label><textarea id="ss-import" name="pack" required autocomplete="off" spellcheck="false" placeholder="'.esc_html__('ここに接続情報を貼り付け','autorepair-ai-hosting-beta').'"></textarea><p id="ss-import-preview" aria-live="polite"></p><p><label><input type="checkbox" name="replace" value="1">'.esc_html__('登録済みの場合、既存の接続情報を置き換える','autorepair-ai-hosting-beta').'</label></p>');submit_button((__('登録して接続テスト','autorepair-ai-hosting-beta')));echo ('</form></section></div><section class="ss-card"><span class="ss-number">03</span><h2>'.esc_html__('結果を確認して、運用を始める','autorepair-ai-hosting-beta').'</h2><p>'.esc_html__('接続成功は診断データを取得できた意味です。異常がないことや、修復が完了したこととは異なります。','autorepair-ai-hosting-beta').'</p><a class="button button-primary" href="').esc_url(admin_url('admin.php?page=aaihb-home')).('">'.esc_html__('全体を見る →','autorepair-ai-hosting-beta').'</a> <a class="button" href="').esc_url(admin_url('admin.php?page=aaihb-help')).('">'.esc_html__('うまく接続できない場合','autorepair-ai-hosting-beta').'</a><p>'.esc_html__('対象サイトが旧版の場合は、従来の「接続設定」でURLとトークンを別々に登録できます。','autorepair-ai-hosting-beta').'</p></section><p id="ss-copy-status" role="status"></p>');
    }
    private static function buy(){
        $state=isset($_GET['aaihb_checkout'])&&is_string($_GET['aaihb_checkout'])?sanitize_key($_GET['aaihb_checkout']):'';
        if($state==='success')echo ('<section class="ss-result" role="status"><strong>'.esc_html__('Stripeのテスト決済が完了しました。','autorepair-ai-hosting-beta').'</strong><p>'.esc_html__('Webhookの受信処理には少し時間がかかる場合があります。実際の請求は発生しません。','autorepair-ai-hosting-beta').'</p></section>');
        elseif($state==='cancel')echo ('<section class="ss-result" role="status"><strong>'.esc_html__('テスト決済を中止しました。','autorepair-ai-hosting-beta').'</strong><p>'.esc_html__('実際の請求は発生していません。','autorepair-ai-hosting-beta').'</p></section>');
        echo ('<section class="ss-card"><h2>'.esc_html__('Stripeテスト決済','autorepair-ai-hosting-beta').'</h2><p>'.esc_html__('テストモード専用です。実際のカード請求は発生しません。中央サーバーとの接続後、StripeのテストカードでWebhook受信まで確認できます。','autorepair-ai-hosting-beta').'</p>');
        if(AAIHB_Central::configured())try{$stripe=AAIHB_Central::stripe_test_status();$labels=['active'=>(__('テスト契約は有効です','autorepair-ai-hosting-beta')),'trialing'=>(__('テストトライアル中です','autorepair-ai-hosting-beta')),'past_due'=>(__('テスト決済の確認が必要です','autorepair-ai-hosting-beta')),'unpaid'=>(__('テスト決済は未払いです','autorepair-ai-hosting-beta')),'canceled'=>(__('テスト契約はキャンセル済みです','autorepair-ai-hosting-beta')),'incomplete'=>(__('テスト契約の処理中です','autorepair-ai-hosting-beta')),'incomplete_expired'=>(__('テスト契約の期限が切れました','autorepair-ai-hosting-beta')),'none'=>(__('テスト契約はまだありません','autorepair-ai-hosting-beta'))];echo ('<p><strong>'.esc_html__('現在の状態：','autorepair-ai-hosting-beta')).esc_html($labels[$stripe['status']]??(__('確認できません','autorepair-ai-hosting-beta'))).'</strong></p>';if($stripe['cancellation_pending']&&$stripe['cancellation_at'])echo ('<p><strong>'.esc_html__('キャンセル予定：','autorepair-ai-hosting-beta')).esc_html(wp_date((__('Y年n月j日','autorepair-ai-hosting-beta')),$stripe['cancellation_at'])).(esc_html__('に終了します','autorepair-ai-hosting-beta').'</strong></p>');if($stripe['updated'])echo ('<p>'.esc_html__('最終更新：','autorepair-ai-hosting-beta')).esc_html($stripe['updated']).'</p>';if($stripe['status']!=='none'){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="aaihb_stripe_test_portal">';wp_nonce_field('aaihb_stripe_test_portal');submit_button((__('Stripeテスト用ポータルを開く','autorepair-ai-hosting-beta')),'secondary','submit',false);echo '</form>';}}catch(Throwable $e){echo ('<p>'.esc_html__('現在の状態：取得できません。しばらく待って再読み込みしてください。','autorepair-ai-hosting-beta').'</p>');}
        if(AAIHB_Central::configured()){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="aaihb_stripe_test_checkout">';wp_nonce_field('aaihb_stripe_test_checkout');submit_button((__('Stripeテスト決済を開始する','autorepair-ai-hosting-beta')),'primary','submit',false);echo '</form>';}else echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page=aaihb-license')).('">'.esc_html__('先に中央サーバーへ接続する →','autorepair-ai-hosting-beta').'</a></p>');
        echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page=aaihb-license')).('">'.esc_html__('利用数と料金を見る →','autorepair-ai-hosting-beta').'</a></p></section>');
    }
    private static function help(){
        echo ('<section class="ss-card"><label for="ss-search">'.esc_html__('困っていることを検索','autorepair-ai-hosting-beta').'</label><input id="ss-search" type="search" placeholder="'.esc_html__('例：403、トークン、購入、PDF','autorepair-ai-hosting-beta').'"><p id="ss-help-count" aria-live="polite"></p></section><div class="ss-faq">');foreach(self::guides() as $id=>$g)echo '<details class="ss-card" id="help-'.$id.'"><summary>'.esc_html($g[0]).'</summary><p>'.esc_html($g[1]).'</p></details>';echo ('</div><section class="ss-card"><h2>'.esc_html__('解決しない場合：確認用メモをコピー','autorepair-ai-hosting-beta').'</h2><p>'.esc_html__('サイトURL・トークン・顧客名は含めません。下の環境情報に、試した操作とエラー番号を添えて販売元へ問い合わせてください。送信は自動では行いません。','autorepair-ai-hosting-beta').'</p><textarea readonly id="ss-support">').esc_textarea('Hosting Beta '.AAIHB_VERSION.' / WordPress '.get_bloginfo('version').' / PHP '.PHP_VERSION.' / HTTPS '.(is_ssl()?'yes':'no').(__(' / 登録サイト ','autorepair-ai-hosting-beta')).AAIHB_Beta::sites_count()).('</textarea><button type="button" class="button" data-copy="ss-support">'.esc_html__('確認用メモをコピー','autorepair-ai-hosting-beta').'</button><p id="ss-copy-status" role="status"></p></section>');
    }
}
