<?php
/**
 * AutoRepair AI Hosting Beta — self-hosted update feed.
 *
 * WordPress decides which plugins have an update through the `update_plugins`
 * site transient. These two filters let a plugin answer from its own HTTPS feed
 * instead of the wordpress.org API:
 *
 *   pre_set_site_transient_update_plugins — offer a newer version
 *   plugins_api                           — render the "View version details" dialog
 *
 * The feed is a small JSON document (see update.json in the repository):
 *   { "version", "download_url", "homepage", "requires", "tested",
 *     "requires_php", "last_updated",
 *     "sections": { "description", "installation", "changelog", "faq" } }
 *
 * Only HTTPS feeds and HTTPS packages are accepted. The manifest is cached in a
 * site transient for six hours (thirty minutes after a failed fetch) so that a
 * slow or unreachable feed never slows down the plugins screen.
 *
 * Override the feed location with the `aaihb_update_feed` option.
 */

if (!defined('ABSPATH')) { exit; }

final class AAIHB_Updater {

	const SLUG         = 'autorepair-ai-hosting-beta';
	const NAME         = 'AutoRepair AI Hosting Beta';
	const FEED_OPT     = 'aaihb_update_feed';
	const CACHE_KEY    = 'aaihb_update_manifest';
	const DEFAULT_FEED = 'https://raw.githubusercontent.com/masa45594-crypto/autorepair-central/main/update.json';
	const TTL_OK       = 21600; // 6 hours
	const TTL_FAIL     = 1800;  // 30 minutes

	public static function boot() {
		add_filter('pre_set_site_transient_update_plugins', [__CLASS__, 'inject']);
		add_filter('plugins_api', [__CLASS__, 'details'], 20, 3);
		add_action('upgrader_process_complete', [__CLASS__, 'flush']);
		add_action('update_option_' . self::FEED_OPT, [__CLASS__, 'flush']);
	}

	/** Plugin file relative to the plugins directory, e.g. slug/slug.php. */
	public static function plugin_file() {
		return defined('AAIHB_PLUGIN_FILE')
			? plugin_basename(AAIHB_PLUGIN_FILE)
			: self::SLUG . '/' . self::SLUG . '.php';
	}

	public static function feed_url() {
		$url = trim((string) get_option(self::FEED_OPT, ''));
		return ($url !== '' && preg_match('#^https://#i', $url)) ? $url : self::DEFAULT_FEED;
	}

	public static function current_version() {
		if (defined('AAIHB_VERSION')) { return (string) AAIHB_VERSION; }
		if (!defined('AAIHB_PLUGIN_FILE')) { return '0.0.0'; }
		if (!function_exists('get_plugin_data')) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
		$data = get_plugin_data(AAIHB_PLUGIN_FILE, false, false);
		return isset($data['Version']) ? (string) $data['Version'] : '0.0.0';
	}

	/**
	 * Fetch and sanitize the feed. Returns [] when the feed is unusable, which
	 * callers treat as "no update offered".
	 */
	public static function manifest($force = false) {
		$key = self::CACHE_KEY . '_' . md5(self::feed_url());
		if (!$force) {
			$cached = get_site_transient($key);
			if (is_array($cached)) { return $cached; }
		}

		$body = '';
		$response = wp_remote_get(self::feed_url(), [
			'timeout'     => 8,
			'redirection' => 2,
			'sslverify'   => true,
			'headers'     => ['Accept' => 'application/json'],
			'user-agent'  => self::NAME . '/' . self::current_version() . '; ' . home_url('/'),
		]);
		if (!is_wp_error($response) && 200 === (int) wp_remote_retrieve_response_code($response)) {
			$body = (string) wp_remote_retrieve_body($response);
		}

		$decoded = json_decode($body, true);
		$clean   = self::sanitize(is_array($decoded) ? $decoded : []);
		set_site_transient($key, $clean, $clean ? self::TTL_OK : self::TTL_FAIL);
		return $clean;
	}

	private static function sanitize(array $data) {
		if (empty($data['version']) || empty($data['download_url'])) { return []; }

		$version = preg_replace('/[^0-9A-Za-z._-]/', '', (string) $data['version']);
		$package = esc_url_raw((string) $data['download_url']);
		if ($version === '' || !preg_match('#^https://#i', $package)) { return []; }

		$sections = [];
		foreach (['description', 'installation', 'changelog', 'faq'] as $slot) {
			if (!empty($data['sections'][$slot])) {
				$sections[$slot] = wp_kses_post((string) $data['sections'][$slot]);
			}
		}

		return [
			'version'      => $version,
			'download_url' => $package,
			'homepage'     => empty($data['homepage']) ? '' : esc_url_raw((string) $data['homepage']),
			'requires'     => empty($data['requires']) ? '' : preg_replace('/[^0-9.]/', '', (string) $data['requires']),
			'tested'       => empty($data['tested']) ? '' : preg_replace('/[^0-9.]/', '', (string) $data['tested']),
			'requires_php' => empty($data['requires_php']) ? '' : preg_replace('/[^0-9.]/', '', (string) $data['requires_php']),
			'last_updated' => empty($data['last_updated']) ? '' : sanitize_text_field((string) $data['last_updated']),
			'sections'     => $sections,
		];
	}

	/** Offer the new version on the Plugins screen. */
	public static function inject($transient) {
		if (!is_object($transient) || empty($transient->checked) || !is_array($transient->checked)) {
			return $transient;
		}
		$manifest = self::manifest();
		if (!$manifest) { return $transient; }

		$file    = self::plugin_file();
		$current = isset($transient->checked[$file]) ? (string) $transient->checked[$file] : self::current_version();

		if (!version_compare($manifest['version'], $current, '>')) {
			unset($transient->response[$file]);
			return $transient;
		}

		$transient->response[$file] = (object) [
			'id'            => self::SLUG,
			'slug'          => self::SLUG,
			'plugin'        => $file,
			'new_version'   => $manifest['version'],
			'url'           => $manifest['homepage'],
			'package'       => $manifest['download_url'],
			'requires'      => $manifest['requires'],
			'tested'        => $manifest['tested'],
			'requires_php'  => $manifest['requires_php'],
			'icons'         => [],
			'banners'       => [],
			'banners_rtl'   => [],
			'compatibility' => new stdClass(),
		];
		return $transient;
	}

	/** "View version details" dialog. */
	public static function details($result, $action, $args) {
		if ('plugin_information' !== $action) { return $result; }
		if (empty($args->slug) || self::SLUG !== (string) $args->slug) { return $result; }

		$manifest = self::manifest();
		if (!$manifest) { return $result; }

		$info = new stdClass();
		$info->name          = self::NAME;
		$info->slug          = self::SLUG;
		$info->version       = $manifest['version'];
		$info->author        = '<a href="' . esc_url($manifest['homepage']) . '">AutoRepair AI</a>';
		$info->homepage      = $manifest['homepage'];
		$info->requires      = $manifest['requires'];
		$info->tested        = $manifest['tested'];
		$info->requires_php  = $manifest['requires_php'];
		$info->last_updated  = $manifest['last_updated'];
		$info->download_link = $manifest['download_url'];
		$info->sections      = $manifest['sections'];
		$info->banners       = [];
		return $info;
	}

	/** Drop the cached manifest so the next check re-reads the feed. */
	public static function flush() {
		delete_site_transient(self::CACHE_KEY . '_' . md5(self::feed_url()));
	}
}
