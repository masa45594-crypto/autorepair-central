<?php
/**
 * Uninstall routine for AutoRepair AI Hosting Beta.
 *
 * 0.20.15 以降は「消しすぎない」方針です。ベータ版は zip をアップロードして
 * 置き換える運用のため、旧フォルダが削除扱いになると、以前の実装では aaihb_ で
 * 始まる全オプションと {prefix}aaihb_sites テーブルまで消え、中央サーバーへの
 * 接続情報と登録サイトが失われていました。
 *
 * 既定（安全側）:
 *   - 一時データのみ削除（ロック・キュー・通知・トランジェント）
 *   - aaihb_central（中央サーバーURL・暗号化された拠点トークン）は残す
 *   - {prefix}aaihb_sites（登録サイト）は残す
 *
 * 完全削除は明示的に選んだときだけ:
 *   aaihb_purge_on_uninstall オプションを 1 にする、または
 *   aaihb_purge_on_uninstall フィルタで true を返す。
 *
 * 無効化（deactivate）ではこのファイルは実行されません。データは削除時まで保持されます。
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
	exit;
}

if (!function_exists('aaihb_uninstall_wants_purge')) {
	/** Whether the administrator asked for a full data purge. */
	function aaihb_uninstall_wants_purge() {
		return (bool) apply_filters(
			'aaihb_purge_on_uninstall',
			(bool) get_option('aaihb_purge_on_uninstall', false)
		);
	}
}

if (!function_exists('aaihb_uninstall_site')) {
	/**
	 * Remove this plugin's data for the current site.
	 *
	 * Ephemeral state is always removed. Durable state (the central-server
	 * connection and the registered-site list) is kept unless a full purge was
	 * explicitly requested, so a routine upgrade that deletes the old folder can
	 * no longer disconnect the customer.
	 */
	function aaihb_uninstall_site() {
		global $wpdb;

		$purge = aaihb_uninstall_wants_purge();

		// Durable state kept by default.
		$keep_exact  = array('aaihb_central');
		$keep_prefix = array(
			'aaihb_vault',
			'aaihb_data',
			'aaihb_observation',
			'aaihb_month_',
			'aaihb_local_report',
			'aaihb_partner_key_',
			'aaihb_fleet_config',
			'aaihb_notify_',
		);

		if ($purge) {
			$wpdb->query($wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like('aaihb_') . '%'
			));
		} else {
			$names = $wpdb->get_col($wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like('aaihb_') . '%'
			));
			foreach ((array) $names as $name) {
				if (in_array($name, $keep_exact, true)) {
					continue;
				}
				$keep = false;
				foreach ($keep_prefix as $prefix) {
					if (strpos($name, $prefix) === 0) {
						$keep = true;
						break;
					}
				}
				if ($keep) {
					continue;
				}
				$wpdb->delete($wpdb->options, array('option_name' => $name));
			}
		}

		// Cached values are always safe to drop.
		foreach (array(
			$wpdb->esc_like('_transient_aaihb_') . '%',
			$wpdb->esc_like('_transient_timeout_aaihb_') . '%',
			$wpdb->esc_like('_site_transient_aaihb_') . '%',
			$wpdb->esc_like('_site_transient_timeout_aaihb_') . '%',
		) as $like) {
			$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like));
		}

		// Registered sites: dropped only on an explicit full purge.
		if ($purge) {
			$table = $wpdb->prefix . 'aaihb_sites';
			$wpdb->query("DROP TABLE IF EXISTS `{$table}`");
		}

		foreach (array(
			'aaihb_value_tick',
			'aaihb_central_tick',
			'aaihb_central_drain',
			'aaihb_recovery_tick',
			'aaihb_local_daily',
			'aaihb_fleet_tick',
			'aaihb_rehearsal_weekly',
		) as $hook) {
			wp_clear_scheduled_hook($hook);
		}
	}
}

if (is_multisite()) {
	$blog_ids = get_sites(array('fields' => 'ids', 'number' => 0));
	if (is_array($blog_ids)) {
		foreach ($blog_ids as $blog_id) {
			switch_to_blog((int) $blog_id);
			aaihb_uninstall_site();
			restore_current_blog();
		}
	}
	if (aaihb_uninstall_wants_purge()) {
		global $wpdb;
		$wpdb->query($wpdb->prepare(
			"DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s",
			$wpdb->esc_like('aaihb_') . '%'
		));
	}
} else {
	aaihb_uninstall_site();
}
