=== AutoRepair AI Hosting Beta ===
Contributors: masa45594
Tags: backup, restore, diagnostics, maintenance, monitoring
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.20.17
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Independent diagnostics, recovery and isolated restore rehearsal for WordPress, with backup status verified separately and usage metered against a central service.

== Description ==

AutoRepair AI Hosting Beta is a standalone plugin. It does not require the
AutoRepair AI service to run its diagnostics, backup and restore rehearsal.

* **Diagnostics** — checks PHP, MySQL/MariaDB, ZipArchive, storage and the
  isolated rehearsal prerequisites, and lists what is ready and what is not.
* **Backup** — full site backup scheduled from the admin screen, with an
  explicit write-freeze confirmation.
* **Isolated restore rehearsal** — restores a save point into a quarantined
  environment and verifies the front page, admin access and the database
  connection. The production site is never modified by a rehearsal.
* **Update protection** — records the state before an update and can roll the
  plugin change back.
* **Central usage metering** — an optional hub token links this site to a
  central service that counts registered sites and reports the estimate.

Restoring the live site is always a manual, confirmed action. Rehearsals run in
isolation only.

= Update feed =

The plugin reads its own update manifest over HTTPS. The default location is

    https://raw.githubusercontent.com/masa45594-crypto/autorepair-central/main/update.json

and it can be changed by setting the `aaihb_update_feed` option. The manifest
must be HTTPS and contain `version` and a HTTPS `download_url`. When the feed
offers a newer version, the update appears on the Plugins screen and installs
through the normal WordPress updater.

= Languages =

Source strings are Japanese. The plugin ships a translation template
(`languages/autorepair-ai-hosting-beta.pot`) and an English catalogue
(`languages/autorepair-ai-hosting-beta-en_US.po` / `.mo`). Strings that are not
yet wrapped in a translation function stay in Japanese.

== Installation ==

1. Upload the plugin zip through Plugins → Add New → Upload Plugin, or extract
   it into `wp-content/plugins/`.
2. Activate **AutoRepair AI Hosting Beta**.
3. Open the **AI運用ホーム** menu and follow **はじめる**.
4. Optional: open **利用数と料金** and paste the hub token to link the site to
   the central service.

== Frequently Asked Questions ==

= Does a rehearsal touch my live site? =

No. A rehearsal restores into a quarantined environment. Restoring the live
site is a separate, manually confirmed action.

= What happens when I delete the plugin? =

`uninstall.php` removes this plugin's options, transients, scheduled events and
its own table. On multisite the cleanup runs for every site on the network.

= Which databases are supported? =

MySQL 8.x and MariaDB 10.5 or newer, InnoDB tables only. The database version
is read from the server with `SELECT VERSION()`, not from the WordPress
abbreviated number.

== Screenshots ==

1. Diagnostics overview
2. Backup and restore rehearsal
3. Usage and billing

== Changelog ==

= 0.20.16 =
* English translations for quick connect, usage and billing, hub management, troubleshooting, test checkout, and built-in diagnostic panel.
* Preserves the non-destructive uninstall behavior and all existing connection data.
* Other administration modules remain partially untranslated.


= 0.20.15 =
* Added a self-hosted update feed: the plugin now offers and installs its own
  updates from an HTTPS manifest (`pre_set_site_transient_update_plugins`,
  `plugins_api`), with a cached manifest and HTTPS-only validation.
* Added translation support: `load_plugin_textdomain` on `init`, a `.pot`
  template and an English catalogue, with the admin menu labels wrapped.
* Added `uninstall.php`, which removes this plugin's options, transients,
  scheduled events and its own table, including multisite.
* Added this `readme.txt` in the WordPress format.

= 0.20.12 =
* The plan pricing card now shows the measured amount from the central service
  (for example `$29.00`) instead of a fixed string, with the monthly estimate,
  billable site count and yen equivalent.
* Response validation accepts the USD (`currency=usd`) payload and re-checks
  `billable_sites` and `estimate_usd_cents`; legacy yen responses still pass.
* Central pricing and monthly reconciliation now work in USD cents.

= 0.20.11 =
* "Last sync" is shown in the site time zone; the raw UTC value stays in the
  tooltip.

= 0.20.10 =
* Reconnect form can replace the hub token; suspended connections open the
  reconnect panel automatically.
* Hubs can be listed and revoked from the admin screen, and a hub token can be
  issued for another domain without the server shell.
* Central server: `GET /v1/manage/hubs`, `POST /v1/manage/hubs/revoke` and the
  unreceived-webhook alert loop.

== Upgrade Notice ==

= 0.20.15 =
Adds self-hosted updates, translation support and a proper uninstall routine.
No configuration change is required.
