<?php
if(!defined('ABSPATH'))exit;
final class AAIHB_Compatibility {
 public static function checks(){global $wpdb;$out=[];$add=function($label,$ok,$note)use(&$out){$out[]=['label'=>$label,'ok'=>(bool)$ok,'note'=>$note];};$add('PHP',version_compare(PHP_VERSION,'7.4.0','>='),'現在 '.PHP_VERSION.' ／ 必要 7.4 以上');$add('ZipArchive',class_exists('ZipArchive'),class_exists('ZipArchive')?'利用可能':'PHP ZipArchive拡張を有効にしてください');$mysql=isset($wpdb)&&method_exists($wpdb,'db_version')?$wpdb->db_version():'';$add('MySQL',is_string($mysql)&&preg_match('/^8\./',$mysql),'現在 '.($mysql?:'確認できません').' ／ 全体バックアップは MySQL 8.x 対応');try{$vault=AAIHB_VaultIO::root();$free=@disk_free_space($vault);$add('保管先',true,'公開領域外・権限0700を確認済み'.($free!==false?' ／ 空き '.size_format($free,1):''));}catch(Throwable $e){$add('保管先',false,$e->getMessage());}$add('隔離リハーサル',function_exists('proc_open'),'proc_open '.(function_exists('proc_open')?'利用可能':'が無効です。サーバー管理者へ確認してください'));return $out;}
}
