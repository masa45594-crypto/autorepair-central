<?php
if (PHP_SAPI !== 'cli') { exit; }
// Run with PHP CLI; isolated WP stubs, not a substitute for WordPress integration tests.
define('ABSPATH', __DIR__); define('WPAI_VERSION', '0.3.2');
$options = []; $ssl = true;
function add_action(...$a) {} function register_deactivation_hook(...$a) {}
function add_filter(...$a) {}
function wp_parse_args($a,$b) { return array_merge($b,$a); }
function get_option($k,$default=false) { return $GLOBALS['options'][$k] ?? $default; }
function update_option($k,$v,...$a) { $GLOBALS['options'][$k]=$v; }
function add_option($k,$v,...$a) { if(array_key_exists($k,$GLOBALS['options']))return false; $GLOBALS['options'][$k]=$v; return true; }
function delete_option($k) { unset($GLOBALS['options'][$k]); }
function is_multisite() { return false; } function is_ssl() { return $GLOBALS['ssl']; }
function sanitize_key($s) { return preg_replace('/[^a-z0-9_\-]/','',strtolower($s)); }
function wp_salt($s) { return 'isolated-test-salt'; }
function wp_parse_url($s) { return parse_url($s); }
function wp_http_validate_url($s) { return strpos($s,'https://public.example/')===0; }
function esc_url_raw($s) { return $s; }
function wp_json_encode($v) { return json_encode($v); }
class WP_Error { public $code; function __construct($c,...$a) { $this->code=$c; } }
class WP_REST_Response { public $data; function __construct($d) { $this->data=$d; } function header(...$a){} }
class WPAI_Logger {}
class WPAI_Diagnostics {
    function __construct(...$a){}
    function run() { return ['score'=>90,'checks'=>array_map(function($id) { return ['id'=>$id,'status'=>'healthy','message'=>'SECRET /private/path']; }, ['home','rest_api','database','https','disk','filesystem','cron','maintenance','updates','debug_log'])]; }
}
class Request { public $token; function __construct($t) {$this->token=$t;} function get_header($h) {return $this->token;} }
/** Minimal in-memory stand-in for $wpdb, just enough to exercise AAIHB_Beta's site_* queries. Not a substitute for real MySQL. */
class FakeWpdb {
    public $prefix = 'wp_'; public $rows = [];
    function prepare($sql, ...$args) {
        if (count($args) === 1 && is_array($args[0])) { $args = $args[0]; }
        $i = 0;
        return preg_replace_callback('/%[sd]/', function($m) use (&$i, $args) { $v = $args[$i++]; return $m[0] === '%d' ? (string)(int)$v : "'" . addslashes((string)$v) . "'"; }, $sql);
    }
    function get_charset_collate() { return ''; }
    function get_row($sql) { if (preg_match("/WHERE id = '([^']*)'/", $sql, $m)) { return isset($this->rows[$m[1]]) ? (object)array_merge(['id'=>$m[1]], $this->rows[$m[1]]) : null; } return null; }
    function get_var($sql) {
        if (strpos($sql, 'SELECT COUNT(*)') === 0) { return count($this->rows); }
        if (preg_match("/SELECT 1 FROM .*WHERE id = '([^']*)'/", $sql, $m)) { return isset($this->rows[$m[1]]) ? 1 : null; }
        return null;
    }
    function get_results($sql) {
        $rows = $this->rows; uasort($rows, function($a,$b) { return strcmp($b['updated_at'] ?? '', $a['updated_at'] ?? ''); });
        if (preg_match('/LIMIT (\d+) OFFSET (\d+)/', $sql, $m)) { $rows = array_slice($rows, (int)$m[2], (int)$m[1], true); }
        $out = []; foreach ($rows as $id=>$r) { $out[] = (object)array_merge(['id'=>$id], $r); } return $out;
    }
    function insert($table, $data) { $id = $data['id']; unset($data['id']); $this->rows[$id] = $data; }
    function update($table, $data, $where) { $id = $where['id']; if (isset($this->rows[$id])) { $this->rows[$id] = array_merge($this->rows[$id], $data); } }
    function delete($table, $where) { unset($this->rows[$where['id']]); }
}
$GLOBALS['wpdb'] = new FakeWpdb();
/* ==========================================================================
 * WordPress スタブ（0.20.45 追加）
 * このファイルは WordPress の外（CI の隔離ハーネス）でも実行されます。
 * 本体が呼ぶ WordPress 関数が未定義だと Fatal error で停止するため、
 * ここで最小限の代替を用意します。すべて function_exists ガード付きなので、
 * 実際の WordPress 上では本物の関数がそのまま使われます。
 * ========================================================================== */
$GLOBALS['transients'] = $GLOBALS['transients'] ?? [];
if (!function_exists('plugin_basename')) { function plugin_basename($f) { return basename($f); } }
if (!function_exists('plugin_dir_path')) { function plugin_dir_path($f) { return dirname($f).'/'; } }
if (!function_exists('plugin_dir_url')) { function plugin_dir_url($f) { return 'https://example.test/'; } }
if (!function_exists('plugins_url')) { function plugins_url($p='', $f='') { return 'https://example.test/'.$p; } }
if (!function_exists('admin_url')) { function admin_url($p='') { return 'https://example.test/wp-admin/'.ltrim((string)$p,'/'); } }
if (!function_exists('home_url')) { function home_url($p='') { return 'https://example.test'.$p; } }
if (!function_exists('site_url')) { function site_url($p='') { return 'https://example.test'.$p; } }
if (!function_exists('add_menu_page')) { function add_menu_page(...$a) { return 'hook'; } }
if (!function_exists('add_submenu_page')) { function add_submenu_page(...$a) { return 'hook'; } }
if (!function_exists('remove_menu_page')) { function remove_menu_page(...$a) { return true; } }
if (!function_exists('check_admin_referer')) { function check_admin_referer(...$a) { return true; } }
if (!function_exists('check_ajax_referer')) { function check_ajax_referer(...$a) { return true; } }
if (!function_exists('wp_verify_nonce')) { function wp_verify_nonce(...$a) { return true; } }
if (!function_exists('wp_create_nonce')) { function wp_create_nonce($a='') { return 'nonce'; } }
if (!function_exists('wp_nonce_field')) { function wp_nonce_field(...$a) { return ''; } }
if (!function_exists('current_user_can')) { function current_user_can(...$a) { return true; } }
if (!function_exists('get_current_user_id')) { function get_current_user_id() { return 1; } }
if (!function_exists('get_current_screen')) { function get_current_screen() { return null; } }
if (!function_exists('get_transient')) { function get_transient($k) { return $GLOBALS['transients'][$k] ?? false; } }
if (!function_exists('set_transient')) { function set_transient($k,$v,$e=0) { $GLOBALS['transients'][$k]=$v; return true; } }
if (!function_exists('delete_transient')) { function delete_transient($k) { unset($GLOBALS['transients'][$k]); return true; } }
if (!function_exists('sanitize_text_field')) { function sanitize_text_field($s) { return trim(strip_tags((string)$s)); } }
if (!function_exists('sanitize_textarea_field')) { function sanitize_textarea_field($s) { return trim(strip_tags((string)$s)); } }
if (!function_exists('sanitize_file_name')) { function sanitize_file_name($s) { return preg_replace('/[^A-Za-z0-9._-]/','-',(string)$s); } }
if (!function_exists('wp_unslash')) { function wp_unslash($s) { return is_string($s) ? stripslashes($s) : $s; } }
if (!function_exists('wp_date')) { function wp_date($f,$t=null) { return date($f,$t ?: time()); } }
if (!function_exists('submit_button')) { function submit_button(...$a) { return ''; } }
if (!function_exists('wp_safe_redirect')) { function wp_safe_redirect($u) { return true; } }
if (!function_exists('wp_redirect')) { function wp_redirect($u) { return true; } }
if (!function_exists('wp_safe_remote_get')) { function wp_safe_remote_get(...$a) { return new WP_Error('no_http'); } }
if (!function_exists('wp_safe_remote_post')) { function wp_safe_remote_post(...$a) { return new WP_Error('no_http'); } }
if (!function_exists('wp_safe_remote_request')) { function wp_safe_remote_request(...$a) { return new WP_Error('no_http'); } }
if (!function_exists('wp_remote_retrieve_body')) { function wp_remote_retrieve_body($r) { return ''; } }
if (!function_exists('wp_remote_retrieve_response_code')) { function wp_remote_retrieve_response_code($r) { return 0; } }
if (!function_exists('wp_remote_retrieve_headers')) { function wp_remote_retrieve_headers($r) { return []; } }
if (!function_exists('wp_remote_retrieve_header')) { function wp_remote_retrieve_header($r,$h) { return ''; } }
if (!function_exists('esc_html')) { function esc_html($s) { return htmlspecialchars((string)$s, ENT_QUOTES); } }
if (!function_exists('esc_attr')) { function esc_attr($s) { return htmlspecialchars((string)$s, ENT_QUOTES); } }
if (!function_exists('esc_js')) { function esc_js($s) { return (string)$s; } }
if (!function_exists('wp_kses_post')) { function wp_kses_post($s) { return (string)$s; } }
if (!function_exists('absint')) { function absint($v) { return abs((int)$v); } }
if (!function_exists('wp_die')) { function wp_die($m='') { throw new Exception('wp_die: '.(is_string($m)?$m:'') ); } }
if (!function_exists('did_action')) { function did_action($h) { return 0; } }
if (!function_exists('doing_action')) { function doing_action($h=null) { return false; } }
if (!function_exists('has_action')) { function has_action(...$a) { return false; } }
if (!function_exists('remove_action')) { function remove_action(...$a) { return true; } }
if (!function_exists('wp_next_scheduled')) { function wp_next_scheduled($h) { return false; } }
if (!function_exists('wp_schedule_event')) { function wp_schedule_event(...$a) { return true; } }
if (!function_exists('wp_schedule_single_event')) { function wp_schedule_single_event(...$a) { return true; } }
if (!function_exists('wp_unschedule_event')) { function wp_unschedule_event(...$a) { return true; } }
if (!function_exists('wp_clear_scheduled_hook')) { function wp_clear_scheduled_hook(...$a) { return true; } }
if (!function_exists('get_bloginfo')) { function get_bloginfo($k='') { return '6.8'; } }
if (!function_exists('wp_upload_dir')) { function wp_upload_dir() { return ['basedir'=>'/tmp','baseurl'=>'https://example.test/uploads','error'=>false]; } }
if (!function_exists('wp_mkdir_p')) { function wp_mkdir_p($d) { return is_dir($d) || @mkdir($d,0755,true); } }
if (!function_exists('trailingslashit')) { function trailingslashit($s) { return rtrim((string)$s,'/\\').'/'; } }
if (!function_exists('untrailingslashit')) { function untrailingslashit($s) { return rtrim((string)$s,'/\\'); } }
if (!function_exists('wp_get_theme')) { function wp_get_theme() { return null; } }
if (!function_exists('get_plugin_data')) { function get_plugin_data(...$a) { return []; } }
if (!function_exists('wp_enqueue_script')) { function wp_enqueue_script(...$a) {} }
if (!function_exists('wp_enqueue_style')) { function wp_enqueue_style(...$a) {} }
if (!function_exists('wp_register_script')) { function wp_register_script(...$a) { return true; } }
if (!function_exists('wp_localize_script')) { function wp_localize_script(...$a) { return true; } }
if (!function_exists('wp_add_inline_script')) { function wp_add_inline_script(...$a) { return true; } }
if (!function_exists('wp_add_inline_style')) { function wp_add_inline_style(...$a) { return true; } }
if (!function_exists('register_rest_route')) { function register_rest_route(...$a) { return true; } }
if (!function_exists('rest_authorization_required_code')) { function rest_authorization_required_code() { return 401; } }
if (!function_exists('is_admin')) { function is_admin() { return true; } }
if (!function_exists('wp_doing_ajax')) { function wp_doing_ajax() { return false; } }
if (!function_exists('wp_doing_cron')) { function wp_doing_cron() { return false; } }
if (!function_exists('get_site_option')) { function get_site_option($k,$d=false) { return get_option($k,$d); } }
if (!function_exists('update_site_option')) { function update_site_option($k,$v) { return update_option($k,$v); } }
if (!function_exists('wp_get_current_user')) { function wp_get_current_user() { return (object)['ID'=>1,'user_login'=>'tester']; } }
if (!function_exists('number_format_i18n')) { function number_format_i18n($n,$d=0) { return number_format((float)$n,$d); } }
if (!function_exists('wp_timezone_string')) { function wp_timezone_string() { return 'UTC'; } }
if (!function_exists('__')) { function __($s,$d=null) { return $s; } }
if (!function_exists('_e')) { function _e($s,$d=null) { echo $s; } }
if (!function_exists('_n')) { function _n($s,$p,$n,$d=null) { return $n==1 ? $s : $p; } }
if (!function_exists('_x')) { function _x($s,$c,$d=null) { return $s; } }
if (!function_exists('esc_html__')) { function esc_html__($s,$d=null) { return htmlspecialchars((string)$s, ENT_QUOTES); } }
if (!function_exists('esc_attr__')) { function esc_attr__($s,$d=null) { return htmlspecialchars((string)$s, ENT_QUOTES); } }
if (!function_exists('esc_html_e')) { function esc_html_e($s,$d=null) { echo htmlspecialchars((string)$s, ENT_QUOTES); } }
if (!function_exists('esc_attr_e')) { function esc_attr_e($s,$d=null) { echo htmlspecialchars((string)$s, ENT_QUOTES); } }
if (!function_exists('load_plugin_textdomain')) { function load_plugin_textdomain(...$a) { return true; } }
require dirname(__DIR__).'/autorepair-ai-hosting-beta.php';
$count=0;
function check($yes,$label) { global $count; if(!$yes) {throw new Exception('FAIL: '.$label);} $count++; echo 'PASS '.$label."\n"; }
$token=str_repeat('a',64); $request=new Request($token);
check(AAIHB_Beta::authenticate($request) instanceof WP_Error,'disabled Agent rejects token');
update_option(AAIHB_Beta::SETTINGS,['agent'=>1,'hash'=>hash('sha256',$token)]);
check(AAIHB_Beta::authenticate($request)===true,'valid token accepted');
check(AAIHB_Beta::authenticate(new Request(str_repeat('b',64))) instanceof WP_Error,'wrong token rejected');
$ssl=false; check(AAIHB_Beta::authenticate($request) instanceof WP_Error,'HTTP rejected'); $ssl=true;
$r=AAIHB_Beta::agent_scan(); check($r instanceof WP_REST_Response,'read-only scan returns report');
check(strpos(json_encode($r->data),'SECRET')===false,'private details stripped');
check(AAIHB_Beta::validate_report($r->data),'valid response accepted');
$verified=['status'=>'passed','checks'=>['files'=>true,'database'=>true,'homepage'=>true,'wordpress'=>true,'cleanup'=>true],'finished_at'=>gmdate('c')];
$evidence=AAIHB_RecoveryEvidence::score($verified); check($evidence['score']===100 && $evidence['fresh']===true,'signed restore checks produce a fresh 100 recovery score');
$unverified=['status'=>'failed','checks'=>['files'=>true]]; check(AAIHB_RecoveryEvidence::score($unverified)['score']===0,'failed restore test never receives a recovery score');
check(AAIHB_VaultDB::supported_server('8.4.3'),'MySQL 8 is accepted for full backup');
check(AAIHB_VaultDB::supported_server('10.5.26-MariaDB'),'MariaDB 10.5 is accepted for full backup');
check(!AAIHB_VaultDB::supported_server('10.4.33-MariaDB'),'older MariaDB is rejected for full backup');
$matrix=AAIHB_Verification::matrix(['available'=>true,'jobs'=>['central'=>'success','unit'=>'success','restore'=>'success','stripe'=>'skipped','load'=>'skipped']]);$states=array_column($matrix,'state','key');
check($states['install']==='passed'&&$states['upgrade']==='passed'&&$states['rollback']==='passed','verification matrix maps successful install update and rollback evidence');
check($states['stripe']==='pending'&&$states['paddle']==='preparing'&&$states['load']==='pending','verification matrix never marks optional billing or load work as passed when skipped');
$bad=$r->data; $bad['checks'][1]=$bad['checks'][0]; check(!AAIHB_Beta::validate_report($bad),'duplicate check rejected');
$bad=$r->data; $bad['score']=101; check(!AAIHB_Beta::validate_report($bad),'invalid score rejected');
$bad=$r->data; $bad['checks'][0]['status']='html'; check(!AAIHB_Beta::validate_report($bad),'invalid status rejected');
check(AAIHB_Beta::agent_scan() instanceof WP_Error,'rapid repeat scan rejected');
delete_option('aaihb_last_scan'); add_option('aaihb_scan_lock',time());
check(AAIHB_Beta::agent_scan() instanceof WP_Error,'concurrent scan rejected'); delete_option('aaihb_scan_lock');
check(AAIHB_Beta::endpoint('https://public.example/sub/wp-json/aaihb/v1/scan')!==false,'subdirectory endpoint accepted');
check(AAIHB_Beta::endpoint('https://public.example/sub/?rest_route=%2Faaihb%2Fv1%2Fscan')!==false,'plain permalink endpoint accepted');
check(AAIHB_Beta::endpoint('http://public.example/wp-json/aaihb/v1/scan')===false,'HTTP endpoint rejected');
check(AAIHB_Beta::endpoint('https://user:pass@public.example/wp-json/aaihb/v1/scan')===false,'URL credentials rejected');
check(AAIHB_Beta::endpoint('https://public.example/wp-json/aaihb/v1/scan?extra=1')===false,'unexpected query rejected');
if(function_exists('openssl_encrypt')) {
    $enc=AAIHB_Beta::crypt($token); check(AAIHB_Beta::crypt($enc,true)===$token,'encrypted token round trip');
    $bytes=base64_decode($enc); $bytes[20]=chr(ord($bytes[20])^1); $rejected=false;
    try {AAIHB_Beta::crypt(base64_encode($bytes),true);} catch(Throwable $e) {$rejected=true;}
    check($rejected,'tampered encrypted token rejected');
}
check(AAIHB_Beta::site('missing')===null,'unknown site id returns null');
check(AAIHB_Beta::sites_count()===0,'fresh registry is empty');
AAIHB_Beta::site_put('id1',['name'=>'Site One','endpoint'=>'https://a.example/wp-json/aaihb/v1/scan','token'=>'tok1','report'=>null,'error'=>'','attempt'=>'']);
check(AAIHB_Beta::sites_exists('id1'),'inserted site exists');
check(AAIHB_Beta::sites_count()===1,'count reflects one insert');
check(AAIHB_Beta::site('id1')['name']==='Site One','stored site round-trips through the table');
AAIHB_Beta::site_put('id1',['name'=>'Renamed','endpoint'=>'https://a.example/wp-json/aaihb/v1/scan','token'=>'tok1','report'=>['score'=>80,'checks'=>[]],'error'=>'','attempt'=>'2026-01-01T00:00:00Z']);
check(AAIHB_Beta::sites_count()===1,'re-registering the same id updates rather than duplicates');
check(AAIHB_Beta::site('id1')['name']==='Renamed' && AAIHB_Beta::site('id1')['report']['score']===80,'update overwrites fields including nested report JSON');
for ($i=2; $i<=6; $i++) { AAIHB_Beta::site_put('id'.$i,['name'=>'Site '.$i,'endpoint'=>'https://a.example/wp-json/aaihb/v1/scan','token'=>'t','report'=>null,'error'=>'','attempt'=>'']); }
check(AAIHB_Beta::sites_count()===6,'six sites registered');
check(count(AAIHB_Beta::sites())===6,'sites() returns the full registry');
check(count(AAIHB_Beta::sites_page(0,4))===4 && count(AAIHB_Beta::sites_page(4,4))===2,'sites_page paginates without loading everything at once');
AAIHB_Beta::site_delete('id1');
check(!AAIHB_Beta::sites_exists('id1') && AAIHB_Beta::sites_count()===5,'delete removes exactly one row');
try { AAIHB_Billing::assert_registration('brand-new-id'); $blocked_unconfigured=false; } catch (Throwable $e) { $blocked_unconfigured=true; }
check($blocked_unconfigured,'new registration blocked until central billing is connected');
update_option('aaihb_central_suspended',true);
try { AAIHB_Billing::assert_registration('another-new-id'); $blocked=false; } catch (Throwable $e) { $blocked=true; }
check($blocked,'new registration blocked while central reports suspension');
try { AAIHB_Billing::assert_registration('id2'); $existing_ok=true; } catch (Throwable $e) { $existing_ok=false; }
check($existing_ok,'re-registering an already-registered site is still allowed while suspended');
update_option('aaihb_central_suspended',false);
try { AAIHB_Billing::assert_registration('yet-another-new-id'); $blocked2=false; } catch (Throwable $e) { $blocked2=true; }
check($blocked2,'new registration remains blocked until central billing authorizes it');
echo $count." tests passed\n";
