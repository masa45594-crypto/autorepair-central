<?php
// Destructive, disposable WordPress ONLY. Fake provider tests, not live payment tests.
if(!defined('AAIHB_TESTING')||!AAIHB_TESTING)exit;
define('AAIHB_PRODUCT_ID',123);define('AAIHB_PRODUCT_PUBLIC_KEY','pk_test');
class AAIHB_FakeCommerce {
 public $paid=true,$plan='agency_starter',$error=false,$product=123;
 function get_id(){if($this->error)throw new RuntimeException('secret provider error');return $this->product;}
 function is_paying(){return $this->paid;} function is_plan($p,$exact){if(!$exact)throw new RuntimeException('must be exact');return $p===$this->plan;}
 function get_upgrade_url(){return 'https://8.8.8.8/checkout';} function get_account_url(){return 'https://8.8.8.8/account';}
}
$GLOBALS['aaihb_commerce']=new AAIHB_FakeCommerce();
require_once ABSPATH.'wp-admin/includes/plugin.php';require_once ABSPATH.'wp-admin/includes/template.php';wp_set_current_user(1);$_SERVER['HTTPS']='on';activate_plugin('autorepair-ai-hosting-beta/autorepair-ai-hosting-beta.php');AAIHB_Beta::upgrade();AAIHB_Value::init();AAIHB_Fleet::init();
$n=0;function bcheck($ok,$label){global $n;if(!$ok)throw new RuntimeException('FAIL '.$label);$n++;echo "PASS $label\n";}function breject($f,$label){try{$f();}catch(Throwable $e){bcheck(true,$label);return;}bcheck(false,$label);}
$fs=$GLOBALS['aaihb_commerce'];$report=['protocol'=>1,'score'=>100,'generated_at'=>gmdate('c'),'checks'=>array_map(function($id){return ['id'=>$id,'status'=>'healthy'];},['home','rest_api','database','https','disk','filesystem','cron','maintenance','updates','debug_log'])];
$GLOBALS['billing_http_calls']=0;add_filter('pre_http_request',function()use($report){$GLOBALS['billing_http_calls']++;return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($report)];});
bcheck(AAIHB_Billing::state()['limit']===10,'active starter exact plan gives ten');
for($i=0;$i<10;$i++)AAIHB_Beta::site_put('fixture'.$i,['name'=>'Fixture','endpoint'=>'https://8.8.8.8/wp-json/aaihb/v1/scan','token'=>AAIHB_Beta::crypt(str_repeat('a',64)),'report'=>$report,'error'=>'','attempt'=>'']);
AAIHB_Billing::meter();bcheck(AAIHB_Billing::usage()['current']===10,'database count');breject(function(){AAIHB_Billing::assert_registration('new');},'ten-site limit enforced');AAIHB_Billing::assert_registration('fixture0');bcheck(true,'existing credential replacement allowed');
$pack=wp_json_encode(['format'=>'aaihb-connect-1','name'=>'New','endpoint'=>'https://8.8.8.8/wp-json/aaihb/v1/scan','token'=>str_repeat('a',64)]);
breject(function()use($pack){AAIHB_Selfserve::connect($pack,false);},'paste registration also enforces cap');bcheck(!get_option('aaihb_registry_lock'),'lock released on rejection');
$fs->plan='agency';bcheck(AAIHB_Billing::state()['limit']===50,'upgrade changes allowance without stored override');$r=AAIHB_Selfserve::connect($pack,false);bcheck($r['ok'],'registration succeeds after upgrade');bcheck(AAIHB_Billing::usage()['peak']===11,'peak increases');
$fs->plan='agency_starter';breject(function(){AAIHB_Billing::assert_registration('new');},'downgrade prevents new additions');bcheck(AAIHB_Beta::sites_count()===11,'downgrade never deletes sites');bcheck(AAIHB_Billing::scan_error()===null,'active downgrade preserves diagnosis');
$fs->paid=false;$calls=$GLOBALS['billing_http_calls'];bcheck(is_wp_error(AAIHB_Beta::scan_site('fixture0')),'inactive licence blocks Hub diagnosis');bcheck($calls===$GLOBALS['billing_http_calls'],'blocked scan sends no request');breject(function(){AAIHB_Billing::assert_registration('new');},'inactive cannot add');bcheck(AAIHB_Beta::site('fixture0')['report']['score']===100,'history preserved');
AAIHB_Beta::site_delete('fixture0');AAIHB_Billing::meter();bcheck(AAIHB_Billing::usage()['current']===10&&AAIHB_Billing::usage()['peak']===11,'delete lowers current not monthly peak');
$fs->paid=true;$fs->plan='unknown';bcheck(AAIHB_Billing::state()['status']==='unknown_plan','unknown plan fails closed');$fs->plan='agency';$fs->error=true;bcheck(!AAIHB_Billing::state()['scan'],'SDK exception fails closed');$fs->error=false;$fs->product=999;bcheck(!AAIHB_Billing::state()['scan'],'other product rejected');$fs->product=123;
$_POST=['limit'=>999999,'plan'=>'white_label','status'=>'active'];update_option('aaihb_store',['limit'=>999999]);bcheck(AAIHB_Billing::state()['limit']===50,'client options cannot change allowance');
foreach(['active','inactive','unknown_plan'] as $state){$fs->paid=$state!=='inactive';$fs->plan=$state==='unknown_plan'?'unknown':'agency';ob_start();AAIHB_Billing::page();$h=ob_get_clean();file_put_contents('/qa/billing-'.$state.'.html',$h);bcheck(strpos($h,'pk_test')===false,'no public configuration dumped '.$state);}
$fs->paid=true;$fs->plan='agency';
add_filter('wp_die_handler',function(){return function(){throw new RuntimeException('Denied');};});wp_set_current_user(wp_create_user('billing_reader','test-only-password'));breject(function(){AAIHB_Billing::page();},'non-admin cannot access billing');
echo "TOTAL $n checks passed\n";
