<?php
/**
 * 無料枠（10サイトまで全機能・期間制限なし）と、Proアップグレードへの導線。
 * 旧 7日間フルトライアル（0.20.53まで）を置き換えるファイルです。
 *
 * ■ 料金（中央サービスの設定と合わせています）
 *   無料枠: 管理サイト10件まで 全機能が無料（期間制限なし）
 *   Pro:    月額 $29.00（管理サイト10件まで）／11件目から 1件あたり $3.00
 *
 * ■ 11サイト目を追加しようとした瞬間に、アップグレード画面で
 *   「事前確認（現在の件数と料金）→ 同意 → 申し込み」の順で案内します。
 */
if (!defined('ABSPATH')) { exit; }

final class AAIHB_Trial {

    /* ==========================================================
     * ここを書き換える
     * ========================================================== */

    /** 購入ページのURL。例：https://your-store.example/checkout/aaihb */
    const CHECKOUT_URL = 'https://autorepair-central-1.onrender.com/signup';

    /** 契約管理（ポータル）のURL。例：https://your-store.example/account */
    const PORTAL_URL = 'https://billing.stripe.com/p/login/bJe14odqDbKO3wwcyD1sQ00';

    /** ライセンス検証APIのURL。Freemius / Lemon Squeezy / EDD のいずれか。 */
    const LICENSE_API = 'https://autorepair-central-1.onrender.com/v1/usage';

    /** 決済サービスの表示名。 */
    const PAYMENT_BACKEND = 'Stripe';

    /* ========================================================== */

    /** 無料枠に含まれる管理サイト数（期間制限なし・全機能）。 */
    const INCLUDED_SITES = 10;

    /** Pro の月額（米ドル）。 */
    const BASE_USD = 29.00;

    /** 11件目からの1件あたり単価（米ドル）。 */
    const UNIT_USD = 3.00;

    const OPT_LICENSE = 'aaihb_trial_license';
    const OPT_CONSENT = 'aaihb_pro_consent';

    /** 無料枠を超えた後に閉じる操作。ここに無い操作は無料のまま使えます。 */
    const PREMIUM_ACTIONS = [
        'aaihb_central', 'aaihb_certificate', 'aaihb_control_center', 'aaihb_csv',
        'aaihb_fleet', 'aaihb_history_csv', 'aaihb_notify', 'aaihb_notify_clear',
        'aaihb_notify_clear_webhook', 'aaihb_ops', 'aaihb_ops_csv', 'aaihb_partner',
        'aaihb_recovery', 'aaihb_repair', 'aaihb_selfserve', 'aaihb_service_check',
        'aaihb_stripe_test_checkout', 'aaihb_stripe_test_portal', 'aaihb_value',
        'aaihb_verification_refresh',
    ];

    /** 無料枠を超えた後に閉じる画面。 */
    const PREMIUM_PAGES = [
        'aaihb-fleet', 'aaihb-ops', 'aaihb-partner', 'aaihb-notify', 'aaihb-recovery',
        'aaihb-value', 'aaihb-verification', 'aaihb-service-checks', 'aaihb-buy',
    ];

    /* ==========================================================
     * 起動
     * ========================================================== */

    public static function boot() {
        add_action('admin_init', [__CLASS__, 'verify_quiet'], 0);
        add_action('admin_init', [__CLASS__, 'block'], 1);
        add_action('admin_menu', [__CLASS__, 'menu'], 99);
        add_action('admin_notices', [__CLASS__, 'notice']);
        add_action('admin_post_aaihb_upgrade', [__CLASS__, 'save']);
        add_action('admin_post_aaihb_pro_consent', [__CLASS__, 'save_consent']);
        add_action('admin_post_aaihb_license_verify', [__CLASS__, 'verify_now']);
        add_filter('rest_authentication_errors', [__CLASS__, 'block_rest']);
        add_filter('plugin_action_links_' . plugin_basename(AAIHB_PLUGIN_FILE), [__CLASS__, 'row_link']);
    }

    /** プラグイン一覧（この画面）に行を追加する。 */
    public static function row_link($links) {
        $label = self::licensed() ? __('ライセンス', 'autorepair-ai-hosting-beta') : __('アップグレード', 'autorepair-ai-hosting-beta');
        $links['aaihb_upgrade'] = '<a href="' . esc_url(admin_url('admin.php?page=aaihb-upgrade')) . '" style="font-weight:600">' . esc_html($label) . '</a>';
        return $links;
    }

    /* ==========================================================
     * 状態の計算
     * ========================================================== */

    public static function consented() { return (int) get_option(self::OPT_CONSENT, 0) > 0; }

    /* ==========================================================
     * ライセンス
     * ========================================================== */

    public static function license() {
        $l = get_option(self::OPT_LICENSE, []);
        return wp_parse_args(is_array($l) ? $l : [], ['key' => '', 'active' => false, 'checked' => 0, 'reachable' => false]);
    }
    public static function licensed() { $l = self::license(); return !empty($l['active']); }

    /** 中央サービスへ問い合わせて、契約が有効かを確認する（未接続なら何もしない）。 */
    public static function verify($force = false) {
        $l = self::license();
        if (!class_exists('AAIHB_Central') || !AAIHB_Central::configured()) {
            if ($force) { $l['checked'] = time(); update_option(self::OPT_LICENSE, $l, false); }
            return $l;
        }
        if (!$force && $l['checked'] && (time() - (int) $l['checked']) < 6 * HOUR_IN_SECONDS) { return $l; }
        $s = AAIHB_Central::settings();
        try {
            $token = AAIHB_Beta::crypt($s['token'], true);
        } catch (Throwable $e) {
            /* 復号できないトークン（移行・ソルト変更など）で管理画面全体を
               落とさないよう、通信不可と同じ扱いにして前回の判定を保ちます。 */
            $l['checked'] = time();
            $l['reachable'] = false;
            update_option(self::OPT_LICENSE, $l, false);
            return $l;
        }
        $r = wp_safe_remote_get(self::LICENSE_API, [
            'timeout' => 15, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 16000,
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
        ]);
        $l['checked'] = time();
        if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) {
            $d = json_decode(wp_remote_retrieve_body($r), true);
            $l['active'] = is_array($d) && ($d['mode'] ?? '') === 'live' && ($d['billable'] ?? null) === true;
            $l['reachable'] = true;
        } else {
            /* 通信できなかっただけのときは、前回の判定をそのまま保ちます。
               一時的な障害で、お支払い済みのお客様の機能を止めないためです。 */
            $l['reachable'] = false;
        }
        update_option(self::OPT_LICENSE, $l, false);
        return $l;
    }

    /** 管理画面を開いたときに静かに確認する（6時間に1回まで）。 */
    public static function verify_quiet() { self::verify(false); }

    /** 管理画面からの「契約状態を今すぐ確認する」。 */
    public static function verify_now() {
        if (class_exists('AAIHB_Beta')) { AAIHB_Beta::allowed(); }
        check_admin_referer('aaihb_license_verify');
        self::verify(true);
        wp_safe_redirect(admin_url('admin.php?page=aaihb-upgrade#aaihb-license'));
        exit;
    }

    /** 全機能が使えるか。無料枠内（10サイト以下）または有効なライセンスがあれば true。 */
    public static function unlocked() { return self::sites_count() <= self::INCLUDED_SITES || self::licensed(); }

    /** 無料枠を超えているか（11サイト目以上）。 */
    public static function over_limit() { return self::sites_count() > self::INCLUDED_SITES; }

    public static function status_label() {
        if (self::licensed()) { return __('ライセンス有効（全機能）', 'autorepair-ai-hosting-beta'); }
        if (!self::over_limit()) {
            return sprintf(__('無料枠内：全機能が無料で使えます（%d / %d サイト）', 'autorepair-ai-hosting-beta'), self::sites_count(), self::INCLUDED_SITES);
        }
        return __('無料枠（10サイト）を超えました（Proへアップグレードで全機能を再開できます）', 'autorepair-ai-hosting-beta');
    }

    /* ==========================================================
     * 料金の計算
     * ========================================================== */

    /** この画面が把握している管理サイト数。正式な件数は中央サービス側で数えます。 */
    public static function sites_count() {
        if (class_exists('AAIHB_Beta') && method_exists('AAIHB_Beta', 'sites_count')) {
            try { return max(0, (int) AAIHB_Beta::sites_count()); } catch (Throwable $e) { return 0; }
        }
        return 0;
    }
    public static function overage_sites($count) { return max(0, (int) $count - self::INCLUDED_SITES); }
    public static function monthly_usd($count) { return self::BASE_USD + self::overage_sites($count) * self::UNIT_USD; }
    public static function money($usd) { return '$' . number_format((float) $usd, 2); }

    /* ==========================================================
     * 無料枠超過後の制限
     * ========================================================== */

    /** 有料の操作と画面だけを止める。画面は壊さず、データも消しません。 */
    public static function block() {
        if (self::unlocked()) { return; }
        $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : '';
        if ($action !== '' && in_array($action, self::PREMIUM_ACTIONS, true)) {
            self::to_upgrade(sprintf(__('操作「%s」', 'autorepair-ai-hosting-beta'), $action));
        }
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page !== '' && in_array($page, self::PREMIUM_PAGES, true)) {
            self::to_upgrade(sprintf(__('画面「%s」', 'autorepair-ai-hosting-beta'), $page));
        }
    }
    private static function to_upgrade($what) {
        set_transient('aaihb_trial_blocked_' . get_current_user_id(), $what, 120);
        wp_safe_redirect(admin_url('admin.php?page=aaihb-upgrade'));
        exit;
    }

    /** エージェント／パートナー向けAPIも閉じる。 */
    public static function block_rest($result) {
        if (is_wp_error($result) || self::unlocked()) { return $result; }
        $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
        $q = isset($_GET['rest_route']) ? (string) $_GET['rest_route'] : '';
        if (strpos($uri, '/aaihb/v1/') !== false || strpos($q, '/aaihb/v1/') === 0) {
            return new WP_Error('aaihb_free_limit', __('無料枠（10サイト）を超えています。Proへアップグレードしてください。', 'autorepair-ai-hosting-beta'), ['status' => 402]);
        }
        return $result;
    }

    /** 管理画面の上に出す案内（この画面＝プラグイン一覧にも出ます）。 */
    public static function notice() {
        if (!current_user_can('manage_options')) { return; }
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $id = $screen ? (string) $screen->id : '';
        if (strpos($id, 'aaihb') === false && $id !== 'plugins') { return; }
        $url = admin_url('admin.php?page=aaihb-upgrade');
        if (self::licensed()) { return; }
        if (self::over_limit()) {
            echo '<div class="notice notice-warning" style="background:#fcf9e8 !important;border-left:4px solid #dba617 !important;color:#1d2327 !important"><p style="color:#1d2327 !important"><strong style="color:#8a5b00 !important">'
                . esc_html__('管理サイトが無料枠（10サイト）を超えています。', 'autorepair-ai-hosting-beta') . '</strong> '
                . esc_html__('診断と履歴の閲覧はそのまま使えます。新規サイトの追加・一括管理・復旧・通知などの操作を再開するには、Proへのアップグレードが必要です。', 'autorepair-ai-hosting-beta') . ' '
                . '<a class="button button-primary" href="' . esc_url($url . '#aaihb-signup') . '">' . esc_html__('アップグレードを確認する', 'autorepair-ai-hosting-beta') . '</a></p></div>';
            return;
        }
        echo '<div class="notice notice-info" style="background:#e7f3ff !important;border-left:4px solid #2271b1 !important;color:#1d2327 !important"><p style="color:#1d2327 !important"><strong style="color:#0a4b78 !important">'
            . esc_html(sprintf(__('無料枠：%d / %d サイト（全機能・期間制限なし）', 'autorepair-ai-hosting-beta'), self::sites_count(), self::INCLUDED_SITES)) . '</strong> — '
            . esc_html(sprintf(__('11サイト目からは月額 %s（管理サイト10件まで）＋11件目から1件 %s です。', 'autorepair-ai-hosting-beta'), self::money(self::BASE_USD), self::money(self::UNIT_USD))) . ' '
            . '<a href="' . esc_url($url . '#aaihb-signup') . '" style="color:#2271b1 !important;font-weight:600;text-decoration:underline">' . esc_html__('料金と申し込み', 'autorepair-ai-hosting-beta') . '</a></p></div>';
    }

    /* ==========================================================
     * アップグレード画面
     * ========================================================== */

    public static function menu() {
        $parent = '';
        foreach (['aaihb-home', 'aaihb'] as $candidate) {
            if (isset($GLOBALS['admin_page_hooks'][$candidate])) { $parent = $candidate; break; }
        }
        if ($parent === '') { return; }
        add_submenu_page($parent, __('アップグレード', 'autorepair-ai-hosting-beta'), __('アップグレード', 'autorepair-ai-hosting-beta'), 'manage_options', 'aaihb-upgrade', [__CLASS__, 'page']);
    }

    public static function page() {
        if (class_exists('AAIHB_Beta')) { AAIHB_Beta::allowed(); }
        $l = self::license();
        $blocked = get_transient('aaihb_trial_blocked_' . get_current_user_id());
        delete_transient('aaihb_trial_blocked_' . get_current_user_id());
        $count = self::sites_count();

        echo '<div class="wrap"><h1>' . esc_html__('アップグレード', 'autorepair-ai-hosting-beta') . '</h1>';
        echo '<p><strong>' . esc_html(self::status_label()) . '</strong></p>';
        if ($blocked) {
            echo '<div class="notice notice-warning"><p>'
                . esc_html(sprintf(__('%s は無料枠（10サイト）の対象外です。Proへアップグレードすると使えます。', 'autorepair-ai-hosting-beta'), $blocked))
                . '</p></div>';
        }

        /* 無料枠の状況 */
        echo '<h2>' . esc_html__('1. 無料枠の状況', 'autorepair-ai-hosting-beta') . '</h2>';
        echo '<table class="widefat striped" style="max-width:820px"><tbody>';
        echo '<tr><td>' . esc_html__('管理サイト数（この画面の登録数）', 'autorepair-ai-hosting-beta') . '</td><td>' . (int) $count . ' ' . esc_html__('件', 'autorepair-ai-hosting-beta') . '</td></tr>';
        echo '<tr><td>' . esc_html__('無料枠', 'autorepair-ai-hosting-beta') . '</td><td>' . (int) self::INCLUDED_SITES . ' ' . esc_html__('件まで（全機能・期間制限なし）', 'autorepair-ai-hosting-beta') . '</td></tr>';
        echo '<tr><td>' . esc_html__('無料枠の状態', 'autorepair-ai-hosting-beta') . '</td><td>'
            . (self::over_limit()
                ? '<span style="color:#b32d2e;font-weight:600">' . esc_html__('超過（有料の操作のみ停止中）', 'autorepair-ai-hosting-beta') . '</span>'
                : '<span style="color:#00a32a;font-weight:600">' . esc_html__('枠内（全機能が使えます）', 'autorepair-ai-hosting-beta') . '</span>') . '</td></tr>';
        echo '</tbody></table>';
        echo '<p>' . esc_html__('無料枠には期限がありません。11サイト目を追加しようとしたときに、下の「Proへのアップグレード」案内に切り替わります。', 'autorepair-ai-hosting-beta') . '</p>';

        /* 使用量と料金 */
        echo '<h2>' . esc_html__('2. 使用量と今月の料金', 'autorepair-ai-hosting-beta') . '</h2>';
        echo '<table class="widefat striped" style="max-width:820px"><tbody>';
        echo '<tr><td>' . esc_html__('管理サイト数（この画面の登録数）', 'autorepair-ai-hosting-beta') . '</td><td>' . (int) $count . ' ' . esc_html__('件', 'autorepair-ai-hosting-beta') . '</td></tr>';
        echo '<tr><td>' . esc_html__('無料枠・月額に含まれる件数', 'autorepair-ai-hosting-beta') . '</td><td>' . (int) self::INCLUDED_SITES . ' ' . esc_html__('件', 'autorepair-ai-hosting-beta') . '</td></tr>';
        echo '<tr><td>' . esc_html__('超過分', 'autorepair-ai-hosting-beta') . '</td><td>' . (int) self::overage_sites($count) . ' ' . esc_html__('件 × ', 'autorepair-ai-hosting-beta') . esc_html(self::money(self::UNIT_USD)) . '</td></tr>';
        echo '<tr><td><strong>' . esc_html__('Pro契約時の見込み', 'autorepair-ai-hosting-beta') . '</strong></td><td><strong>' . esc_html(self::money(self::monthly_usd($count))) . '</strong> / ' . esc_html__('月', 'autorepair-ai-hosting-beta') . '</td></tr>';
        echo '</tbody></table>';
        echo '<p>' . esc_html(sprintf(__('例：12件なら %s ＋ 2件 × %s ＝ %s。', 'autorepair-ai-hosting-beta'), self::money(self::BASE_USD), self::money(self::UNIT_USD), self::money(self::BASE_USD + 2 * self::UNIT_USD))) . '</p>';
        echo '<p>' . esc_html__('正式な件数と請求は、契約サーバー（中央サービス）側でStripeにより確定します。この画面の数字は目安です。', 'autorepair-ai-hosting-beta') . '</p>';

        /* プラン比較 */
        echo '<h2>' . esc_html__('3. プラン', 'autorepair-ai-hosting-beta') . '</h2>';
        echo '<table class="widefat striped" style="max-width:820px"><thead><tr><th>' . esc_html__('内容', 'autorepair-ai-hosting-beta')
            . '</th><th>' . esc_html__('無料枠（10サイトまで）', 'autorepair-ai-hosting-beta') . '</th><th>' . esc_html__('Pro（有料プラン）', 'autorepair-ai-hosting-beta') . '</th></tr></thead><tbody>';
        $rows = [
            [__('月額', 'autorepair-ai-hosting-beta'), __('無料（期間制限なし）', 'autorepair-ai-hosting-beta'), self::money(self::BASE_USD)],
            [__('管理サイト数', 'autorepair-ai-hosting-beta'), sprintf(__('%d件まで（全機能）', 'autorepair-ai-hosting-beta'), self::INCLUDED_SITES), sprintf(__('%d件まで（11件目から1件 %s）', 'autorepair-ai-hosting-beta'), self::INCLUDED_SITES, self::money(self::UNIT_USD))],
            [__('診断・スコア', 'autorepair-ai-hosting-beta'), '✓', '✓'],
            [__('バックアップ・復元', 'autorepair-ai-hosting-beta'), '✓', '✓'],
            [__('自動修復・限定修復', 'autorepair-ai-hosting-beta'), '✓', '✓'],
            [__('複数サイトの一括管理', 'autorepair-ai-hosting-beta'), '✓', '✓'],
            [__('Slack・メール通知', 'autorepair-ai-hosting-beta'), '✓', '✓'],
            [__('隔離環境での復旧リハーサル', 'autorepair-ai-hosting-beta'), '✓', '✓'],
            [__('パートナー向けAPI', 'autorepair-ai-hosting-beta'), '✓', '✓'],
            [__('11サイト目以上の追加', 'autorepair-ai-hosting-beta'), '—', '✓'],
        ];
        foreach ($rows as $r) {
            echo '<tr><td>' . esc_html($r[0]) . '</td><td>' . esc_html($r[1]) . '</td><td>' . esc_html($r[2]) . '</td></tr>';
        }
        echo '</tbody></table>';

        /* 申し込み（事前確認 → 同意 → 申し込み） */
        echo '<h2 id="aaihb-signup">' . esc_html__('4. Proへのアップグレード（事前確認と同意）', 'autorepair-ai-hosting-beta') . '</h2>';
        if (self::CHECKOUT_URL !== '') {
            if (!self::consented()) {
                echo '<div style="max-width:820px;padding:12px 16px;border:1px solid #dba617;background:#fcf9e8">';
                echo '<p><strong>' . esc_html__('事前確認', 'autorepair-ai-hosting-beta') . '</strong></p>';
                echo '<ul style="list-style:disc;padding-left:20px">';
                echo '<li>' . esc_html(sprintf(__('現在の管理サイト数：%d 件（無料枠は %d 件まで）', 'autorepair-ai-hosting-beta'), $count, self::INCLUDED_SITES)) . '</li>';
                echo '<li>' . esc_html(sprintf(__('Proの料金：月額 %s（管理サイト10件まで）＋11件目から1件あたり %s', 'autorepair-ai-hosting-beta'), self::money(self::BASE_USD), self::money(self::UNIT_USD))) . '</li>';
                echo '<li>' . esc_html__('請求はStripe（お申し込みと同時に開始）、契約はいつでも解約できます。', 'autorepair-ai-hosting-beta') . '</li>';
                echo '</ul>';
                echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
                echo '<input type="hidden" name="action" value="aaihb_pro_consent">';
                wp_nonce_field('aaihb_pro_consent');
                echo '<p><label><input type="checkbox" name="agree" value="1" required> ' . esc_html__('上記の料金と請求開始のタイミングを確認し、Proへのアップグレードに同意します。', 'autorepair-ai-hosting-beta') . '</label></p>';
                submit_button(__('同意して申し込みへ進む', 'autorepair-ai-hosting-beta'), 'primary', 'submit', false);
                echo '</form></div>';
            } else {
                echo '<p><strong style="color:#00a32a">' . esc_html__('アップグレードに同意済みです。', 'autorepair-ai-hosting-beta') . '</strong> '
                    . esc_html(wp_date(__('Y年n月j日 H:i', 'autorepair-ai-hosting-beta'), (int) get_option(self::OPT_CONSENT))) . '</p>';
                echo '<p><a class="button button-primary button-hero" href="' . esc_url(self::CHECKOUT_URL) . '" target="_blank" rel="noopener">'
                    . esc_html__('Proを申し込む（Stripe決済）', 'autorepair-ai-hosting-beta') . '</a></p>';
            }
            echo '<p class="description">' . esc_html__('はじめてのお申し込みは、上のボタンからお進みください（新規契約）。すでにご契約中で、解約・支払い方法の変更・請求書の確認をご希望の場合は、次のリンクからお進みください。', 'autorepair-ai-hosting-beta') . '</p>';
            if (self::PORTAL_URL !== '') {
                echo '<p><a href="' . esc_url(self::PORTAL_URL) . '" target="_blank" rel="noopener">'
                    . esc_html__('契約と支払いを確認する（すでにご契約中の方）', 'autorepair-ai-hosting-beta') . '</a></p>';
            }
        } else {
            echo '<div class="notice notice-error" style="max-width:820px"><p><strong>'
                . esc_html__('購入ページのURLが未設定です。', 'autorepair-ai-hosting-beta') . '</strong><br>'
                . esc_html__('trial.php の CHECKOUT_URL / PORTAL_URL / LICENSE_API の3か所を書き換えてください。未設定の間は、このボタンは表示されません（決済は行いません）。', 'autorepair-ai-hosting-beta') . '</p></div>';
        }

        /* ライセンス登録 */
        echo '<h2 id="aaihb-license">' . esc_html__('5. ライセンスキーの登録', 'autorepair-ai-hosting-beta') . '</h2>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="aaihb_upgrade">';
        wp_nonce_field('aaihb_upgrade');
        echo '<p><input type="text" class="regular-text" name="license" autocomplete="off" placeholder="XXXX-XXXX-XXXX-XXXX" value="' . esc_attr($l['key']) . '"></p>';
        echo '<p><label><input type="checkbox" name="clear" value="1"> ' . esc_html__('登録を解除する', 'autorepair-ai-hosting-beta') . '</label></p>';
        submit_button(__('保存する', 'autorepair-ai-hosting-beta'));
        echo '</form>';
        $connected = class_exists('AAIHB_Central') && AAIHB_Central::configured();
        echo '<p><strong>' . esc_html(self::licensed()
            ? __('現在の状態：有効（有料機能が使えます）', 'autorepair-ai-hosting-beta')
            : __('現在の状態：未有効', 'autorepair-ai-hosting-beta')) . '</strong></p>';
        if (!$connected) {
            echo '<p>' . esc_html__('お申し込み後にお送りする拠点トークンを「AI運用ホーム」で登録すると、契約が確認され、有料機能が自動で使えるようになります。', 'autorepair-ai-hosting-beta') . '</p>';
        } else {
            echo '<p>' . esc_html(sprintf(__('最終確認：%s', 'autorepair-ai-hosting-beta'), $l['checked'] ? wp_date('Y年n月j日 H:i', (int) $l['checked']) : __('未実施', 'autorepair-ai-hosting-beta'))) . '</p>';
        }
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="aaihb_license_verify">';
        wp_nonce_field('aaihb_license_verify');
        submit_button(__('契約状態を今すぐ確認する', 'autorepair-ai-hosting-beta'), 'secondary', 'submit', false);
        echo '</form>';

        /* 設定する場所 */
        echo '<h2>' . esc_html__('設定する場所', 'autorepair-ai-hosting-beta') . '</h2>';
        echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>' . esc_html__('定数', 'autorepair-ai-hosting-beta')
            . '</th><th>' . esc_html__('内容', 'autorepair-ai-hosting-beta') . '</th><th>' . esc_html__('現在の値', 'autorepair-ai-hosting-beta') . '</th></tr></thead><tbody>';
        foreach ([
            ['CHECKOUT_URL', __('購入ページのURL', 'autorepair-ai-hosting-beta'), self::CHECKOUT_URL],
            ['PORTAL_URL', __('契約管理ページのURL', 'autorepair-ai-hosting-beta'), self::PORTAL_URL],
            ['LICENSE_API', __('ライセンス検証APIのURL', 'autorepair-ai-hosting-beta'), self::LICENSE_API],
            ['PAYMENT_BACKEND', __('決済サービス名', 'autorepair-ai-hosting-beta'), self::PAYMENT_BACKEND],
        ] as $row) {
            echo '<tr><td><code>' . esc_html($row[0]) . '</code></td><td>' . esc_html($row[1]) . '</td><td>'
                . ($row[2] === '' ? '<em>' . esc_html__('未設定', 'autorepair-ai-hosting-beta') . '</em>' : esc_html($row[2])) . '</td></tr>';
        }
        echo '</tbody></table>';
        echo '<p>' . esc_html__('契約の確認は、お申し込み時に発行される拠点トークンを使って中央サービス（Stripe の契約状態）へ問い合わせます。Freemius / Lemon Squeezy / Easy Digital Downloads を使う場合は、LICENSE_API を各サービスの検証APIに差し替えられます。', 'autorepair-ai-hosting-beta') . '</p>';
        echo '</div>';
    }

    /** 「同意して申し込みへ進む」の保存。 */
    public static function save_consent() {
        if (class_exists('AAIHB_Beta')) { AAIHB_Beta::allowed(); }
        check_admin_referer('aaihb_pro_consent');
        if (isset($_POST['agree']) && wp_unslash($_POST['agree']) === '1') {
            update_option(self::OPT_CONSENT, time(), false);
        }
        wp_safe_redirect(admin_url('admin.php?page=aaihb-upgrade#aaihb-signup'));
        exit;
    }

    public static function save() {
        if (class_exists('AAIHB_Beta')) { AAIHB_Beta::allowed(); }
        check_admin_referer('aaihb_upgrade');
        $l = self::license();
        if (isset($_POST['clear']) && wp_unslash($_POST['clear']) === '1') {
            $l = ['key' => '', 'active' => false, 'checked' => 0];
        } else {
            $key = strtoupper(sanitize_text_field(wp_unslash($_POST['license'] ?? '')));
            $l['key'] = $key;
            $l['active'] = false;
            $l['checked'] = time();
            if ($key !== '') {
                /* 契約の有効性は中央サービスへ問い合わせて確認します。 */
                $l['checked'] = 0;
            }
        }
        update_option(self::OPT_LICENSE, $l, false);
        self::verify(true);
        wp_safe_redirect(admin_url('admin.php?page=aaihb-upgrade#aaihb-license'));
        exit;
    }
}
