<?php
if(!defined('ABSPATH'))exit;
// Every new managed site is authorised by the billing source of truth before it is saved.
final class AAIHB_Billing {
 public static function boot(){add_action('admin_menu',function(){add_submenu_page('aaihb-home','利用数と料金','利用数と料金','manage_options','aaihb-license',['AAIHB_Central','page']);});}
 public static function configured(){return AAIHB_Central::configured();}
 public static function assert_registration($id){
  if(!AAIHB_Beta::sites_exists($id)){
   if(!self::configured())throw new RuntimeException('新しいサイトを登録するには、先に「利用数と料金」で中央サーバーへ接続してください。');
   if(get_option('aaihb_central_suspended',false))throw new RuntimeException('中央サーバーとの接続が拒否されているため、新しいサイトを登録できません。「利用数と料金」画面で状態を確認してください。');
   AAIHB_Central::authorize_registration($id);
  }
 }
 public static function scan_error(){return null;}
 public static function meter($ignored=null){}
}
