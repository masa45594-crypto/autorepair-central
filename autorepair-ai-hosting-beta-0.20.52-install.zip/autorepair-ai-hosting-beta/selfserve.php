<?php
if(!defined('ABSPATH'))exit;
final class AAIHB_Selfserve {
    const SETTINGS='aaihb_store';
    public static function boot(){add_action('admin_menu',[__CLASS__,'menu']);add_action('admin_post_aaihb_selfserve',[__CLASS__,'save']);add_action('admin_post_aaihb_stripe_test_checkout',[__CLASS__,'stripe_test_checkout']);add_action('admin_post_aaihb_stripe_test_portal',[__CLASS__,'stripe_test_portal']);add_action('admin_post_aaihb_csv_result',[__CLASS__,'csv_result']);}
    public static function menu(){foreach(['aaihb-start'=>__( __('かんたん接続', 'autorepair-ai-hosting-beta'), 'autorepair-ai-hosting-beta' ),'aaihb-buy'=>__( __('購入・契約管理', 'autorepair-ai-hosting-beta'), 'autorepair-ai-hosting-beta' ),'aaihb-help'=>__( __('困ったとき', 'autorepair-ai-hosting-beta'), 'autorepair-ai-hosting-beta' )] as $slug=>$label)add_submenu_page('aaihb-home',$label,$label,'manage_options',$slug,[__CLASS__,'page']);}
    public static function store(){return wp_parse_args(get_option(self::SETTINGS,[]),['checkout'=>'','portal'=>'','description'=>'','ready'=>false]);}
    public static function link($url){if($url==='')return '';if(strlen($url)>2000||!wp_http_validate_url($url)||wp_parse_url($url,PHP_URL_SCHEME)!=='https'||wp_parse_url($url,PHP_URL_USER)||wp_parse_url($url,PHP_URL_FRAGMENT))throw new RuntimeException((__(__('公開HTTPSのURLを入力してください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));return esc_url_raw($url,['https']);}
    public static function configure($checkout,$portal,$description,$ready){AAIHB_Beta::allowed();$c=self::link($checkout);$p=self::link($portal);$d=sanitize_textarea_field($description);if(strlen($d)>3000)throw new RuntimeException((__(__('案内は3000バイト以内で入力してください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));if($ready&&(!$c||!$d))throw new RuntimeException((__(__('購入先とプラン説明を設定してください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));update_option(self::SETTINGS,['checkout'=>$c,'portal'=>$p,'description'=>$d,'ready'=>(bool)$ready],false);}
    public static function parse($raw){
        if(!is_string($raw)||strlen($raw)>4096)throw new RuntimeException((__(__('接続情報を4096バイト以内で貼り付けてください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));
        $d=json_decode(trim($raw),true);if(!is_array($d)||($d['format']??'')!=='aaihb-connect-1'||!is_string($d['endpoint']??null)||!is_string($d['token']??null)||!is_string($d['name']??null))throw new RuntimeException((__(__('対象サイトでコピーした接続情報を、そのまま貼り付けてください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));
        $url=AAIHB_Beta::endpoint($d['endpoint']);if(!$url||!preg_match('/^[a-f0-9]{64}$/D',$d['token']))throw new RuntimeException((__(__('公開HTTPSの接続先と64桁のトークンが必要です。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));
        return ['endpoint'=>$url,'token'=>$d['token'],'name'=>wp_html_excerpt(sanitize_text_field($d['name']),80,'')];
    }
    public static function connect($raw,$replace){
        AAIHB_Beta::allowed();if(!is_ssl())throw new RuntimeException((__('管理側もHTTPSで開いてください。','autorepair-ai-hosting-beta')));$d=self::parse($raw);$id=self::save_site($d,$replace);
        $r=AAIHB_Beta::scan_site($id);return ['id'=>$id,'ok'=>!is_wp_error($r),'message'=>is_wp_error($r)?$r->get_error_message():(__('登録・診断データの取得が完了しました。','autorepair-ai-hosting-beta')),'help'=>is_wp_error($r)?self::category($r->get_error_message()):''];
    }
    /** Saves one already-validated entry. Shared by the paste form and the CSV importer. */
    public static function save_site(array $d,$replace){
        AAIHB_Beta::allowed();
        $id=hash('sha256',$d['endpoint']);
        if(!add_option('aaihb_registry_lock',time(),'',false))throw new RuntimeException((__('別の登録が処理中です。少し待ってください。','autorepair-ai-hosting-beta')));
        try{
            AAIHB_Billing::meter();
            if(AAIHB_Beta::sites_exists($id)&&!$replace)throw new RuntimeException((__('登録済みです。更新する場合は「既存の接続情報を置き換える」にチェックしてください。','autorepair-ai-hosting-beta')));
            AAIHB_Billing::assert_registration($id);
            $token=AAIHB_Beta::crypt($d['token']);
            AAIHB_Beta::site_put($id,['name'=>$d['name']?:__(__('登録サイト','autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'),'endpoint'=>$d['endpoint'],'token'=>$token,'report'=>null,'error'=>'','attempt'=>'']);
            $stored=AAIHB_Beta::site($id);
            if(!$stored||$stored['token']!==$token)throw new RuntimeException((__('登録を保存できませんでした。データベースを確認してください。','autorepair-ai-hosting-beta')));
            do_action('aaihb_registry_saved',AAIHB_Beta::sites_count());
        }finally{delete_option('aaihb_registry_lock');}
        return $id;
    }
    const CSV_ROWS=300;
    const CSV_BYTES=524288;
    const CSV_REPORT='aaihb_csv_report_';
    /** CSV upload: header check, then parse()+save_site() per row, result CSV kept for download. */
    public static function csv_import(){
        if(!is_ssl())throw new RuntimeException((__('HTTPSでこの画面を開いてください。','autorepair-ai-hosting-beta')));
        if(!isset($_FILES['aaihb_csv'])||!is_array($_FILES['aaihb_csv']))throw new RuntimeException((__('CSVファイルを選択してください。','autorepair-ai-hosting-beta')));
        $f=$_FILES['aaihb_csv'];
        $err=isset($f['error'])?(int)$f['error']:UPLOAD_ERR_NO_FILE;
        if($err!==UPLOAD_ERR_OK)throw new RuntimeException(self::upload_error($err));
        $tmp=isset($f['tmp_name'])&&is_string($f['tmp_name'])?$f['tmp_name']:'';
        if($tmp===''||!is_uploaded_file($tmp))throw new RuntimeException((__('アップロードされたファイルを読み取れませんでした。','autorepair-ai-hosting-beta')));
        $size=isset($f['size'])?(int)$f['size']:0;
        if($size<1)throw new RuntimeException((__('CSVが空です。','autorepair-ai-hosting-beta')));
        if($size>self::CSV_BYTES)throw new RuntimeException(sprintf((__('CSVは%u KB以下にしてください。','autorepair-ai-hosting-beta')),(int)(self::CSV_BYTES/1024)));
        $raw=file_get_contents($tmp);
        if(!is_string($raw)||trim($raw)==='')throw new RuntimeException((__('CSVが空です。','autorepair-ai-hosting-beta')));
        return self::csv_body($raw,AAIHB_Beta::input('replace')==='1',AAIHB_Beta::input('scan')==='1');
    }
    /** Everything after the upload is pure text-in / report-out, so it can be unit tested without $_FILES. */
    public static function csv_body($raw,$replace=false,$scan=false){
        $rows=self::csv_rows(self::csv_text($raw));
        if(!$rows)throw new RuntimeException((__('CSVに行がありません。','autorepair-ai-hosting-beta')));
        $head=self::csv_head(array_shift($rows));
        foreach(['name','endpoint','token'] as $need)if(!isset($head[$need]))throw new RuntimeException(sprintf((__('1行目の見出しに %s 列がありません。name,endpoint,token の3列が必要です。','autorepair-ai-hosting-beta')),$need));
        if($scan&&function_exists('set_time_limit'))@set_time_limit(0);
        $out=self::csv_run($rows,$head,$replace,$scan);
        $added=0;$failed=0;$skipped=0;
        foreach($out as $r){if($r['status']==='skipped')$skipped++;elseif($r['status']==='failed')$failed++;else $added++;}
        $file='aaihb-import-'.gmdate('Ymd-His').'.csv';
        set_transient(self::CSV_REPORT.get_current_user_id(),['name'=>$file,'body'=>self::csv_report($out)],600);
        return ['message'=>sprintf((__('CSVを取り込みました。登録 %d件 / 失敗 %d件 / 未処理 %d件','autorepair-ai-hosting-beta')),$added,$failed,$skipped),'csv'=>$out,'file'=>$file,'download'=>wp_nonce_url(admin_url('admin-post.php?action=aaihb_csv_result'),'aaihb_csv_result'),'ok'=>$failed===0&&$skipped===0];
    }
    /** Row loop: each row becomes the same aaihb-connect-1 payload parse() already accepts. */
    private static function csv_run(array $rows,array $head,$replace,$scan){
        $out=[];$seen=[];$n=0;
        foreach($rows as $cells){
            if(!is_array($cells))continue;
            $blank=true;foreach($cells as $c)if(trim((string)$c)!==''){$blank=false;break;}
            if($blank)continue;
            $n++;
            $name=isset($cells[$head['name']])?trim((string)$cells[$head['name']]):'';
            $endpoint=isset($cells[$head['endpoint']])?trim((string)$cells[$head['endpoint']]):'';
            $token=isset($cells[$head['token']])?strtolower(trim((string)$cells[$head['token']])):'';
            $rec=['row'=>$n,'name'=>$name,'endpoint'=>$endpoint,'token'=>$token,'status'=>'failed','reason'=>'','help'=>''];
            if($n>self::CSV_ROWS){$rec['status']='skipped';$rec['reason']=sprintf((__('上限%d行を超えたため処理していません。','autorepair-ai-hosting-beta')),self::CSV_ROWS);$out[]=$rec;continue;}
            try{
                if($endpoint==='')throw new RuntimeException((__('接続先URLが空です。','autorepair-ai-hosting-beta')));
                if($token==='')throw new RuntimeException((__('トークンが空です。','autorepair-ai-hosting-beta')));
                $json=wp_json_encode(['format'=>'aaihb-connect-1','name'=>$name,'endpoint'=>$endpoint,'token'=>$token]);
                $d=self::parse($json);
                if(isset($seen[$d['endpoint']]))throw new RuntimeException(sprintf((__('同じ接続先が%d行目と重複しています。','autorepair-ai-hosting-beta')),$seen[$d['endpoint']]));
                $seen[$d['endpoint']]=$n;
                $id=self::save_site($d,$replace);
                $rec['status']='registered';
                if($scan){$r=AAIHB_Beta::scan_site($id);if(is_wp_error($r)){$rec['status']='registered_unscanned';$rec['reason']=$r->get_error_message();$rec['help']=self::category($r->get_error_message());}}
            }catch(Throwable $e){$rec['reason']=$e->getMessage();}
            $out[]=$rec;
        }
        return $out;
    }
    public static function csv_result(){
        AAIHB_Beta::allowed();check_admin_referer('aaihb_csv_result');
        $r=get_transient(self::CSV_REPORT.get_current_user_id());delete_transient(self::CSV_REPORT.get_current_user_id());
        if(!is_array($r)||empty($r['body']))wp_die((__('ダウンロードできる結果がありません。もう一度取り込んでください。','autorepair-ai-hosting-beta')));
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="'.preg_replace('/[^A-Za-z0-9._-]/','',(string)$r['name']).'"');
        header('Content-Length: '.strlen($r['body']));
        echo $r['body'];exit;
    }
    private static function upload_error($code){
        $map=[UPLOAD_ERR_INI_SIZE=>(__('ファイルがサーバーの上限を超えています。','autorepair-ai-hosting-beta')),UPLOAD_ERR_FORM_SIZE=>(__('ファイルが大きすぎます。','autorepair-ai-hosting-beta')),UPLOAD_ERR_PARTIAL=>(__('アップロードが途中で切れました。','autorepair-ai-hosting-beta')),UPLOAD_ERR_NO_FILE=>(__('CSVファイルを選択してください。','autorepair-ai-hosting-beta')),UPLOAD_ERR_NO_TMP_DIR=>(__('一時フォルダがありません。サーバー管理者に確認してください。','autorepair-ai-hosting-beta')),UPLOAD_ERR_CANT_WRITE=>(__('一時ファイルを書き込めませんでした。','autorepair-ai-hosting-beta')),UPLOAD_ERR_EXTENSION=>(__('拡張機能がアップロードを中止しました。','autorepair-ai-hosting-beta'))];
        return $map[$code]??(__('アップロードに失敗しました。','autorepair-ai-hosting-beta'));
    }
    /** UTF-8 / UTF-8 BOM / UTF-16LE / Shift_JIS (Excel JP) are normalised to UTF-8. */
    public static function csv_text($raw){
        if(substr($raw,0,3)==="\xEF\xBB\xBF")return substr($raw,3);
        if(!function_exists('mb_convert_encoding'))return $raw;
        try{
            if(substr($raw,0,2)==="\xFF\xFE"){$t=mb_convert_encoding(substr($raw,2),'UTF-8','UTF-16LE');if(is_string($t)&&$t!=='')return $t;}
            if(function_exists('mb_check_encoding')&&mb_check_encoding($raw,'UTF-8'))return $raw;
            foreach(['CP932','SJIS-win'] as $enc){$t=mb_convert_encoding($raw,'UTF-8',$enc);if(is_string($t)&&$t!==''&&(!function_exists('mb_check_encoding')||mb_check_encoding($t,'UTF-8')))return $t;}
        }catch(Throwable $e){}
        return $raw;
    }
    public static function csv_rows($text){
        $h=fopen('php://temp','r+');if(!$h)return [];
        fwrite($h,$text);rewind($h);$rows=[];
        while(($cells=fgetcsv($h,0,',','"',''))!==false){if($cells===[null])continue;$rows[]=$cells;}
        fclose($h);return $rows;
    }
    private static function csv_head($cells){
        $alias=['name'=>'name','sitename'=>'name','サイト名'=>'name','サイト'=>'name','endpoint'=>'endpoint','url'=>'endpoint','接続先'=>'endpoint','接続先url'=>'endpoint','token'=>'token','トークン'=>'token'];
        $map=[];
        foreach((array)$cells as $i=>$v){
            $k=strtolower(trim((string)$v));
            if($k===''||$k==="\xEF\xBB\xBF")continue;
            $k=str_replace([' ','_','-',"\t"],'',$k);
            if(isset($alias[$k]))$map[$alias[$k]]=(int)$i;
        }
        return $map;
    }
    public static function csv_mask($token){
        $t=(string)preg_replace('/[^a-f0-9]/i','',(string)$token);
        if($t==='')return '(空)';
        if(strlen($t)<8)return '****';
        return substr($t,0,4).'…'.substr($t,-4);
    }
    private static function csv_cell($v){
        $v=preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/','',(string)$v);
        if($v!==''&&strpos('=+-@',$v[0])!==false)$v="'".$v;
        return $v;
    }
    public static function csv_label($status){
        $map=['registered'=>(__('登録済み','autorepair-ai-hosting-beta')),'registered_unscanned'=>(__('登録済み・診断未完了','autorepair-ai-hosting-beta')),'failed'=>(__('失敗','autorepair-ai-hosting-beta')),'skipped'=>(__('未処理','autorepair-ai-hosting-beta'))];
        return $map[$status]??(string)$status;
    }
    public static function csv_report(array $rows){
        $h=fopen('php://temp','r+');if(!$h)return '';
        fwrite($h,"\xEF\xBB\xBF");
        fputcsv($h,[__('行','autorepair-ai-hosting-beta'),__('サイト名','autorepair-ai-hosting-beta'),__('接続先URL','autorepair-ai-hosting-beta'),__('トークン','autorepair-ai-hosting-beta'),__('結果','autorepair-ai-hosting-beta'),__('理由','autorepair-ai-hosting-beta')],',','"','');
        foreach($rows as $r)fputcsv($h,[(int)$r['row'],self::csv_cell($r['name']),self::csv_cell($r['endpoint']),self::csv_mask($r['token']),self::csv_label($r['status']),self::csv_cell($r['reason'])],',','"','');
        rewind($h);$body=stream_get_contents($h);fclose($h);return (string)$body;
    }
    private static function csv_table($r){
        echo '<div class="ss-csv-summary"><table class="widefat striped"><thead><tr><th>'.esc_html__('行','autorepair-ai-hosting-beta').'</th><th>'.esc_html__('サイト名','autorepair-ai-hosting-beta').'</th><th>'.esc_html__('接続先','autorepair-ai-hosting-beta').'</th><th>'.esc_html__('結果','autorepair-ai-hosting-beta').'</th><th>'.esc_html__('理由','autorepair-ai-hosting-beta').'</th></tr></thead><tbody>';
        $n=0;foreach($r['csv'] as $row){$n++;if($n>100)break;echo '<tr><td>'.(int)$row['row'].'</td><td>'.esc_html($row['name']).'</td><td>'.esc_html($row['endpoint']).'</td><td>'.esc_html(self::csv_label($row['status'])).'</td><td>'.esc_html($row['reason']).'</td></tr>';}
        echo '</tbody></table>';
        if(count($r['csv'])>100)echo '<p>'.esc_html(sprintf(__('表は先頭100行までです。全%d行は結果CSVをダウンロードしてください。','autorepair-ai-hosting-beta'),count($r['csv']))).'</p>';
        if(!empty($r['download']))echo '<p><a class="button button-primary" href="'.esc_url($r['download']).'">'.esc_html__('結果CSVをダウンロード','autorepair-ai-hosting-beta').'</a></p>';
        echo '</div>';
    }

    public static function category($error){if(preg_match('/HTTP\s+(\d+)/',$error,$m)){return ['403'=>'auth','429'=>'wait','503'=>'dependency','404'=>'url'][$m[1]]??'network';}if(strpos($error,__(__('停止中', 'autorepair-ai-hosting-beta'), 'autorepair-ai-hosting-beta'))!==false||stripos($error,'paused')!==false)return 'paused';if(strpos($error,__(__('形式', 'autorepair-ai-hosting-beta'), 'autorepair-ai-hosting-beta'))!==false||stripos($error,'format')!==false)return 'format';if(strpos($error,__(__('トークン', 'autorepair-ai-hosting-beta'), 'autorepair-ai-hosting-beta'))!==false||stripos($error,'token')!==false)return 'auth';return 'network';}
    public static function guides(){return [
        'auth'=>[(__(__('403・認証できない', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('対象サイトで接続が有効か確認します。接続情報を再発行した場合は、管理側へ新しい情報を貼り付けて更新します。WAFによる拒否でも403になるため、認証だけが原因とは限りません。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'wait'=>[(__(__('429・診断が混み合っている', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('同じサイトの前回診断から60秒以上待ちます。定期診断や別の画面で診断している場合は、重ねて実行しないでください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'dependency'=>[(__(__('503・対象サイトの準備を確認', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('対象サイトのHosting Betaを0.11.0以降へ更新します。旧版の対象サイトではAutoRepair AI本体が必要です。新しい版は内蔵診断を使用します。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'url'=>[(__(__('404・接続先が見つからない', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('診断対象の「かんたん接続」で発行した接続情報を使います。公開ページのURLや管理画面のURLをそのまま入力しないでください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'network'=>[(__(__('接続・SSL・DNSのエラー', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('両方のWordPressを公開HTTPSで開けるか確認します。証明書、DNS、WAF、外向き通信制限を確認します。SSL検証を無効にして回避しないでください。ローカル専用URLや内部IPは対象外です。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'paused'=>[(__(__('診断を停止中', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('「グループ・予約」で対象サイトを選び、診断を再開してから実行します。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'format'=>[(__(__('診断データの形式が違う', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('対象サイトの両プラグインのバージョンと、WAFやログイン画面が応答に混ざっていないか確認します。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'token'=>[(__(__('コピーした接続情報が見つからない', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('接続情報は発行直後の画面に一度だけ表示されます。再発行すると古いトークンは失効します。再発行後は接続済みの管理側も更新してください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'cron'=>[(__(__('画面を閉じると診断が進まない', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('ホームの手動診断は画面を開いておきます。閉じて進めたい場合は「グループ・予約」を使います。予約にはWP-Cronの実行が必要です。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'billing'=>[(__(__('購入したのに表示が変わらない', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('現在は中央集計の検証モードです。「利用数と料金」で試算を確認できます。購入受付・実請求は開始していません。以前の契約は購入先で確認してください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'csv'=>[(__(__('CSVでまとめて登録できない', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('1行目の見出しを name,endpoint,token の3列にします。Excelでは「CSV UTF-8」で保存してください。Shift_JISでも自動で変換します。トークンは64桁の英数字です。同じ接続先URLが2行以上あると、2行目以降は重複として失敗します。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'report'=>[(__(__('報告書をPDFにしたい', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('顧客向け報告書を開き、ブラウザーの印刷で「PDFに保存」を選択します。社内の対応メモが載るため、内容を確認してから渡してください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],
        'repair'=>[(__(__('異常があるのに自動修復されない', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('「自動修復・復元」で限定修復を利用できます。自動修復は初期OFFで、空の内部URLルールだけが対象です。修復の計画・承認ボタンは記録用です。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))]
    ];}
    private static function form($op,$multipart=false){echo '<form method="post"'.($multipart?' enctype="multipart/form-data"':'').' action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="aaihb_selfserve"><input type="hidden" name="op" value="'.esc_attr($op).'">';wp_nonce_field('aaihb_selfserve');}
    public static function save(){
        AAIHB_Beta::allowed();check_admin_referer('aaihb_selfserve');$page='aaihb-start';$result=[];
        try{
            $op=AAIHB_Beta::input('op');
            if($op==='issue'){
                if(!is_ssl())throw new RuntimeException((__(__('HTTPSでこの画面を開いてください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));
                if(AAIHB_Beta::input('confirm')!=='1')throw new RuntimeException((__(__('再発行で古い接続情報が失効することを確認してください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));
                $token=bin2hex(random_bytes(32));$s=AAIHB_Beta::settings();$s['agent']=1;$s['hash']=hash('sha256',$token);update_option(AAIHB_Beta::SETTINGS,$s,false);if(AAIHB_Beta::settings()['hash']!==$s['hash'])throw new RuntimeException((__(__('接続情報を保存できませんでした。再度お試しください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));
                set_transient('aaihb_pack_'.get_current_user_id(),wp_json_encode(['format'=>'aaihb-connect-1','name'=>get_bloginfo('name'),'endpoint'=>rest_url('aaihb/v1/scan'),'token'=>$token],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),120);
                $result=['message'=>(__(__('接続情報を発行しました。下の欄をコピーして管理側へ貼り付けてください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))];
            }elseif($op==='connect'){$result=self::connect(AAIHB_Beta::input('pack'),AAIHB_Beta::input('replace')==='1');}elseif($op==='csv'){$result=self::csv_import();}
            elseif($op==='store'){$page='aaihb-buy';self::configure(AAIHB_Beta::input('checkout'),AAIHB_Beta::input('portal'),AAIHB_Beta::input('description'),AAIHB_Beta::input('ready')==='1');$result=['message'=>(__(__('購入導線の設定を保存しました。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))];}
            else throw new RuntimeException((__(__('操作が不正です。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));
        }catch(Throwable $e){$result=['message'=>$e->getMessage()];}
        set_transient('aaihb_flow_result_'.get_current_user_id(),$result,120);wp_safe_redirect(admin_url('admin.php?page='.$page));exit;
    }
    public static function stripe_test_checkout(){
        AAIHB_Beta::allowed();check_admin_referer('aaihb_stripe_test_checkout');
        try{
            $base=admin_url('admin.php');$success=add_query_arg(['page'=>'aaihb-buy','aaihb_checkout'=>'success'],$base);$cancel=add_query_arg(['page'=>'aaihb-buy','aaihb_checkout'=>'cancel'],$base);
            $url=AAIHB_Central::test_checkout_url($success,$cancel);wp_redirect($url,302);exit;
        }catch(Throwable $e){set_transient('aaihb_flow_result_'.get_current_user_id(),['message'=>$e->getMessage()],120);wp_safe_redirect(admin_url('admin.php?page=aaihb-buy'));exit;}
    }
    public static function stripe_test_portal(){
        AAIHB_Beta::allowed();check_admin_referer('aaihb_stripe_test_portal');
        try{
            $return=admin_url('admin.php?page=aaihb-buy');$url=AAIHB_Central::stripe_test_portal_url($return);wp_redirect($url,302);exit;
        }catch(Throwable $e){set_transient('aaihb_flow_result_'.get_current_user_id(),['message'=>$e->getMessage()],120);wp_safe_redirect(admin_url('admin.php?page=aaihb-buy'));exit;}
    }
    public static function page(){
        AAIHB_Beta::allowed();nocache_headers();$page=isset($_GET['page'])&&is_string($_GET['page'])?sanitize_key($_GET['page']):'aaihb-start';
        $titles=['aaihb-start'=>['CONNECT IN THREE STEPS',(__(__('貼り付けて、つなぐ。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('診断されるサイトで発行 → 管理側へ貼り付け → 結果を確認', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))], 'aaihb-buy'=>['YOUR PLAN',(__(__('購入・契約を、迷わず確認。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('購入先の条件を確認してから、お手続きください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))],'aaihb-help'=>['SELF SERVICE HELP',(__(__('困ったときは、ここから。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),(__(__('表示されたエラーや、やりたいことから手順を探せます。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))]];$title=$titles[$page]??$titles['aaihb-start'];
        echo '<div class="wrap aaihb-app aaihb-selfserve"><header class="ss-hero"><small>'.esc_html($title[0]).'</small><h1>'.esc_html($title[1]).'</h1><p>'.esc_html($title[2]).'</p></header>';AAIHB_Dashboard::nav($page);
        $r=get_transient('aaihb_flow_result_'.get_current_user_id());delete_transient('aaihb_flow_result_'.get_current_user_id());
        if($r){echo '<section class="ss-result" role="status"><strong>'.esc_html($r['message']).'</strong>';if(isset($r['ok']))echo '<p>'.($r['ok']?(__(__('接続テスト成功。異常の有無は「全体を見る」で確認してください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')):(__(__('登録は保存済みですが、診断は完了していません。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))).'</p>';if(!empty($r['csv']))self::csv_table($r);if(!empty($r['help']))echo '<a class="button" href="'.esc_url(admin_url('admin.php?page=aaihb-help#help-'.$r['help'])).('">'.esc_html__(__('このエラーの解決手順 →', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</a>');echo '<p><a href="'.esc_url(admin_url('admin.php?page=aaihb')).('">'.esc_html__(__('接続設定・再診断を開く', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</a></p></section>');}
        if($page==='aaihb-buy')self::buy();elseif($page==='aaihb-help')self::help();else self::start();echo '</div>';
    }
    private static function start(){
        AAIHB_Diagnostics::panel();
        $pack=get_transient('aaihb_pack_'.get_current_user_id());delete_transient('aaihb_pack_'.get_current_user_id());
        echo ('<div class="ss-grid"><section class="ss-card"><span class="ss-number">01</span><h2>'.esc_html__(__('診断されるサイトで操作', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</h2><p>'.esc_html__(__('対象サイトにもHosting Betaを設置し、この画面を開きます。接続情報には認証トークンが含まれます。管理者以外に渡さないでください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</p><ul class="ss-checks"><li>').(is_ssl()?'✓':(__(__('要確認', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))).(esc_html__(__(' HTTPSの管理画面', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</li><li>').(class_exists('AAIHB_Diagnostics')?'✓':(__(__('要確認', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))).(esc_html__(__(' Hosting Beta内蔵診断（本体不要）', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</li></ul>');
        if($pack){echo ('<label for="ss-pack">'.esc_html__(__('今回だけ表示する接続情報', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</label><textarea id="ss-pack" readonly autocomplete="off" spellcheck="false">').esc_textarea($pack).('</textarea><button type="button" class="button button-primary" data-copy="ss-pack">'.esc_html__(__('接続情報をまとめてコピー', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</button><p>'.esc_html__(__('画面を閉じる前にコピーしてください。ブラウザー内に自動保存しません。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</p>');}
        self::form('issue');echo ('<p><label><input required type="checkbox" name="confirm" value="1">'.esc_html__(__('発行すると古い接続情報が失効することを確認しました', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</label></p>');submit_button((__(__('接続情報を発行する', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),'secondary');echo ('</form></section><section class="ss-card"><span class="ss-number">02</span><h2>'.esc_html__(__('まとめて管理する側で操作', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</h2><p>'.esc_html__(__('対象サイトでコピーした情報を、下の欄へ一度だけ貼り付けます。URLとトークンを別々に入力する必要はありません。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</p>');
        self::form('connect');echo ('<label for="ss-import">'.esc_html__(__('対象サイトの接続情報', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</label><textarea id="ss-import" name="pack" required autocomplete="off" spellcheck="false" placeholder="'.esc_html__(__('ここに接続情報を貼り付け', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'"></textarea><p id="ss-import-preview" aria-live="polite"></p><p><label><input type="checkbox" name="replace" value="1">'.esc_html__(__('登録済みの場合、既存の接続情報を置き換える', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</label></p>');submit_button((__(__('登録して接続テスト', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')));echo ('</form></section><section class="ss-card" id="ss-csv"><span class="ss-number">02-B</span><h2>'.esc_html__('CSVでまとめて登録','autorepair-ai-hosting-beta').'</h2><p>'.esc_html__('ExcelやGoogleスプレッドシートの一覧から、まとめて登録できます。1行目の見出しは name,endpoint,token の3列です。各行は上の貼り付け欄と同じ検証を通り、失敗した行だけ理由が返ります。','autorepair-ai-hosting-beta').'</p><p>'.esc_html__('300行・512KBまで。トークンは結果CSVでは先頭4桁と末尾4桁だけを表示します。','autorepair-ai-hosting-beta').'</p>');self::form('csv',true);echo ('<p><label for="ss-csv-file">'.esc_html__('CSVファイル','autorepair-ai-hosting-beta').'</label><br><input id="ss-csv-file" type="file" name="aaihb_csv" accept=".csv,text/csv" required></p><p><label><input type="checkbox" name="replace" value="1">'.esc_html__('登録済みの接続先を置き換える（トークンを再発行した場合）','autorepair-ai-hosting-beta').'</label></p><p><label><input type="checkbox" name="scan" value="1">'.esc_html__('登録後に接続テストも実行する（1件あたり最大45秒）','autorepair-ai-hosting-beta').'</label></p>');submit_button(__('CSVを取り込む','autorepair-ai-hosting-beta'),'secondary');echo ('</form></section></div><section class="ss-card"><span class="ss-number">03</span><h2>'.esc_html__(__('結果を確認して、運用を始める', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</h2><p>'.esc_html__(__('接続成功は診断データを取得できた意味です。異常がないことや、修復が完了したこととは異なります。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</p><a class="button button-primary" href="').esc_url(admin_url('admin.php?page=aaihb-home')).('">'.esc_html__(__('全体を見る →', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</a> <a class="button" href="').esc_url(admin_url('admin.php?page=aaihb-help')).('">'.esc_html__(__('うまく接続できない場合', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</a><p>'.esc_html__(__('対象サイトが旧版の場合は、従来の「接続設定」でURLとトークンを別々に登録できます。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</p></section><p id="ss-copy-status" role="status"></p>');
    }
    private static function buy(){
        $state=isset($_GET['aaihb_checkout'])&&is_string($_GET['aaihb_checkout'])?sanitize_key($_GET['aaihb_checkout']):'';
        if($state==='success')echo ('<section class="ss-result" role="status"><strong>'.esc_html__(__('Stripeのテスト決済が完了しました。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</strong><p>'.esc_html__(__('Webhookの受信処理には少し時間がかかる場合があります。実際の請求は発生しません。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</p></section>');
        elseif($state==='cancel')echo ('<section class="ss-result" role="status"><strong>'.esc_html__(__('テスト決済を中止しました。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</strong><p>'.esc_html__(__('実際の請求は発生していません。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</p></section>');
        echo ('<section class="ss-card"><h2>'.esc_html__(__('Stripeテスト決済', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</h2><p>'.esc_html__(__('テストモード専用です。実際のカード請求は発生しません。中央サーバーとの接続後、StripeのテストカードでWebhook受信まで確認できます。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</p>');
        if(AAIHB_Central::configured())try{$stripe=AAIHB_Central::stripe_test_status();$labels=['active'=>(__(__('テスト契約は有効です', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),'trialing'=>(__(__('テストトライアル中です', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),'past_due'=>(__(__('テスト決済の確認が必要です', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),'unpaid'=>(__(__('テスト決済は未払いです', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),'canceled'=>(__(__('テスト契約はキャンセル済みです', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),'incomplete'=>(__(__('テスト契約の処理中です', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),'incomplete_expired'=>(__(__('テスト契約の期限が切れました', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),'none'=>(__(__('テスト契約はまだありません', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))];echo ('<p><strong>'.esc_html__(__('現在の状態：', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')).esc_html($labels[$stripe['status']]??(__(__('確認できません', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta'))).'</strong></p>';if($stripe['cancellation_pending']&&$stripe['cancellation_at'])echo ('<p><strong>'.esc_html__(__('キャンセル予定：', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')).esc_html(wp_date((__(__('Y年n月j日', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),$stripe['cancellation_at'])).(esc_html__(__('に終了します', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</strong></p>');if($stripe['updated'])echo ('<p>'.esc_html__(__('最終更新：', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')).esc_html($stripe['updated']).'</p>';if($stripe['status']!=='none'){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="aaihb_stripe_test_portal">';wp_nonce_field('aaihb_stripe_test_portal');submit_button((__(__('Stripeテスト用ポータルを開く', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),'secondary','submit',false);echo '</form>';}}catch(Throwable $e){echo ('<p>'.esc_html__(__('現在の状態：取得できません。しばらく待って再読み込みしてください。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</p>');}
        if(AAIHB_Central::configured()){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="aaihb_stripe_test_checkout">';wp_nonce_field('aaihb_stripe_test_checkout');submit_button((__(__('Stripeテスト決済を開始する', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')),'primary','submit',false);echo '</form>';}else echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page=aaihb-license')).('">'.esc_html__(__('先に中央サーバーへ接続する →', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</a></p>');
        echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page=aaihb-license')).('">'.esc_html__(__('利用数と料金を見る →', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</a></p></section>');
    }
    private static function help(){
        echo ('<section class="ss-card"><label for="ss-search">'.esc_html__(__('困っていることを検索', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</label><input id="ss-search" type="search" placeholder="'.esc_html__(__('例：403、トークン、購入、PDF', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'"><p id="ss-help-count" aria-live="polite"></p></section><div class="ss-faq">');foreach(self::guides() as $id=>$g)echo '<details class="ss-card" id="help-'.$id.'"><summary>'.esc_html($g[0]).'</summary><p>'.esc_html($g[1]).'</p></details>';echo ('</div><section class="ss-card"><h2>'.esc_html__(__('解決しない場合：確認用メモをコピー', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</h2><p>'.esc_html__(__('サイトURL・トークン・顧客名は含めません。下の環境情報に、試した操作とエラー番号を添えて販売元へ問い合わせてください。送信は自動では行いません。', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</p><textarea readonly id="ss-support">').esc_textarea('Hosting Beta '.AAIHB_VERSION.' / WordPress '.get_bloginfo('version').' / PHP '.PHP_VERSION.' / HTTPS '.(is_ssl()?'yes':'no').(__(__(' / 登録サイト ', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta')).AAIHB_Beta::sites_count()).('</textarea><button type="button" class="button" data-copy="ss-support">'.esc_html__(__('確認用メモをコピー', 'autorepair-ai-hosting-beta'),'autorepair-ai-hosting-beta').'</button><p id="ss-copy-status" role="status"></p></section>');
    }
}
