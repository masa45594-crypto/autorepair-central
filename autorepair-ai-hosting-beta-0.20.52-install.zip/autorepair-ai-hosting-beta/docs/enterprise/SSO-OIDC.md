# SSO（OpenID Connect）設定手順

対象: AutoRepair AI Hosting Beta 0.20.52
画面: `wp-admin/admin.php?page=aaihb-sso`

## 仕組み

- フロー: Authorization Code + PKCE（`code_challenge_method=S256`）
- 署名検証: ID トークンの `RS256` 署名を JWKS の公開鍵で検証（`openssl_verify`）。
  `alg: none` と `HS256`（公開鍵を共通鍵として悪用する攻撃）は明示的に拒否します。
- 鍵の回転: JWKS を1時間キャッシュし、未知の `kid` が来たときだけ一度だけ強制再取得します。
- 使い捨て検証: `state` と `nonce` は 10 分で失効する transient に保存し、コールバックで即削除します。
  PKCE の `code_verifier` も同じレコードに入れ、使い捨てにしています。
- リダイレクトURI: 設定した文字列をそのまま認可リクエストとトークン交換の両方に使います（自動変換しません）。
- クライアントシークレット: AES-256-GCM で暗号化して保存し、画面には再表示しません。
- 非常口: 通常のユーザー名／パスワードでのログインは残しています。SSO が壊れても管理者は入れます。

## 設定手順

1. IdP 側でアプリ（OIDC クライアント）を作成します。
2. リダイレクトURIに、プラグイン画面に表示される値を **完全一致** で登録します。
   既定値は `https://〈サイト〉/wp-admin/admin-post.php?action=aaihb_sso_callback` です。
3. IdP からクライアントIDとクライアントシークレットを取得します。
4. プラグインの「SSO（OpenID Connect）」画面に入力します。
   - 発行者（issuer）: `https://...`（末尾に `/.well-known/openid-configuration` を付けて取得できるURLの手前まで）
   - クライアントID / クライアントシークレット
   - スコープ: `openid email profile`（グループを使う場合はIdPに応じて `groups` など）
   - クレームの対応: `preferred_username` / `email` / `name` / `groups` が既定
5. 「SSOログインを試す」で動作確認し、問題なければ「SSOを有効にする」を保存します。

## IdP ごとの設定例（値は各サービスの表記に合わせて確認してください）

| IdP | 発行者（issuer） | 備考 |
| --- | --- | --- |
| Microsoft Entra ID | `https://login.microsoftonline.com/〈テナントID〉/v2.0` | アプリ登録の「リダイレクトURI」は種類を「Web」にします。グループを使う場合はトークン構成で groups クレームを有効化します |
| Google Workspace | `https://accounts.google.com` | OAuth クライアントは「ウェブ アプリケーション」。内部限定にする場合は「内部」を選択します |
| Okta | `https://〈ドメイン〉.okta.com` | アプリは「OIDC - Web Application」。認可サーバーのissuerを使う場合はそのURL |

## ユーザーの扱い

- メールアドレス（`email` クレーム）で既存ユーザーを探し、なければログイン名で探します。
- 既存ユーザーのロールは **変更しません**（SSO 経由の権限昇格を防ぐため）。
- 「未登録ユーザーを自動作成する」を有効にした場合だけ、新規ユーザーを作成します。
  ロールは「ロール対応表」の最初の一致で決まり、未指定は `subscriber` です。
- `administrator` への自動割り当ては、明示的に許可しない限り拒否します。
- 「許可ドメイン」を設定すると、そのドメイン以外のメールではログインできません。

## 失敗したときのコード

コールバック画面と監査ログに、次のようなコードが残ります。

| コード | 意味 / 対処 |
| --- | --- |
| `state_not_found` / `state_mismatch` | ログインをやり直してください。10分を超えた場合もこれになります |
| `idp_access_denied` | IdP 側で同意が拒否されました（アプリの割り当て・同意設定を確認） |
| `token_exchange_failed` | リダイレクトURIの不一致、シークレット誤り、`token_auth` の方式違いが典型です |
| `id_token_bad_signature` / `unknown_kid` | JWKS の鍵と署名が合いません。IdP の署名アルゴリズムが RS256 か確認してください |
| `id_token_bad_aud` / `bad_azp` | クライアントIDが違います |
| `id_token_bad_iss` | 発行者（issuer）の表記が IdP の `iss` と一致していません（末尾スラッシュ含む） |
| `id_token_expired` | 端末の時計ずれ、またはコードの使い回し |
| `id_token_bad_nonce` | 別のタブで開始したログインと混ざった可能性があります。やり直してください |
| `login_rejected` | 未登録ユーザー（自動作成オフ）、未確認メール、許可外ドメイン、administrator 割り当て拒否のいずれか |

## 制約（正直な記載）

- SAML 2.0 には対応していません（OIDC のみ）。
- グループ／ロールの値は IdP の設定により変わるため、実際の値は一度トークンを見て確認してください
  （本プラグインはトークン本文をログに残しません。IdP 側のデバッグ機能を使ってください）。
- 実機での検証は Entra ID・Google Workspace・Okta のいずれも未実施です。
  ローカルのモック IdP（RSA 鍵で署名した JWT）に対する単体テストのみ通過しています。
- バックチャネルログアウト（IdP 側でログアウトしたときに WordPress のセッションも切る）には未対応です。
