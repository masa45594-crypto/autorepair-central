# 監査ログの仕様（Access Audit）

対象: AutoRepair AI Hosting Beta 0.20.51 / 画面 `wp-admin/admin.php?page=aaihb-audit`

## 記録するイベント

| action | 内容 |
| --- | --- |
| `login_ok` / `login_failed` / `logout` | WordPress へのログイン成功・失敗・ログアウト（対象にユーザー名、補足にロール） |
| `option_change` | `aaihb_central`（中央サーバー接続）、`aaihb_access_v1`、`aaihb_allow_multisite`、監査設定、`aaihb_purge_on_uninstall` の変更。値そのものは記録せず、キー名だけを残します |
| `admin_post` | プラグイン管理画面への POST（ページ名と、送信された項目名だけ。値・トークン・パスワードは記録しない） |
| `audit_settings` / `audit_export` | 監査設定の変更、書き出しの実行 |

`token` / `pass` / `secret` を含む項目名は記録対象から除外しています。

## 改ざん検知の仕組み

各行は次の値を持ちます。

- `prev`: 直前の行の `hash`
- `hash`: `sha256(prev | at | actor | action | object | result | detail_hash)`
- `detail_hash`: 補足文の SHA-256（補足文そのものは `detail` 列）

検証（`AAIHB_AuditLog::verify_rows()`）は行を ID 順にたどり、
`prev` が直前の `hash` と一致するか、`hash` が再計算値と一致するかを確認します。

- 途中の行を書き換える → その行の `hash` が合わなくなり `broken` に入る
- 途中の行を削除する → 次の行の `prev` が合わず `broken` に入る（同時に `gaps` に ID が入る）
- 古い行を保存期間で削除する → 先頭が欠けるだけで `broken` にはならない（`gaps` のみ）

画面には「連結の検証：正常／異常」と、検証した行数・欠番数を表示します。

## 書き出し（SIEM・チェックシート提出用）

- CSV: `admin-post.php?action=aaihb_audit_export&format=csv`（BOM 付き UTF-8、Excel でそのまま開ける）
- JSON: `...&format=json`（`chain` に検証結果を含む）

どちらも `manage_options` と nonce が必要です。CSV は `= + - @` で始まる値を無害化し、
表計算ソフトでの数式実行（CSV インジェクション）を防ぎます。

## 制約（正直な記載）

- ログは WordPress の DB 内にあります。DB 全体の管理者（phpMyAdmin 等）はテーブルごと差し替えられます。
  その場合もハッシュ連鎖は壊れるため「改ざんされた」ことは分かりますが、防止はできません。
  防止が必要な場合は、CSV/JSON を外部の WORM ストレージや SIEM に定期転送してください。
- IP アドレスは `REMOTE_ADDR` のみを記録します（プロキシ配下ではプロキシの IP になります）。
- 監査ログ自体の改ざん検知は「気づける」レベルであり、法令上の証跡要件を満たすかは契約時にご確認ください。
