<?php
if (!defined('ABSPATH')) { exit; }

/**
 * SSO（OpenID Connect / Authorization Code + PKCE）
 *
 * 既定は無効。管理者が「SSO（OpenID Connect）」画面で発行者・クライアントID・
 * クライアントシークレット・リダイレクトURIを設定して有効化したときだけ動きます。
 *
 * 設計方針:
 *   - ログイン画面の通常のユーザー名/パスワード入力は残します（break-glass）。
 *     SSO が壊れても、WordPress 管理者は local login で入れる必要があるためです。
 *   - state / nonce は使い捨て（transient に 10 分だけ保存し、コールバックで即削除）。
 *   - PKCE は S256 固定（plain は使いません）。
 *   - ID トークンは RS256 の署名のみ受け付けます。alg: none や HS256 は拒否します。
 *   - JWKS は 1 時間キャッシュし、未知の kid が来たら一度だけ強制再取得します（鍵の回転対応）。
 *   - クライアントシークレットは AES-256-GCM で暗号化して保存します（AAIHB_Beta::crypt）。
 *   - 既存ユーザーのロールは SSO では変更しません（権限昇格の防止）。
 *   - 新規ユーザー作成（自動プロビジョニング）は明示的に有効化した場合だけです。
 *   - すべての SSO イベントは監査ログ（改ざん検知つき）に記録します。
 *
 * 検証しやすいよう、外部 I/O を持たない純粋関数（verify_id_token / state_ok /
 * jwk_to_pem / authorize_url / pkce_pair）を分離しています。
 */
final class AAIHB_SSO {
	const OPT          = 'aaihb_sso';
	const DISC         = 'aaihb_sso_discovery';
	const JWKS         = 'aaihb_sso_jwks';
	const STATE_PREFIX = 'aaihb_sso_state_';
	const STATE_TTL    = 600;
	const SKEW         = 60;
	const CAP          = 'manage_options';

	public static function boot() {
		add_action('admin_menu', function () {
			add_submenu_page('aaihb-home', __('SSO（OpenID Connect）', 'autorepair-ai-hosting-beta'), __('SSO（OpenID Connect）', 'autorepair-ai-hosting-beta'), self::CAP, 'aaihb-sso', [__CLASS__, 'page']);
		});
		add_action('admin_post_aaihb_sso_save', [__CLASS__, 'save_settings']);
		add_action('admin_post_nopriv_aaihb_sso_start', [__CLASS__, 'start']);
		add_action('admin_post_aaihb_sso_start', [__CLASS__, 'start']);
		add_action('admin_post_nopriv_aaihb_sso_callback', [__CLASS__, 'callback']);
		add_action('admin_post_aaihb_sso_callback', [__CLASS__, 'callback']);
		add_filter('login_message', [__CLASS__, 'login_message']);
	}

	/* ------------------------------------------------------------------ 設定 */

	public static function defaults() {
		return [
			'enabled' => 0, 'issuer' => '', 'client_id' => '', 'secret' => '',
			'redirect_uri' => '', 'scopes' => 'openid email profile',
			'claim_login' => 'preferred_username', 'claim_email' => 'email', 'claim_name' => 'name',
			'claim_groups' => 'groups', 'role_map' => '', 'auto_provision' => 0,
			'allow_admin' => 0, 'require_verified' => 1, 'allowed_domains' => '',
			'token_auth' => 'basic',
		];
	}

	public static function cfg($k = null) {
		$c = wp_parse_args((array) get_option(self::OPT, []), self::defaults());
		if ($k === null) { return $c; }
		return array_key_exists($k, $c) ? $c[$k] : null;
	}

	public static function redirect_uri() {
		$u = trim((string) self::cfg('redirect_uri'));
		return $u !== '' ? $u : admin_url('admin-post.php?action=aaihb_sso_callback');
	}

	/** 暗号化されたシークレットを復号します。失敗しても例外を投げません（管理画面を止めない）。 */
	public static function secret($quiet = true) {
		$enc = (string) self::cfg('secret');
		if ($enc === '') { return ''; }
		try {
			return (string) AAIHB_Beta::crypt($enc, true);
		} catch (Throwable $e) {
			if (!$quiet) { throw $e; }
			return '';
		}
	}

	public static function start_url() {
		return admin_url('admin-post.php?action=aaihb_sso_start');
	}

	/* ------------------------------------------------------- ディスカバリ / JWKS */

	public static function issuer() {
		return rtrim((string) self::cfg('issuer'), '/');
	}

	public static function discovery($force = false) {
		if (!$force) {
			$c = get_transient(self::DISC);
			if (is_array($c) && !empty($c['authorization_endpoint'])) { return $c; }
		}
		$iss = self::issuer();
		if ($iss === '' || !preg_match('#^https://[^\s]+$#i', $iss)) {
			throw new RuntimeException(__('発行者（issuer）は https の URL で入力してください。例: https://login.microsoftonline.com/〈テナントID〉/v2.0', 'autorepair-ai-hosting-beta'));
		}
		$url = $iss . '/.well-known/openid-configuration';
		$res = wp_remote_get($url, ['timeout' => 15, 'sslverify' => true, 'redirection' => 0, 'headers' => ['Accept' => 'application/json']]);
		if (is_wp_error($res)) {
			throw new RuntimeException(sprintf(__('ディスカバリに失敗しました（%s）。', 'autorepair-ai-hosting-beta'), $res->get_error_message()));
		}
		$code = (int) wp_remote_retrieve_response_code($res);
		if ($code !== 200) {
			throw new RuntimeException(sprintf(__('ディスカバリが HTTP %d を返しました。発行者URLを確認してください。', 'autorepair-ai-hosting-beta'), $code));
		}
		$j = json_decode((string) wp_remote_retrieve_body($res), true);
		if (!is_array($j)) {
			throw new RuntimeException(__('ディスカバリの応答が JSON ではありません。', 'autorepair-ai-hosting-beta'));
		}
		foreach (['issuer', 'authorization_endpoint', 'token_endpoint', 'jwks_uri'] as $need) {
			if (empty($j[$need]) || !is_string($j[$need])) {
				throw new RuntimeException(sprintf(__('ディスカバリに %s がありません。', 'autorepair-ai-hosting-beta'), $need));
			}
		}
		if (rtrim((string) $j['issuer'], '/') !== $iss) {
			throw new RuntimeException(__('ディスカバリの issuer が設定した発行者と一致しません。', 'autorepair-ai-hosting-beta'));
		}
		set_transient(self::DISC, $j, 3600);
		return $j;
	}

	public static function jwks($force = false) {
		if (!$force) {
			$c = get_transient(self::JWKS);
			if (is_array($c) && isset($c['keys'])) { return $c; }
		}
		$d = self::discovery($force);
		$res = wp_remote_get((string) $d['jwks_uri'], ['timeout' => 15, 'sslverify' => true, 'redirection' => 0, 'headers' => ['Accept' => 'application/json']]);
		if (is_wp_error($res)) {
			throw new RuntimeException(sprintf(__('JWKS の取得に失敗しました（%s）。', 'autorepair-ai-hosting-beta'), $res->get_error_message()));
		}
		if ((int) wp_remote_retrieve_response_code($res) !== 200) {
			throw new RuntimeException(__('JWKS が 200 以外を返しました。', 'autorepair-ai-hosting-beta'));
		}
		$j = json_decode((string) wp_remote_retrieve_body($res), true);
		if (!is_array($j) || !isset($j['keys']) || !is_array($j['keys'])) {
			throw new RuntimeException(__('JWKS の応答が不正です。', 'autorepair-ai-hosting-beta'));
		}
		set_transient(self::JWKS, $j, 3600);
		return $j;
	}

	/** kid に一致する RSA 署名鍵を返します。kid が null なら最初の署名用 RSA 鍵。 */
	public static function key_for_kid(array $jwks, $kid) {
		$keys = isset($jwks['keys']) && is_array($jwks['keys']) ? $jwks['keys'] : [];
		foreach ($keys as $k) {
			if (!is_array($k) || ($k['kty'] ?? '') !== 'RSA') { continue; }
			if (isset($k['use']) && $k['use'] !== 'sig') { continue; }
			if (isset($k['alg']) && $k['alg'] !== 'RS256') { continue; }
			if (empty($k['n']) || empty($k['e'])) { continue; }
			if ($kid !== null && (string) ($k['kid'] ?? '') !== (string) $kid) { continue; }
			return $k;
		}
		return null;
	}

	/* ------------------------------------------------------------ 純粋関数群 */

	public static function b64url($raw) {
		return rtrim(strtr(base64_encode((string) $raw), '+/', '-_'), '=');
	}

	public static function b64url_decode($s) {
		if (!is_string($s) || $s === '') { return ''; }
		if (!preg_match('#^[A-Za-z0-9_-]+$#D', $s)) { return false; }
		$pad = strlen($s) % 4;
		if ($pad) { $s .= str_repeat('=', 4 - $pad); }
		$out = base64_decode(strtr($s, '-_', '+/'), true);
		return $out === false ? false : $out;
	}

	public static function b64url_json($s) {
		$raw = self::b64url_decode($s);
		if ($raw === false || $raw === '') { return null; }
		$j = json_decode($raw, true);
		return is_array($j) ? $j : null;
	}

	public static function pkce_pair() {
		$v = self::b64url(random_bytes(32));
		return ['verifier' => $v, 'challenge' => self::b64url(hash('sha256', $v, true)), 'method' => 'S256'];
	}

	public static function authorize_url($endpoint, $client_id, $redirect_uri, $state, $nonce, $challenge, $scopes) {
		$q = [
			'response_type' => 'code',
			'client_id' => (string) $client_id,
			'redirect_uri' => (string) $redirect_uri,
			'scope' => (string) $scopes,
			'state' => (string) $state,
			'nonce' => (string) $nonce,
			'code_challenge' => (string) $challenge,
			'code_challenge_method' => 'S256',
		];
		$sep = (strpos($endpoint, '?') === false) ? '?' : '&';
		return $endpoint . $sep . http_build_query($q, '', '&', PHP_QUERY_RFC3986);
	}

	/** state の使い捨てレコードを検証します（純粋）。 */
	public static function state_ok($state, $record, $now = null) {
		if (!is_array($record) || empty($record['state']) || empty($record['nonce']) || empty($record['verifier'])) { return false; }
		if (!is_string($state) || strlen($state) < 32) { return false; }
		if (!hash_equals((string) $record['state'], $state)) { return false; }
		$now = ($now === null) ? time() : (int) $now;
		if ((int) ($record['created'] ?? 0) + self::STATE_TTL < $now) { return false; }
		return true;
	}

	private static function bad(array $res, $code) {
		$res['ok'] = false; $res['error'] = (string) $code; $res['claims'] = [];
		return $res;
	}

	private static function der_len($len) {
		if ($len < 0x80) { return chr($len); }
		$b = ltrim(pack('N', $len), "\x00");
		return chr(0x80 | strlen($b)) . $b;
	}

	private static function der_integer($bin) {
		$bin = ltrim((string) $bin, "\x00");
		if ($bin === '') { $bin = "\x00"; }
		if (ord($bin[0]) > 0x7f) { $bin = "\x00" . $bin; }
		return "\x02" . self::der_len(strlen($bin)) . $bin;
	}

	private static function der_seq($body) {
		return "\x30" . self::der_len(strlen($body)) . $body;
	}

	/**
	 * JWK（RSA 公開鍵）を PEM に変換します。RSA そのものは実装せず、
	 * ASN.1（SubjectPublicKeyInfo）を組み立てるだけです。署名検証は openssl が行います。
	 */
	public static function jwk_to_pem(array $jwk) {
		if (($jwk['kty'] ?? '') !== 'RSA' || empty($jwk['n']) || empty($jwk['e'])) {
			throw new RuntimeException(__('JWK が RSA 公開鍵ではありません。', 'autorepair-ai-hosting-beta'));
		}
		$n = self::b64url_decode((string) $jwk['n']);
		$e = self::b64url_decode((string) $jwk['e']);
		if ($n === false || $e === false || $n === '' || $e === '') {
			throw new RuntimeException(__('JWK の n / e を復号できません。', 'autorepair-ai-hosting-beta'));
		}
		$rsa = self::der_seq(self::der_integer($n) . self::der_integer($e));
		$bit = "\x03" . self::der_len(strlen($rsa) + 1) . "\x00" . $rsa;
		$alg = "\x30\x0d\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00"; // rsaEncryption, NULL
		$spki = self::der_seq($alg . $bit);
		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($spki), 64, "\n") . "-----END PUBLIC KEY-----\n";
	}

	/**
	 * ID トークンを検証します（純粋関数・ネットワーク不要）。
	 *
	 * @param string   $jwt    compact serialization
	 * @param array    $expect issuer / client_id / nonce
	 * @param callable $lookup function(string $kid): ?string  PEM を返す。null なら不明な kid
	 * @param int|null $now    テスト用の現在時刻
	 * @return array{ok:bool,claims:array,error:string,kid:string}
	 */
	public static function verify_id_token($jwt, array $expect, callable $lookup, $now = null) {
		$now = ($now === null) ? time() : (int) $now;
		$res = ['ok' => false, 'claims' => [], 'error' => '', 'kid' => ''];

		if (!is_string($jwt) || substr_count($jwt, '.') !== 2) { return self::bad($res, 'malformed'); }
		$parts = explode('.', $jwt);

		$head = self::b64url_json($parts[0]);
		if ($head === null) { return self::bad($res, 'bad_header'); }
		$alg = isset($head['alg']) ? (string) $head['alg'] : '';
		// alg: none / HS256 / ES256 を拒否（RS256 固定）
		if ($alg !== 'RS256') { return self::bad($res, 'bad_alg'); }
		$kid = isset($head['kid']) ? (string) $head['kid'] : '';
		if ($kid === '') { return self::bad($res, 'missing_kid'); }
		$res['kid'] = $kid;

		$sig = self::b64url_decode($parts[2]);
		if ($sig === false || $sig === '') { return self::bad($res, 'bad_signature'); }

		try {
			$pem = $lookup($kid);
		} catch (Throwable $e) {
			return self::bad($res, 'jwks_unavailable');
		}
		if (!is_string($pem) || $pem === '') { return self::bad($res, 'unknown_kid'); }
		$key = openssl_pkey_get_public($pem);
		if ($key === false) { return self::bad($res, 'bad_key'); }
		if (openssl_verify($parts[0] . '.' . $parts[1], $sig, $key, OPENSSL_ALGO_SHA256) !== 1) {
			return self::bad($res, 'bad_signature');
		}

		$c = self::b64url_json($parts[1]);
		if ($c === null) { return self::bad($res, 'bad_payload'); }

		$want_iss = (string) ($expect['issuer'] ?? '');
		if ($want_iss === '' || (string) ($c['iss'] ?? '') !== $want_iss) { return self::bad($res, 'bad_iss'); }

		$cid = (string) ($expect['client_id'] ?? '');
		$aud = $c['aud'] ?? null;
		$auds = is_array($aud) ? array_map('strval', $aud) : [(string) $aud];
		if ($cid === '' || !in_array($cid, $auds, true)) { return self::bad($res, 'bad_aud'); }
		if (isset($c['azp']) && (string) $c['azp'] !== $cid) { return self::bad($res, 'bad_azp'); }
		if (count($auds) > 1 && !isset($c['azp'])) { return self::bad($res, 'bad_azp'); }

		if (!isset($c['exp'])) { return self::bad($res, 'missing_exp'); }
		if ((int) $c['exp'] + self::SKEW < $now) { return self::bad($res, 'expired'); }
		if (isset($c['iat']) && (int) $c['iat'] - self::SKEW > $now) { return self::bad($res, 'iat_future'); }
		if (isset($c['nbf']) && (int) $c['nbf'] - self::SKEW > $now) { return self::bad($res, 'nbf_future'); }

		$want_nonce = (string) ($expect['nonce'] ?? '');
		if ($want_nonce !== '') {
			if (!isset($c['nonce']) || !hash_equals($want_nonce, (string) $c['nonce'])) { return self::bad($res, 'bad_nonce'); }
		}

		$res['ok'] = true; $res['error'] = ''; $res['claims'] = $c;
		return $res;
	}

	/* ------------------------------------------------------------ ログイン導線 */

	public static function login_message($message) {
		if (!(int) self::cfg('enabled')) { return $message; }
		$url = self::start_url();
		return $message . '<p style="margin:0 0 1em"><a class="button button-primary" style="width:100%;text-align:center" href="'
			. esc_url($url) . '">' . esc_html__('SSOでログイン', 'autorepair-ai-hosting-beta') . '</a></p>'
			. '<p style="margin:0 0 1em;color:#646970;font-size:12px">' . esc_html__('SSOが使えない場合は、下のユーザー名とパスワードでログインできます。', 'autorepair-ai-hosting-beta') . '</p>';
	}

	private static function wanted_redirect() {
		$to = isset($_GET['redirect_to']) ? (string) wp_unslash($_GET['redirect_to']) : '';
		$ok = wp_validate_redirect($to, admin_url());
		return $ok !== '' ? $ok : admin_url();
	}

	public static function start() {
		if (!(int) self::cfg('enabled')) { wp_safe_redirect(wp_login_url()); exit; }
		try {
			$d = self::discovery();
		} catch (Throwable $e) {
			AAIHB_AuditLog::log('sso_start', 'discovery', 'fail', $e->getMessage());
			wp_die(esc_html($e->getMessage()), esc_html__('SSOを開始できません', 'autorepair-ai-hosting-beta'), ['response' => 500]);
		}
		$state = self::b64url(random_bytes(24));
		$nonce = self::b64url(random_bytes(24));
		$p = self::pkce_pair();
		set_transient(self::STATE_PREFIX . hash('sha256', $state), [
			'state' => $state, 'nonce' => $nonce, 'verifier' => $p['verifier'],
			'created' => time(), 'redirect_to' => self::wanted_redirect(),
		], self::STATE_TTL);
		AAIHB_AuditLog::log('sso_start', 'oidc', 'ok', 'issuer=' . self::issuer());
		$url = self::authorize_url((string) $d['authorization_endpoint'], (string) self::cfg('client_id'), self::redirect_uri(), $state, $nonce, $p['challenge'], (string) self::cfg('scopes'));
		wp_redirect($url); exit;
	}

	public static function callback() {
		$fail = function ($code, $detail = '', $status = 403) {
			AAIHB_AuditLog::log('sso_callback', (string) $code, 'fail', (string) $detail);
			wp_die(
				esc_html__('SSOでのログインを完了できませんでした。', 'autorepair-ai-hosting-beta') . '<br><code>' . esc_html($code) . '</code>',
				esc_html__('SSOログイン失敗', 'autorepair-ai-hosting-beta'),
				['response' => $status, 'back_link' => true]
			);
		};

		if (!(int) self::cfg('enabled')) { $fail('sso_disabled'); }

		if (isset($_GET['error'])) {
			$err = sanitize_key(wp_unslash((string) $_GET['error']));
			$desc = isset($_GET['error_description']) ? substr(sanitize_text_field(wp_unslash((string) $_GET['error_description'])), 0, 200) : '';
			$fail('idp_' . $err, $desc);
		}

		$state = isset($_GET['state']) ? (string) wp_unslash($_GET['state']) : '';
		$key = self::STATE_PREFIX . hash('sha256', $state);
		$rec = get_transient($key);
		if (!is_array($rec)) { $fail('state_not_found'); }
		delete_transient($key); // 使い捨て
		if (!self::state_ok($state, $rec)) { $fail('state_mismatch'); }

		$code = isset($_GET['code']) ? (string) wp_unslash($_GET['code']) : '';
		if ($code === '' || strlen($code) > 4096) { $fail('missing_code'); }

		try {
			$d = self::discovery();
			$tok = self::exchange($d, $code, (string) $rec['verifier']);
		} catch (Throwable $e) {
			$fail('token_exchange_failed', $e->getMessage(), 502);
		}
		$id = isset($tok['id_token']) ? (string) $tok['id_token'] : '';
		if ($id === '') { $fail('missing_id_token', '', 502); }

		$lookup = function ($kid) {
			$k = self::key_for_kid(self::jwks(), $kid);
			if (!$k) { $k = self::key_for_kid(self::jwks(true), $kid); } // 鍵の回転
			return $k ? self::jwk_to_pem($k) : null;
		};
		$v = self::verify_id_token($id, [
			'issuer' => self::issuer(),
			'client_id' => (string) self::cfg('client_id'),
			'nonce' => (string) $rec['nonce'],
		], $lookup);
		if (!$v['ok']) { $fail('id_token_' . $v['error'], 'kid=' . $v['kid'], 401); }

		try {
			$user = self::login_user($v['claims']);
		} catch (Throwable $e) {
			$fail('login_rejected', $e->getMessage(), 403);
		}

		AAIHB_AuditLog::log('sso_login', $user->user_login, 'ok', 'email=' . $user->user_email);
		wp_set_current_user($user->ID);
		wp_set_auth_cookie($user->ID, false, is_ssl());
		do_action('wp_login', $user->user_login, $user);
		wp_safe_redirect(wp_validate_redirect((string) ($rec['redirect_to'] ?? ''), admin_url()));
		exit;
	}

	public static function exchange(array $d, $code, $verifier) {
		$cid = (string) self::cfg('client_id');
		$sec = self::secret();
		if ($sec === '' && (string) self::cfg('token_auth') === 'basic') {
			throw new RuntimeException(__('クライアントシークレットを復号できません。SSO設定で再入力してください。', 'autorepair-ai-hosting-beta'));
		}
		$body = [
			'grant_type' => 'authorization_code',
			'code' => (string) $code,
			'redirect_uri' => self::redirect_uri(),
			'client_id' => $cid,
			'code_verifier' => (string) $verifier,
		];
		$headers = ['Content-Type' => 'application/x-www-form-urlencoded', 'Accept' => 'application/json'];
		if ($sec !== '') {
			if ((string) self::cfg('token_auth') === 'post') { $body['client_secret'] = $sec; }
			else { $headers['Authorization'] = 'Basic ' . base64_encode($cid . ':' . $sec); }
		}
		$res = wp_remote_post((string) $d['token_endpoint'], [
			'timeout' => 15, 'sslverify' => true, 'redirection' => 0,
			'headers' => $headers,
			'body' => $body,
		]);
		if (is_wp_error($res)) { throw new RuntimeException($res->get_error_message()); }
		$code_http = (int) wp_remote_retrieve_response_code($res);
		$raw = (string) wp_remote_retrieve_body($res);
		$j = json_decode($raw, true);
		if (!is_array($j)) { throw new RuntimeException(sprintf(__('トークン応答が JSON ではありません（HTTP %d）。', 'autorepair-ai-hosting-beta'), $code_http)); }
		if ($code_http !== 200 || !empty($j['error'])) {
			$msg = isset($j['error']) ? (string) $j['error'] : ('HTTP ' . $code_http);
			if (isset($j['error_description'])) { $msg .= ': ' . substr((string) $j['error_description'], 0, 200); }
			throw new RuntimeException($msg);
		}
		if (isset($j['token_type']) && strtolower((string) $j['token_type']) !== 'bearer') {
			throw new RuntimeException(__('token_type が Bearer ではありません。', 'autorepair-ai-hosting-beta'));
		}
		return $j;
	}

	/** ロール表（"グループ値=role" の行）から最初に一致したロールを返します。 */
	public static function map_role($groups, $map_text) {
		$map = [];
		foreach (preg_split('/\r\n|\r|\n/', (string) $map_text) as $line) {
			$line = trim($line);
			if ($line === '' || strpos($line, '=') === false) { continue; }
			list($k, $v) = array_map('trim', explode('=', $line, 2));
			if ($k !== '' && $v !== '') { $map[$k] = $v; }
		}
		$gs = is_array($groups) ? $groups : ((string) $groups === '' ? [] : [(string) $groups]);
		foreach ($gs as $g) {
			if (isset($map[(string) $g])) { return sanitize_key($map[(string) $g]); }
		}
		return 'subscriber';
	}

	public static function login_user(array $claims) {
		$email = sanitize_email((string) ($claims[(string) self::cfg('claim_email')] ?? ''));
		$login = sanitize_user((string) ($claims[(string) self::cfg('claim_login')] ?? ''), true);
		if ($login === '' && $email !== '') { $login = sanitize_user((string) strstr($email, '@', true), true); }
		if ($login === '') { throw new RuntimeException(__('ID トークンに利用できるユーザー名がありません。', 'autorepair-ai-hosting-beta')); }

		if ((int) self::cfg('require_verified')) {
			$ev = $claims['email_verified'] ?? null;
			$ok = ($ev === true || $ev === 'true' || $ev === 1 || $ev === '1');
			if (!$ok) { throw new RuntimeException(__('メールアドレスが確認済みではありません（email_verified）。', 'autorepair-ai-hosting-beta')); }
		}

		$domains = array_filter(array_map('trim', explode(',', strtolower((string) self::cfg('allowed_domains')))));
		if ($domains) {
			$host = $email !== '' ? strtolower((string) substr(strrchr($email, '@'), 1)) : '';
			if ($host === '' || !in_array($host, $domains, true)) {
				throw new RuntimeException(__('許可されていないメールドメインです。', 'autorepair-ai-hosting-beta'));
			}
		}

		$user = null;
		if ($email !== '') { $user = get_user_by('email', $email); }
		if (!$user) { $user = get_user_by('login', $login); }

		if ($user) {
			// 既存ユーザーのロールは変更しない（権限昇格の防止）。
			return $user;
		}

		if (!(int) self::cfg('auto_provision')) {
			throw new RuntimeException(__('このユーザーはまだ登録されていません。管理者に依頼してください。', 'autorepair-ai-hosting-beta'));
		}

		$groups = $claims[(string) self::cfg('claim_groups')] ?? [];
		$role = self::map_role($groups, (string) self::cfg('role_map'));
		if ($role === 'administrator' && !(int) self::cfg('allow_admin')) {
			throw new RuntimeException(__('administrator への自動割り当ては許可されていません。', 'autorepair-ai-hosting-beta'));
		}
		if (!get_role($role)) { $role = 'subscriber'; }

		$login = self::unique_login($login, $email);
		$uid = wp_insert_user([
			'user_login' => $login,
			'user_email' => $email,
			'user_pass' => wp_generate_password(48, true, true),
			'display_name' => sanitize_text_field((string) ($claims[(string) self::cfg('claim_name')] ?? $login)),
			'role' => $role,
		]);
		if (is_wp_error($uid)) { throw new RuntimeException($uid->get_error_message()); }
		AAIHB_AuditLog::log('sso_provision', (string) $login, 'ok', 'role=' . $role . ' email=' . $email);
		return get_user_by('id', (int) $uid);
	}

	private static function unique_login($login, $email) {
		if (!username_exists($login)) { return $login; }
		$base = $login;
		if ($email !== '' && strpos($email, '@') !== false) { $base = (string) strstr($email, '@', true); }
		for ($i = 1; $i <= 20; $i++) {
			$try = $base . $i;
			if (!username_exists($try)) { return $try; }
		}
		return 'sso_' . substr(hash('sha256', $email . microtime(true)), 0, 10);
	}

	/* -------------------------------------------------------------- 設定画面 */

	public static function save_settings() {
		if (!current_user_can(self::CAP) || !AAIHB_Beta::scope_ok()) {
			wp_die(__('管理者権限が必要です。', 'autorepair-ai-hosting-beta'), '', ['response' => 403]);
		}
		check_admin_referer('aaihb_sso_save');
		$old = self::cfg();
		$in = function ($k) { return isset($_POST[$k]) && is_string($_POST[$k]) ? trim(wp_unslash($_POST[$k])) : ''; };
		$new = $old;

		$new['enabled'] = $in('enabled') === '1' ? 1 : 0;
		$iss = rtrim($in('issuer'), '/');
		if ($iss !== '' && !preg_match('#^https://[^\s]+$#i', $iss)) {
			$iss = $old['issuer'];
			add_settings_error('aaihb_sso', 'issuer', __('発行者（issuer）は https の URL で入力してください。', 'autorepair-ai-hosting-beta'));
		}
		$new['issuer'] = $iss;
		$new['client_id'] = substr(sanitize_text_field($in('client_id')), 0, 190);
		$redirect = trim($in('redirect_uri'));
		if ($redirect !== '' && !preg_match('#^https://#i', $redirect)) {
			$redirect = $old['redirect_uri'];
			add_settings_error('aaihb_sso', 'redirect', __('リダイレクトURIは https で入力してください。', 'autorepair-ai-hosting-beta'));
		}
		$new['redirect_uri'] = $redirect;
		$new['scopes'] = preg_replace('/[^a-z0-9 _\-\.\/:]/i', '', $in('scopes')) ?: 'openid email profile';
		foreach (['claim_login' => 'preferred_username', 'claim_email' => 'email', 'claim_name' => 'name', 'claim_groups' => 'groups'] as $f => $def) {
			$v = preg_replace('/[^a-zA-Z0-9_.:]/', '', $in($f));
			$new[$f] = $v !== '' ? $v : $def;
		}
		$new['role_map'] = substr((string) $in('role_map'), 0, 4000);
		$new['auto_provision'] = $in('auto_provision') === '1' ? 1 : 0;
		$new['allow_admin'] = $in('allow_admin') === '1' ? 1 : 0;
		$new['require_verified'] = $in('require_verified') === '1' ? 1 : 0;
		$new['allowed_domains'] = substr(strtolower(sanitize_text_field($in('allowed_domains'))), 0, 500);
		$new['token_auth'] = $in('token_auth') === 'post' ? 'post' : 'basic';

		// シークレットは「新しい値が入っているときだけ」差し替えます（空欄＝現状維持）。
		$sec = $in('secret');
		if ($in('clear_secret') === '1') {
			$new['secret'] = '';
		} elseif ($sec !== '') {
			try {
				$new['secret'] = AAIHB_Beta::crypt($sec);
			} catch (Throwable $e) {
				add_settings_error('aaihb_sso', 'secret', __('シークレットを暗号化できませんでした。', 'autorepair-ai-hosting-beta'));
			}
		}

		if ($new['enabled'] && ($new['issuer'] === '' || $new['client_id'] === '')) {
			$new['enabled'] = 0;
			add_settings_error('aaihb_sso', 'required', __('発行者とクライアントIDが未入力のため、SSOは無効のままにしました。', 'autorepair-ai-hosting-beta'));
		}

		update_option(self::OPT, $new, false);
		delete_transient(self::DISC);
		delete_transient(self::JWKS);
		AAIHB_AuditLog::log('sso_settings', 'aaihb-sso', 'ok', 'enabled=' . $new['enabled'] . ' issuer=' . $new['issuer'] . ' provision=' . $new['auto_provision']);
		wp_safe_redirect(admin_url('admin.php?page=aaihb-sso&saved=1')); exit;
	}

	public static function page() {
		if (!current_user_can(self::CAP) || !AAIHB_Beta::scope_ok()) {
			wp_die(__('管理者権限が必要です。', 'autorepair-ai-hosting-beta'), '', ['response' => 403]);
		}
		$c = self::cfg();
		$has_secret = (string) $c['secret'] !== '';
		$secret_ok = $has_secret ? (self::secret() !== '') : true;
		$redirect = self::redirect_uri();

		echo '<div class="wrap"><h1>' . esc_html__('SSO（OpenID Connect）', 'autorepair-ai-hosting-beta') . '</h1>';
		echo '<p>' . esc_html__('Entra ID（Azure AD）・Google Workspace・Okta など、OpenID Connect に対応した IdP でログインできるようにします。Authorization Code + PKCE（S256）を使います。', 'autorepair-ai-hosting-beta') . '</p>';

		if ($c['enabled']) {
			echo '<div class="notice notice-success inline"><p><strong>' . esc_html__('SSOは有効です。', 'autorepair-ai-hosting-beta') . '</strong> ';
			echo esc_html__('ログイン画面に「SSOでログイン」ボタンが出ます。通常のユーザー名／パスワードでのログインも残しています（SSO障害時の非常口）。', 'autorepair-ai-hosting-beta') . '</p></div>';
		} else {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__('SSOは無効です。ログイン画面はこれまでどおりです。', 'autorepair-ai-hosting-beta') . '</p></div>';
		}
		if (!$secret_ok) {
			echo '<div class="notice notice-error inline"><p>' . esc_html__('保存されているクライアントシークレットを復号できません。もう一度入力してください。', 'autorepair-ai-hosting-beta') . '</p></div>';
		}

		echo '<table class="form-table"><tr><th>' . esc_html__('IdPに登録するリダイレクトURI', 'autorepair-ai-hosting-beta') . '</th><td><code>' . esc_html($redirect) . '</code><p class="description">' . esc_html__('IdP 側のリダイレクトURIは、この文字列と完全に一致させてください（末尾スラッシュ・http/https・クエリの有無まで同じ）。', 'autorepair-ai-hosting-beta') . '</p></td></tr></table>';

		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field('aaihb_sso_save');
		echo '<input type="hidden" name="action" value="aaihb_sso_save">';
		echo '<table class="form-table">';

		echo '<tr><th>' . esc_html__('有効化', 'autorepair-ai-hosting-beta') . '</th><td><label><input type="checkbox" name="enabled" value="1"' . ($c['enabled'] ? ' checked' : '') . '> ' . esc_html__('SSOを有効にする', 'autorepair-ai-hosting-beta') . '</label></td></tr>';

		echo '<tr><th><label for="issuer">' . esc_html__('発行者（issuer）', 'autorepair-ai-hosting-beta') . '</label></th><td>';
		echo '<input type="url" class="regular-text" id="issuer" name="issuer" value="' . esc_attr($c['issuer']) . '" placeholder="https://login.microsoftonline.com/〈テナントID〉/v2.0">';
		echo '<p class="description">' . esc_html__('末尾に /.well-known/openid-configuration を付けて取得できるURLの手前まで。例: Google は https://accounts.google.com、Okta は https://〈ドメイン〉.okta.com', 'autorepair-ai-hosting-beta') . '</p></td></tr>';

		echo '<tr><th><label for="client_id">' . esc_html__('クライアントID', 'autorepair-ai-hosting-beta') . '</label></th><td><input type="text" class="regular-text" id="client_id" name="client_id" value="' . esc_attr($c['client_id']) . '"></td></tr>';

		echo '<tr><th><label for="secret">' . esc_html__('クライアントシークレット', 'autorepair-ai-hosting-beta') . '</label></th><td>';
		echo '<input type="password" class="regular-text" id="secret" name="secret" value="" autocomplete="new-password" placeholder="' . esc_attr($has_secret ? __('設定済み（変更するときだけ入力）', 'autorepair-ai-hosting-beta') : __('IdPで発行された値', 'autorepair-ai-hosting-beta')) . '">';
		if ($has_secret) {
			echo '<label style="margin-left:1em"><input type="checkbox" name="clear_secret" value="1"> ' . esc_html__('保存済みの値を消す', 'autorepair-ai-hosting-beta') . '</label>';
		}
		echo '<p class="description">' . esc_html__('AES-256-GCM で暗号化して保存します。画面には再表示しません。', 'autorepair-ai-hosting-beta') . '</p></td></tr>';

		echo '<tr><th><label for="redirect_uri">' . esc_html__('リダイレクトURI（任意）', 'autorepair-ai-hosting-beta') . '</label></th><td>';
		echo '<input type="url" class="regular-text" id="redirect_uri" name="redirect_uri" value="' . esc_attr($c['redirect_uri']) . '" placeholder="' . esc_attr($redirect) . '">';
		echo '<p class="description">' . esc_html__('空欄なら上に表示した既定値を使います。入力した場合は、この値がそのまま認可リクエストに使われます（自動変換しません）。', 'autorepair-ai-hosting-beta') . '</p></td></tr>';

		echo '<tr><th><label for="scopes">' . esc_html__('スコープ', 'autorepair-ai-hosting-beta') . '</label></th><td><input type="text" class="regular-text" id="scopes" name="scopes" value="' . esc_attr($c['scopes']) . '"><p class="description">' . esc_html__('openid は必須です。', 'autorepair-ai-hosting-beta') . '</p></td></tr>';

		echo '<tr><th>' . esc_html__('クレームの対応', 'autorepair-ai-hosting-beta') . '</th><td>';
		foreach ([['claim_login', __('ユーザー名', 'autorepair-ai-hosting-beta')], ['claim_email', __('メールアドレス', 'autorepair-ai-hosting-beta')], ['claim_name', __('表示名', 'autorepair-ai-hosting-beta')], ['claim_groups', __('グループ／ロール', 'autorepair-ai-hosting-beta')]] as $f) {
			echo '<p><label>' . esc_html($f[1]) . ' <input type="text" name="' . esc_attr($f[0]) . '" value="' . esc_attr($c[$f[0]]) . '" class="regular-text" style="max-width:22em"></label></p>';
		}
		echo '<p class="description">' . esc_html__('IdP が返すクレーム名に合わせてください。Entra ID のグループは groups、Okta は groups か roles のことがあります。', 'autorepair-ai-hosting-beta') . '</p></td></tr>';

		echo '<tr><th><label for="allowed_domains">' . esc_html__('許可ドメイン', 'autorepair-ai-hosting-beta') . '</label></th><td><input type="text" class="regular-text" id="allowed_domains" name="allowed_domains" value="' . esc_attr($c['allowed_domains']) . '" placeholder="example.co.jp, example.com"><p class="description">' . esc_html__('カンマ区切り。空欄なら制限しません。設定すると、このドメイン以外のメールではログインできません。', 'autorepair-ai-hosting-beta') . '</p></td></tr>';

		echo '<tr><th>' . esc_html__('トークン取得の認証方式', 'autorepair-ai-hosting-beta') . '</th><td><select name="token_auth">';
		foreach (['basic' => __('client_secret_basic（Authorizationヘッダ）', 'autorepair-ai-hosting-beta'), 'post' => __('client_secret_post（本文に含める）', 'autorepair-ai-hosting-beta')] as $v => $l) {
			echo '<option value="' . esc_attr($v) . '"' . ($c['token_auth'] === $v ? ' selected' : '') . '>' . esc_html($l) . '</option>';
		}
		echo '</select><p class="description">' . esc_html__('通常は basic のままで構いません。トークン取得が invalid_client で失敗する場合に post を試してください。', 'autorepair-ai-hosting-beta') . '</p></td></tr>';

		echo '<tr><th>' . esc_html__('ユーザーの扱い', 'autorepair-ai-hosting-beta') . '</th><td>';
		echo '<p><label><input type="checkbox" name="require_verified" value="1"' . ($c['require_verified'] ? ' checked' : '') . '> ' . esc_html__('メール確認済み（email_verified）だけを許可する', 'autorepair-ai-hosting-beta') . '</label></p>';
		echo '<p><label><input type="checkbox" name="auto_provision" value="1"' . ($c['auto_provision'] ? ' checked' : '') . '> ' . esc_html__('未登録ユーザーを自動作成する', 'autorepair-ai-hosting-beta') . '</label></p>';
		echo '<p><label><input type="checkbox" name="allow_admin" value="1"' . ($c['allow_admin'] ? ' checked' : '') . '> ' . esc_html__('administrator への自動割り当てを許可する（非推奨）', 'autorepair-ai-hosting-beta') . '</label></p>';
		echo '<p class="description">' . esc_html__('既存ユーザーのロールは SSO では変更しません。自動作成時のロールは下の対応表で決まります。未指定は subscriber です。', 'autorepair-ai-hosting-beta') . '</p></td></tr>';

		echo '<tr><th><label for="role_map">' . esc_html__('ロール対応表', 'autorepair-ai-hosting-beta') . '</label></th><td>';
		echo '<textarea id="role_map" name="role_map" rows="6" class="large-text code" placeholder="aaihb-operators=aaihb_recovery_operator&#10;wp-admins=administrator">' . esc_textarea($c['role_map']) . '</textarea>';
		echo '<p class="description">' . esc_html__('1行1件。「グループ値=WordPressのロール」の形。上から順に最初に一致したものを使います。', 'autorepair-ai-hosting-beta') . '</p></td></tr>';

		echo '</table>';
		echo '<p><button class="button button-primary" type="submit">' . esc_html__('保存', 'autorepair-ai-hosting-beta') . '</button></p>';
		echo '</form>';

		echo '<h2>' . esc_html__('動作確認', 'autorepair-ai-hosting-beta') . '</h2>';
		echo '<table class="widefat striped" style="max-width:900px"><tbody>';
		$rows = [
			[__('発行者', 'autorepair-ai-hosting-beta'), $c['issuer'] !== '' ? $c['issuer'] : __('未設定', 'autorepair-ai-hosting-beta')],
			[__('リダイレクトURI（実際に使う値）', 'autorepair-ai-hosting-beta'), $redirect],
			[__('シークレット', 'autorepair-ai-hosting-beta'), $has_secret ? ($secret_ok ? __('保存済み・復号可', 'autorepair-ai-hosting-beta') : __('保存済み・復号不可', 'autorepair-ai-hosting-beta')) : __('未設定', 'autorepair-ai-hosting-beta')],
			[__('ログイン画面', 'autorepair-ai-hosting-beta'), $c['enabled'] ? sprintf(__('SSOボタンあり（%s）', 'autorepair-ai-hosting-beta'), self::start_url()) : __('SSOボタンなし', 'autorepair-ai-hosting-beta')],
		];
		foreach ($rows as $r) {
			echo '<tr><td style="width:280px"><strong>' . esc_html($r[0]) . '</strong></td><td><code style="word-break:break-all">' . esc_html($r[1]) . '</code></td></tr>';
		}
		echo '</tbody></table>';
		echo '<p><a class="button" href="' . esc_url(self::start_url()) . '">' . esc_html__('SSOログインを試す', 'autorepair-ai-hosting-beta') . '</a> ';
		echo '<span class="description">' . esc_html__('現在ログイン中のままテストできます。失敗した場合はコード（例: id_token_bad_nonce）が表示され、監査ログにも残ります。', 'autorepair-ai-hosting-beta') . '</span></p>';
		echo '<p class="description">' . esc_html__('設定の変更・開始・失敗・ログイン成功は、すべて「監査ログ」に記録されます。', 'autorepair-ai-hosting-beta') . '</p>';
		echo '</div>';
	}
}
