<?php
if (!defined('ABSPATH')) { exit; }
/**
 * 監査ログ（追記型・改ざん検知つき）
 *
 * 企業の稟議で必ず聞かれる「誰が・いつ・何をしたか」「後から書き換えられないか」に
 * 答えるためのローカル実装です。外部サービスは不要で、CSV / JSON に書き出して
 * セキュリティチェックシートの提出資料や SIEM への取り込みに使えます。
 *
 * 各行は直前の行のハッシュを prev に持ち、自分のハッシュを hash に持ちます。
 * 途中の行を SQL で書き換え・削除すると、それ以降の検証が必ず失敗します。
 * 古い行の定期削除（保存期間）は先頭が欠けるだけなので、連結は保たれます。
 */
final class AAIHB_AuditLog {
    const OPT_ENABLED   = 'aaihb_audit_enabled';
    const OPT_RETENTION = 'aaihb_retention_days';
    const CRON          = 'aaihb_audit_prune';
    const DB_OPT        = 'aaihb_audit_db_version';
    const DB_VER        = '1';
    const LOCK          = 'aaihb_audit_lock';
    const DEFAULT_DAYS  = 180;
    const MAX_ROWS      = 5000;

    public static function table() {
        global $wpdb; return $wpdb->prefix . 'aaihb_audit';
    }

    public static function boot() {
        add_action('plugins_loaded', [__CLASS__, 'install']);
        add_action('admin_menu', function () {
            add_submenu_page('aaihb-home', __('監査ログ', 'autorepair-ai-hosting-beta'), __('監査ログ', 'autorepair-ai-hosting-beta'), 'manage_options', 'aaihb-audit', [__CLASS__, 'page']);
        });
        add_action('admin_post_aaihb_audit_export', [__CLASS__, 'export']);
        add_action('admin_post_aaihb_audit_save', [__CLASS__, 'save_settings']);
        add_action(self::CRON, [__CLASS__, 'prune']);

        add_action('wp_login', function ($login, $user = null) {
            $role = is_object($user) && isset($user->roles[0]) ? (string) $user->roles[0] : '';
            self::log('login_ok', (string) $login, 'ok', $role === '' ? '' : 'role=' . $role);
        }, 10, 2);
        add_action('wp_login_failed', function ($login) {
            self::log('login_failed', is_string($login) ? $login : '', 'fail');
        }, 10, 1);
        add_action('wp_logout', function () { self::log('logout', '', 'ok'); });

        // 設定変更（中央サーバー接続・権限初期化・保存期間など）
        foreach (['aaihb_central', 'aaihb_access_v1', 'aaihb_allow_multisite', self::OPT_ENABLED, self::OPT_RETENTION, 'aaihb_purge_on_uninstall'] as $opt) {
            add_action('update_option_' . $opt, function ($old, $new) use ($opt) {
                $keys = is_array($new) ? implode(',', array_slice(array_keys($new), 0, 12)) : 'scalar';
                self::log('option_change', $opt, 'ok', 'keys=' . $keys);
            }, 10, 2);
        }

        // プラグイン管理画面への POST は、項目名だけ記録します（値・トークンは記録しません）。
        add_action('admin_init', function () {
            if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') { return; }
            $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
            if ($page === '' || strpos($page, 'aaihb') !== 0) { return; }
            $keys = is_array($_POST) ? array_keys($_POST) : [];
            $keys = array_values(array_filter($keys, function ($k) {
                $k = strtolower((string) $k);
                return strpos($k, 'token') === false && strpos($k, 'pass') === false && strpos($k, 'secret') === false;
            }));
            self::log('admin_post', $page, 'ok', 'fields=' . implode(',', array_slice($keys, 0, 12)));
        });

        if (!wp_next_scheduled(self::CRON)) { wp_schedule_event(time() + 3600, 'daily', self::CRON); }
    }

    public static function install() {
        if (get_option(self::DB_OPT) === self::DB_VER) { return; }
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table(); $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            at VARCHAR(25) NOT NULL DEFAULT '',
            actor BIGINT UNSIGNED NOT NULL DEFAULT 0,
            actor_login VARCHAR(60) NOT NULL DEFAULT '',
            action VARCHAR(64) NOT NULL DEFAULT '',
            object VARCHAR(190) NOT NULL DEFAULT '',
            result VARCHAR(16) NOT NULL DEFAULT '',
            ip VARCHAR(45) NOT NULL DEFAULT '',
            detail_hash CHAR(64) NOT NULL DEFAULT '',
            prev CHAR(64) NOT NULL DEFAULT '',
            hash CHAR(64) NOT NULL DEFAULT '',
            detail TEXT NULL,
            PRIMARY KEY  (id),
            KEY at (at),
            KEY action (action)
        ) $charset_collate;";
        dbDelta($sql);
        update_option(self::DB_OPT, self::DB_VER, false);
    }

    public static function enabled() {
        return (bool) apply_filters('aaihb_audit_enabled', get_option(self::OPT_ENABLED, '1') === '1');
    }

    public static function retention_days() {
        $d = (int) get_option(self::OPT_RETENTION, self::DEFAULT_DAYS);
        return $d >= 30 ? $d : self::DEFAULT_DAYS;
    }

    /** 純粋関数：1 行分のハッシュ。テストはこれを直接呼びます。 */
    public static function chain_hash($prev, array $r) {
        return hash('sha256', implode('|', [
            (string) $prev,
            (string) ($r['at'] ?? ''),
            (string) ($r['actor'] ?? '0'),
            (string) ($r['action'] ?? ''),
            (string) ($r['object'] ?? ''),
            (string) ($r['result'] ?? ''),
            (string) ($r['detail_hash'] ?? ''),
        ]));
    }

    /** 純粋関数：連結の検証。gaps（削除の跡）と broken（改ざん）を分けて返します。 */
    public static function verify_rows(array $rows) {
        $prev = null; $checked = 0; $broken = []; $gaps = []; $last = 0;
        foreach ($rows as $r) {
            $checked++;
            $id = (int) ($r['id'] ?? 0);
            if ($last !== 0 && $id !== $last + 1) { $gaps[] = $id; }
            if ($prev !== null && (string) ($r['prev'] ?? '') !== $prev) { $broken[] = $id; }
            if (!hash_equals(self::chain_hash((string) ($r['prev'] ?? ''), $r), (string) ($r['hash'] ?? ''))) { $broken[] = $id; }
            // 補足文そのものが書き換えられていないか（detail_hash はハッシュに含まれるため、
            // 本文だけを差し替えても上の検証では捕まらない）
            if (array_key_exists('detail', $r) && !hash_equals(hash('sha256', (string) $r['detail']), (string) ($r['detail_hash'] ?? ''))) { $broken[] = $id; }
            $prev = (string) ($r['hash'] ?? ''); $last = $id;
        }
        $broken = array_values(array_unique($broken));
        return ['ok' => !$broken, 'checked' => $checked, 'broken' => $broken, 'gaps' => $gaps, 'head' => (string) ($prev ?? '')];
    }

    private static function lock() {
        for ($i = 0; $i < 60; $i++) {
            if (add_option(self::LOCK, time(), '', false)) { return true; }
            if ((int) get_option(self::LOCK, 0) > 0 && time() - (int) get_option(self::LOCK, 0) > 10) { delete_option(self::LOCK); continue; }
            usleep(15000);
        }
        return false;
    }

    private static function actor_login() {
        if (!function_exists('wp_get_current_user')) { return ''; }
        $u = wp_get_current_user();
        return is_object($u) && isset($u->user_login) ? substr((string) $u->user_login, 0, 60) : '';
    }

    private static function ip() {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
        return filter_var($ip, FILTER_VALIDATE_IP) ? substr($ip, 0, 45) : '';
    }

    public static function log($action, $object = '', $result = 'ok', $detail = '') {
        if (!self::enabled()) { return false; }
        global $wpdb;
        self::install();
        if (!self::lock()) { return false; }
        try {
            $prev = (string) $wpdb->get_var('SELECT hash FROM ' . self::table() . ' ORDER BY id DESC LIMIT 1');
            $detail = substr((string) $detail, 0, 500);
            $r = [
                'at' => gmdate('c'),
                'actor' => (int) get_current_user_id(),
                'actor_login' => self::actor_login(),
                'action' => substr(sanitize_key($action), 0, 64),
                'object' => substr(sanitize_text_field((string) $object), 0, 180),
                'result' => substr(sanitize_key($result), 0, 16),
                'ip' => self::ip(),
                'detail_hash' => hash('sha256', $detail),
                'prev' => $prev,
                'hash' => '',
                'detail' => $detail,
            ];
            $r['hash'] = self::chain_hash($prev, $r);
            return (bool) $wpdb->insert(self::table(), $r);
        } finally {
            delete_option(self::LOCK);
        }
    }

    public static function rows($limit = 200, $offset = 0) {
        global $wpdb;
        $limit = max(1, min(self::MAX_ROWS, (int) $limit)); $offset = max(0, (int) $offset);
        $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . self::table() . ' ORDER BY id ASC LIMIT %d OFFSET %d', $limit, $offset), ARRAY_A);
        return is_array($rows) ? $rows : [];
    }

    public static function recent($limit = 50) {
        global $wpdb;
        $limit = max(1, min(self::MAX_ROWS, (int) $limit));
        $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . self::table() . ' ORDER BY id DESC LIMIT %d', $limit), ARRAY_A);
        return is_array($rows) ? array_reverse($rows) : [];
    }

    /** 保存期間を超えた行を削除（先頭から欠けるだけなので連結は保たれます）。 */
    public static function prune() {
        global $wpdb;
        $cut = gmdate('c', time() - self::retention_days() * 86400);
        $deleted = $wpdb->query($wpdb->prepare('DELETE FROM ' . self::table() . ' WHERE at < %s', $cut));
        update_option('aaihb_audit_pruned_at', gmdate('c'), false);
        return (int) $deleted;
    }

    private static function csv_safe($v) {
        $v = (string) $v;
        return ($v !== '' && strpos('=+-@', $v[0]) !== false) ? "'" . $v : $v;
    }

    public static function save_settings() {
        if (!current_user_can('manage_options') || !AAIHB_Beta::scope_ok()) {
            wp_die(__('管理者権限が必要です。', 'autorepair-ai-hosting-beta'), '', ['response' => 403]);
        }
        check_admin_referer('aaihb_audit_save');
        update_option(self::OPT_ENABLED, (isset($_POST['aaihb_audit_on']) && $_POST['aaihb_audit_on'] === '1') ? '1' : '0', false);
        $days = isset($_POST['aaihb_retention']) ? (int) $_POST['aaihb_retention'] : self::DEFAULT_DAYS;
        update_option(self::OPT_RETENTION, max(30, min(3650, $days)), false);
        self::log('audit_settings', 'aaihb-audit', 'ok', 'enabled=' . get_option(self::OPT_ENABLED) . ' days=' . get_option(self::OPT_RETENTION));
        wp_safe_redirect(admin_url('admin.php?page=aaihb-audit&saved=1')); exit;
    }

    public static function export() {
        if (!current_user_can('manage_options') || !AAIHB_Beta::scope_ok()) {
            wp_die(__('管理者権限が必要です。', 'autorepair-ai-hosting-beta'), '', ['response' => 403]);
        }
        check_admin_referer('aaihb_audit_export');
        $fmt = (isset($_GET['format']) && $_GET['format'] === 'json') ? 'json' : 'csv';
        $rows = self::rows(self::MAX_ROWS, 0);
        $check = self::verify_rows($rows);
        self::log('audit_export', $fmt, 'ok', 'rows=' . count($rows) . ' chain=' . ($check['ok'] ? 'ok' : 'broken'));
        nocache_headers();
        $stamp = gmdate('Ymd-His');
        if ($fmt === 'json') {
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="aaihb-audit-' . $stamp . '.json"');
            echo wp_json_encode(['generated_at' => gmdate('c'), 'retention_days' => self::retention_days(), 'chain' => $check, 'rows' => $rows]);
            exit;
        }
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="aaihb-audit-' . $stamp . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['id', 'at', 'actor', 'actor_login', 'action', 'object', 'result', 'ip', 'chain', 'prev', 'hash', 'detail']);
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['id'], self::csv_safe($r['at']), $r['actor'], self::csv_safe($r['actor_login']),
                self::csv_safe($r['action']), self::csv_safe($r['object']), self::csv_safe($r['result']),
                self::csv_safe($r['ip']), $check['ok'] ? 'ok' : 'broken',
                $r['prev'], $r['hash'], self::csv_safe($r['detail']),
            ]);
        }
        fclose($out);
        exit;
    }

    public static function page() {
        if (!current_user_can('manage_options') || !AAIHB_Beta::scope_ok()) {
            wp_die(__('管理者権限が必要です。', 'autorepair-ai-hosting-beta'), '', ['response' => 403]);
        }
        $rows = self::recent(50);
        $check = self::verify_rows(self::rows(self::MAX_ROWS, 0));
        $on = get_option(self::OPT_ENABLED, '1') === '1';
        $days = self::retention_days();
        $csv = wp_nonce_url(admin_url('admin-post.php?action=aaihb_audit_export&format=csv'), 'aaihb_audit_export');
        $json = wp_nonce_url(admin_url('admin-post.php?action=aaihb_audit_export&format=json'), 'aaihb_audit_export');
        echo '<div class="wrap"><h1>' . esc_html__('監査ログ', 'autorepair-ai-hosting-beta') . '</h1>';
        echo '<p>' . esc_html__('誰が・いつ・何をしたかを追記型で記録します。各行は前の行のハッシュにつながっており、途中の書き換え・削除は検証で検出されます。', 'autorepair-ai-hosting-beta') . '</p>';
        echo '<p><strong>' . esc_html__('連結の検証', 'autorepair-ai-hosting-beta') . '：';
        echo $check['ok'] ? esc_html__('正常', 'autorepair-ai-hosting-beta') : esc_html__('異常（改ざんの可能性）', 'autorepair-ai-hosting-beta');
        echo '</strong> ' . esc_html(sprintf(__('検証 %1$d 行 / 欠番 %2$d 件', 'autorepair-ai-hosting-beta'), (int) $check['checked'], count($check['gaps']))) . '</p>';
        if (!$check['ok']) {
            echo '<div class="notice notice-error inline"><p>' . esc_html(sprintf(__('整合しない行 ID: %s', 'autorepair-ai-hosting-beta'), implode(', ', array_slice($check['broken'], 0, 20)))) . '</p></div>';
        }
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('aaihb_audit_save');
        echo '<input type="hidden" name="action" value="aaihb_audit_save">';
        echo '<table class="form-table"><tr><th>' . esc_html__('記録する', 'autorepair-ai-hosting-beta') . '</th><td><label><input type="checkbox" name="aaihb_audit_on" value="1"' . ($on ? ' checked' : '') . '> ' . esc_html__('監査ログを有効にする', 'autorepair-ai-hosting-beta') . '</label></td></tr>';
        echo '<tr><th>' . esc_html__('保存期間（日）', 'autorepair-ai-hosting-beta') . '</th><td><input type="number" min="30" max="3650" name="aaihb_retention" value="' . (int) $days . '" class="small-text"> ' . esc_html__('30〜3650日。毎日自動で古い行を削除します。', 'autorepair-ai-hosting-beta') . '</td></tr></table>';
        echo '<p><button class="button button-primary" type="submit">' . esc_html__('保存', 'autorepair-ai-hosting-beta') . '</button> ';
        echo '<a class="button" href="' . esc_url($csv) . '">' . esc_html__('CSV書き出し', 'autorepair-ai-hosting-beta') . '</a> ';
        echo '<a class="button" href="' . esc_url($json) . '">' . esc_html__('JSON書き出し（検証結果つき）', 'autorepair-ai-hosting-beta') . '</a></p>';
        echo '</form>';
        echo '<h2>' . esc_html__('直近 50 件', 'autorepair-ai-hosting-beta') . '</h2>';
        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>' . esc_html__('日時(UTC)', 'autorepair-ai-hosting-beta') . '</th><th>' . esc_html__('操作者', 'autorepair-ai-hosting-beta') . '</th><th>' . esc_html__('操作', 'autorepair-ai-hosting-beta') . '</th><th>' . esc_html__('対象', 'autorepair-ai-hosting-beta') . '</th><th>' . esc_html__('結果', 'autorepair-ai-hosting-beta') . '</th><th>IP</th><th>' . esc_html__('補足', 'autorepair-ai-hosting-beta') . '</th></tr></thead><tbody>';
        if (!$rows) {
            echo '<tr><td colspan="8">' . esc_html__('まだ記録はありません。', 'autorepair-ai-hosting-beta') . '</td></tr>';
        }
        foreach ($rows as $r) {
            echo '<tr><td>' . (int) $r['id'] . '</td><td>' . esc_html($r['at']) . '</td><td>' . esc_html($r['actor_login'] !== '' ? $r['actor_login'] : '#' . (int) $r['actor']) . '</td><td>' . esc_html($r['action']) . '</td><td>' . esc_html($r['object']) . '</td><td>' . esc_html($r['result']) . '</td><td>' . esc_html($r['ip']) . '</td><td>' . esc_html($r['detail']) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
}
