<?php
if(!defined('ABSPATH'))exit;
/** Explicitly acknowledged full-backup queue. It never runs without user approval. */
final class AAIHB_BackupJobs {
 const JOB='aaihb_full_backup_job';
 public static function boot(){add_action('aaihb_full_backup_run',[__CLASS__,'run']);}
 public static function enqueue(){if(get_option(self::JOB))throw new RuntimeException('すでにバックアップが予約済みまたは実行中です。');$job=['status'=>'queued','queued_at'=>gmdate('c'),'finished_at'=>'','id'=>'','message'=>''];update_option(self::JOB,$job,false);if(!wp_schedule_single_event(time()+5,'aaihb_full_backup_run')){delete_option(self::JOB);throw new RuntimeException('バックアップ予約を作成できません。WP-Cronの設定を確認してください。');}}
 public static function run(){$job=get_option(self::JOB,[]);if(!is_array($job)||($job['status']??'')!=='queued')return;$job['status']='running';update_option(self::JOB,$job,false);try{$job['id']=AAIHB_FullSite::backup();$job['status']='passed';$job['message']='サイト全体バックアップを作成しました。';}catch(Throwable $e){$job['status']='failed';$job['message']='バックアップを作成できませんでした。保管先・容量・書き込み停止を確認してください。';}$job['finished_at']=gmdate('c');update_option(self::JOB,$job,false);}
 public static function latest(){ $v=get_option(self::JOB,[]);return is_array($v)?$v:[]; }
}
