=== AutoRepair AI Hosting Beta ===
Contributors: masa45594
Tags: backup, restore, diagnostics, maintenance, monitoring
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.20.50
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Independent diagnostics, recovery and isolated restore rehearsal for WordPress, with backup status verified separately and usage metered against a central service.

== Description ==

AutoRepair AI Hosting Beta is a standalone plugin. It does not require the
AutoRepair AI service to run its diagnostics, backup and restore rehearsal.

* **Diagnostics** — checks PHP, MySQL/MariaDB, ZipArchive, storage and the
  isolated rehearsal prerequisites, and lists what is ready and what is not.
* **Backup** — full site backup scheduled from the admin screen, with an
  explicit write-freeze confirmation.
* **Isolated restore rehearsal** — restores a save point into a quarantined
  environment and verifies the front page, admin access and the database
  connection. The production site is never modified by a rehearsal.
* **Update protection** — records the state before an update and can roll the
  plugin change back.
* **Central usage metering** — an optional hub token links this site to a
  central service that counts registered sites and reports the estimate.

Restoring the live site is always a manual, confirmed action. Rehearsals run in
isolation only.

= Update feed =

The plugin reads its own update manifest over HTTPS. The default location is

    https://raw.githubusercontent.com/masa45594-crypto/autorepair-central/main/update.json

and it can be changed by setting the `aaihb_update_feed` option. The manifest
must be HTTPS and contain `version` and a HTTPS `download_url`. When the feed
offers a newer version, the update appears on the Plugins screen and installs
through the normal WordPress updater.

= Languages =

Source strings are Japanese. The plugin ships a translation template
(`languages/autorepair-ai-hosting-beta.pot`) and an English catalogue
(`languages/autorepair-ai-hosting-beta-en_US.po` / `.mo`). Strings that are not
yet wrapped in a translation function stay in Japanese.

== Installation ==

1. Upload the plugin zip through Plugins → Add New → Upload Plugin, or extract
   it into `wp-content/plugins/`.
2. Activate **AutoRepair AI Hosting Beta**.
3. Open the **AI運用ホーム** menu and follow **はじめる**.
4. Optional: open **利用数と料金** and paste the hub token to link the site to
   the central service.

== Frequently Asked Questions ==

= Does a rehearsal touch my live site? =

No. A rehearsal restores into a quarantined environment. Restoring the live
site is a separate, manually confirmed action.

= What happens when I delete the plugin? =

`uninstall.php` removes this plugin's options, transients, scheduled events and
its own table. On multisite the cleanup runs for every site on the network.

= Which databases are supported? =

MySQL 8.x and MariaDB 10.5 or newer, InnoDB tables only. The database version
is read from the server with `SELECT VERSION()`, not from the WordPress
abbreviated number.

== Screenshots ==

1. Diagnostics overview
2. Backup and restore rehearsal
3. Usage and billing

== Changelog ==

= 0.20.50 =

* 「かんたん接続」にCSV一括登録を追加。1行目を name,endpoint,token の見出しにしたCSVをアップロードすると、各行を貼り付け欄と同じ検証（`parse()`）に通し、既存の登録処理（`save_site()` として共通化）で順次登録します。
* 失敗した行だけ理由を返し、結果をその場の表とダウンロード可能なCSV（UTF-8 BOM付き）で出力します。トークンは結果CSVで先頭4桁と末尾4桁のみ表示し、ブラウザーに全文を戻しません。
* Excel由来のUTF-8 BOM・Shift_JIS（CP932）・UTF-16LEを自動判定してUTF-8に正規化。引用符付きフィールド、日本語の見出し（サイト名／接続先／トークン）にも対応。
* 1行300件・512KBの上限、同一接続先URLの重複検出、CSV数式インジェクション対策（先頭 `= + - @` の無害化）を追加。

= 0.20.49 =

* 配布zipから開発用の tests/ を除外し、Plugin Check の指摘 416 件（エラー81・警告335）を削減。
* サイト登録テーブルの読み取りを60秒キャッシュし、管理画面での重複クエリを削減（書き込み時に即時破棄）。

= 0.20.48 =
* 中央サーバーの拠点トークンが復号できないとき、拠点一覧・Stripeテスト画面・登録確認が致命的エラーで停止していた不具合を修正しました（0.20.46 の修正を残りの呼び出し箇所にも適用）。
* 復号できないときは「未接続」と同じ扱いにするため、管理画面は開いたまま操作できます。
* README-JA.md の版数表記と TEST-RESULTS.md のファイル数を実測に合わせました。

= 0.20.47 =
* Central connection: use a separate management token to issue a new hub token or safely replace a lost hub token. The prior hub token is never revealed and is invalidated during replacement.

= 0.20.46 =
* 重大な不具合を修正しました。中央サービスの拠点トークンが復号できない状態（サイトの移行・復元、暗号ソルトの変更など）のとき、管理画面を開くと致命的エラーで全体が停止していました。復号に失敗した場合は通信不可時と同じ安全な扱いにし、管理画面を止めずに前回の契約判定を保持するようにしました。

= 0.20.45 =
* テスト用ファイル（tests/contracts.php）に WordPress の関数スタブを追加しました。プラグイン本体の動作に変更はありません。GitHub Actions の unit ジョブが試用版の zip を最新版として選んだときに、未定義関数で停止していた問題を解消します。

= 0.20.44 =
* 契約状態の確認を中央サービス経由で行うようにしました。拠点トークンを登録すると、有効な契約では試用終了後も自動で有料機能が使えます（「契約状態を今すぐ確認する」ボタン付き）。

= 0.20.43 =
* 「4. 申し込み」のボタンを、お申し込み用の1つに整理しました。すでにご契約中のお客様向けの「契約と支払いを確認する」は、説明文つきのリンクとして表示します。

= 0.20.42 =
* 試用案内バナーの「料金と申し込み」リンクを、アップグレード画面の「4. 申し込み」へ直接ジャンプするようにしました。

= 0.20.41 =
* アップグレード画面に「契約と支払いを確認する」ボタンを追加し、Stripe のカスタマーポータル（ログインリンク）に接続しました。お客様が自分で解約・支払い方法の変更・請求書の確認を行えます。

= 0.20.40 =
* アップグレード画面の「お申し込み」ボタンの行き先を、既に本番で稼働している申し込みページ（中央サービス /signup）に接続しました。Stripe の決済用リンクを新しく作る必要はありません。

= 0.20.39 =
* 管理画面の試用案内バナーの文字色を濃くし、背景色を固定して、暗い配色の管理画面でも読めるようにしました。

= 0.20.38 =
* Documentation and admin UI only (no functional change). The three operations screens now
carry a built-in Japanese manual: what the screen is for, step-by-step instructions, the
meaning of each status and term, what to do when a warning appears, and links to related
screens. It is shown as collapsible sections, with the steps open first.
* Added on the "All sites" home screen, "Protect" and "Respond". All text is escaped on
output and nothing is sent anywhere.

= 0.20.37 =
* Fix: the licence screen's yen estimate now uses the same basis as the charge. Yen was
derived from the month's peak site count while USD -- and the actual invoice -- charges only
the sites above the plan's allowance, so from the 11th site the yen line overstated the
amount (11 sites showed about 9,780 yen for a $32.00 charge). Yen is now base + unit x
billable sites, so 11 sites read about 5,050 yen.
* Fix: a spending cap could trip on money that was never charged, because the cap compared
the peak-based yen figure rather than the billable one.
* The plugin's central-server integrity check now accepts the corrected basis (peak minus the
plan's included sites), so a hub running this version stays in sync with the central service.
* Central service (central-service/): status() and export() derive their yen fields, and the
export amount_yen, from the billable-site basis; test_service.py adds a regression test and
the full suite (59 tests) passes.

= 0.20.36 =
* Documentation only (no functional change). Corrected a stale note in the 0.16.0 changelog of README-JA.md that still said Stripe billing was available only with test-mode settings and that Paddle was in preparation. Stripe runs in live mode; Paddle remains in preparation.

= 0.20.35 =
* Documentation only (no functional change). Corrected the start-here guide, which still said Stripe was only a test-mode draft and that live automatic billing was not enabled. Stripe now runs in live mode: up to 10 sites for $29.00 per month, and $3.00 per site per month from the 11th site, reported to the usage meter.

= 0.20.34 =
* Documentation only (no functional change). Updated the version stamp in THIRD-PARTY-NOTICES.md to 0.20.34.
* Recorded the 0.20.33 yen-conversion fix in this changelog. The licence screen now converts yen from the billable site count, so a $29.00/month plan (up to 10 sites) shows about 4,577 yen at 157.83 yen/USD instead of about 5,523 yen.

= 0.20.33 =

* Fix: the licence screen showed the monthly estimate in yen for the maximum site count, so a $29.00 bill was displayed next to a yen figure for $35. The yen line now follows the billable sites, the same basis as the dollar figure, and the breakdown names additional sites.
* Version: aligned the plugin header, version constant, asset version and readme Stable tag to 0.20.33.

= 0.20.32 =

* Fix: the licence screen described the extra-site charge as a Stripe subscription item synchronised before registration. Extra sites are reported to Stripe's usage meter at registration, so the wording now matches the billing code.
* Version: aligned the plugin header, version constant, asset version and readme Stable tag to 0.20.32.

= 0.20.31 =

* Distribution: the plugin zip now bundles `LICENSE` (GNU GPL v2.0 full text) and `THIRD-PARTY-NOTICES.md`, so a downloaded copy carries its own licence text.
* Docs: added a licence section to README-JA.md. No functional change.

= 0.20.30 =
* Docs: the start-here guide described a two-level package (an outer zip holding a plugin zip). The distribution is a single zip whose root is autorepair-ai-hosting-beta/, so the guide now matches the real upload flow.
* Version: aligned the plugin header, version constant, asset version and readme Stable tag to 0.20.30.

= 0.20.29 =
* Docs: the current guides no longer name an old release. The start-here guide, the vault guide and the restore-test results heading carried version numbers from older builds.
* Docs: the distribution pointer now names the current package, and the Japanese readme opens with the current version instead of an old release heading.
* Version: aligned the plugin header, version constant, asset version and readme Stable tag to 0.20.29.

= 0.20.28 =
* Docs: the isolated restore-test guide now builds the runner image with the tag the code actually looks for (aaihb-restore-test:0.20.6). The guide said 0.14.2, so following it left every reader at "test environment not ready".
* Docs: removed the stale version numbers from the restore-test guide title and its first preparation step.
* Package: removed stray __pycache__ bytecode from the distribution.
* Version: aligned the plugin header, version constant, asset version and readme Stable tag to 0.20.28.

= 0.20.26 =
* selfserve.php（かんたん接続・購入/契約・困ったとき）の英語化：日本語 108 箇所を翻訳関数で包み、英語カタログへ追加。

= 0.20.26 =
* vault-admin.php（バックアップ・復元）の英語化：日本語 142 箇所を翻訳関数で包み、英語カタログへ追加。

= 0.20.26 =
* value.php の英語化（日本語 190 箇所）
* 接続情報の自動復元（暗号化ミラー）と送信番号ズレ（409）の自動再試行

= 0.20.16 =
* English translations for quick connect, usage and billing, hub management, troubleshooting, test checkout, and built-in diagnostic panel.
* Preserves the non-destructive uninstall behavior and all existing connection data.
* Other administration modules remain partially untranslated.


= 0.20.15 =
* Added a self-hosted update feed: the plugin now offers and installs its own
  updates from an HTTPS manifest (`pre_set_site_transient_update_plugins`,
  `plugins_api`), with a cached manifest and HTTPS-only validation.
* Added translation support: `load_plugin_textdomain` on `init`, a `.pot`
  template and an English catalogue, with the admin menu labels wrapped.
* Added `uninstall.php`, which removes this plugin's options, transients,
  scheduled events and its own table, including multisite.
* Added this `readme.txt` in the WordPress format.

= 0.20.12 =
* The plan pricing card now shows the measured amount from the central service
  (for example `$29.00`) instead of a fixed string, with the monthly estimate,
  billable site count and yen equivalent.
* Response validation accepts the USD (`currency=usd`) payload and re-checks
  `billable_sites` and `estimate_usd_cents`; legacy yen responses still pass.
* Central pricing and monthly reconciliation now work in USD cents.

= 0.20.11 =
* "Last sync" is shown in the site time zone; the raw UTC value stays in the
  tooltip.

= 0.20.10 =
* Reconnect form can replace the hub token; suspended connections open the
  reconnect panel automatically.
* Hubs can be listed and revoked from the admin screen, and a hub token can be
  issued for another domain without the server shell.
* Central server: `GET /v1/manage/hubs`, `POST /v1/manage/hubs/revoke` and the
  unreceived-webhook alert loop.

== Upgrade Notice ==

= 0.20.15 =
Adds self-hosted updates, translation support and a proper uninstall routine.
No configuration change is required.

== 試用版について ==

この配布物は 7日間フルトライアル版です。

* 有効化した日から 7日間、すべての機能を制限なく使えます。
* 8日目からは、一括管理・自動修復・通知・パートナーAPI・エージェントAPI などの有料機能が停止します。診断・履歴の閲覧・バックアップは引き続き使えます。
* 料金は月額 $29.00（管理サイト10件まで）、11件目から1件あたり $3.00 です。
* 管理画面「AutoRepair AI」→「アップグレード」から申し込みとライセンス登録ができます。

この版は WordPress.org の公式ディレクトリには提出できません（試用期間後に機能を停止する仕組みは、公式ディレクトリのガイドライン5「Trialware is not permitted」に該当します）。
