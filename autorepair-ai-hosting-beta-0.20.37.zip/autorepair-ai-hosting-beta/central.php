<?php
if(!defined('ABSPATH'))exit;
final class AAIHB_Central {
 const OPT='aaihb_central';
 public static function settings(){
  // Self-heal: keep an encrypted mirror of the endpoint and token, and restore the connection
  // automatically when the settings are wiped (destructive uninstall, failed migration, ...).
  $__m=get_option('aaihb_central_mirror',[]);$__s=get_option(self::OPT,[]);
  if(!is_array($__m))$__m=[];if(!is_array($__s))$__s=[];
  if(!empty($__s['url'])&&!empty($__s['token'])){if(empty($__m['url']))update_option('aaihb_central_mirror',['url'=>$__s['url'],'token'=>$__s['token']],false);}
  elseif(!empty($__m['url'])&&!empty($__m['token'])){
   $__s['url']=$__m['url'];$__s['token']=$__m['token'];
   if(!isset($__s['result'])||!is_array($__s['result']))$__s['result']=[];
   if(!isset($__s['error']))$__s['error']='';
   if($__s['error']==='')$__s['error']=(__('接続情報をバックアップから自動復元しました。','autorepair-ai-hosting-beta'));
   update_option(self::OPT,$__s,false);
  }return wp_parse_args(get_option(self::OPT,[]),['url'=>'','token'=>'','error'=>'','result'=>[]]);}
 public static function boot(){add_action('admin_post_aaihb_central',[__CLASS__,'save']);add_action('aaihb_registry_saved',[__CLASS__,'enqueue']);add_action('aaihb_central_tick',[__CLASS__,'sync']);add_action('aaihb_central_drain',[__CLASS__,'sync']);add_action('init',function(){if(!wp_next_scheduled('aaihb_central_tick'))wp_schedule_event(time()+60,'hourly','aaihb_central_tick');});}
 public static function configured(){ $s=self::settings();return $s['url']!==''&&$s['token']!==''; }
 public static function authorize_registration($id){
  if(!self::configured())throw new RuntimeException((__('中央サーバーへ接続してください。','autorepair-ai-hosting-beta')));
  if(!preg_match('/^[a-f0-9]{64}$/D',$id))throw new RuntimeException((__('サイト識別子を検証できません。','autorepair-ai-hosting-beta')));
  $s=self::settings();$token=AAIHB_Beta::crypt($s['token'],true);
  $r=wp_safe_remote_post($s['url'].'/v1/registration-check',['timeout'=>20,'redirection'=>0,'sslverify'=>true,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],'body'=>wp_json_encode(['site'=>$id])]);
  $code=is_wp_error($r)?0:wp_remote_retrieve_response_code($r);
  if($code!==200)throw new RuntimeException((__('追加サイトの料金確認を完了できないため、登録を停止しました。契約・Stripe・中央サーバーの状態を確認してください。','autorepair-ai-hosting-beta')));
  $data=json_decode(wp_remote_retrieve_body($r),true);
  if(!is_array($data)||($data['allowed']??false)!==true||!is_int($data['current']??null)||!is_int($data['included_sites']??null)||!is_array($data['billing_sync']??null))throw new RuntimeException((__('追加サイトの料金応答を検証できないため、登録を停止しました。','autorepair-ai-hosting-beta')));
  return $data;
 }
 public static function test_checkout_url($success,$cancel){
  if(!self::configured())throw new RuntimeException((__('先に中央サーバーへ接続してください。','autorepair-ai-hosting-beta')));
  if(!is_ssl())throw new RuntimeException((__('管理画面をHTTPSで開いてください。','autorepair-ai-hosting-beta')));
  $s=self::settings();$token=AAIHB_Beta::crypt($s['token'],true);
  $r=wp_safe_remote_post($s['url'].'/v1/stripe/test-checkout',['timeout'=>20,'redirection'=>0,'sslverify'=>true,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],'body'=>wp_json_encode(['success_url'=>$success,'cancel_url'=>$cancel])]);
  if(is_wp_error($r))throw new RuntimeException((__('Stripeテスト決済を開始できません。中央サーバーの設定を確認してください。','autorepair-ai-hosting-beta')));
  $code=wp_remote_retrieve_response_code($r);
  if($code===409)throw new RuntimeException((__('すでに有効なテスト契約があります。Stripeテスト用ポータルから契約を管理できます。','autorepair-ai-hosting-beta')));
  if($code!==200)throw new RuntimeException((__('Stripeテスト決済を開始できません。中央サーバーの設定を確認してください。','autorepair-ai-hosting-beta')));
  $data=json_decode(wp_remote_retrieve_body($r),true);$url=is_array($data)?($data['checkout_url']??''):'';$p=wp_parse_url($url);
  if(($data['mode']??'')!=='test'||!is_string($url)||!$p||($p['scheme']??'')!=='https'||($p['host']??'')!=='checkout.stripe.com'||isset($p['user'])||isset($p['pass']))throw new RuntimeException((__('Stripeテスト決済URLを検証できません。','autorepair-ai-hosting-beta')));
  return $url;
 }
 public static function stripe_test_status(){
  if(!self::configured())return ['status'=>'not_connected','updated'=>''];
  $s=self::settings();$token=AAIHB_Beta::crypt($s['token'],true);
  $r=wp_safe_remote_get($s['url'].'/v1/stripe/test-status',['timeout'=>15,'redirection'=>0,'sslverify'=>true,'headers'=>['Authorization'=>'Bearer '.$token]]);
  if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)throw new RuntimeException((__('Stripeテスト契約の状態を取得できません。','autorepair-ai-hosting-beta')));
  $data=json_decode(wp_remote_retrieve_body($r),true);$status=is_array($data)?($data['subscription_status']??''):'';$updated=is_array($data)?($data['updated']??''):'';$pending=is_array($data)?($data['cancellation_pending']??false):false;$at=is_array($data)?($data['cancellation_at']??0):0;
  if(($data['mode']??'')!=='test'||!is_string($status)||!is_string($updated)||!is_bool($pending)||!is_int($at)||$at<0||!in_array($status,['','active','trialing','past_due','unpaid','canceled','incomplete','incomplete_expired'],true))throw new RuntimeException((__('Stripeテスト契約の状態を検証できません。','autorepair-ai-hosting-beta')));
  return ['status'=>$status?:'none','updated'=>$updated,'cancellation_pending'=>$pending,'cancellation_at'=>$at];
 }
 public static function stripe_test_portal_url($return){
  if(!self::configured())throw new RuntimeException((__('先に中央サーバーへ接続してください。','autorepair-ai-hosting-beta')));
  if(!is_ssl())throw new RuntimeException((__('管理画面をHTTPSで開いてください。','autorepair-ai-hosting-beta')));
  $s=self::settings();$token=AAIHB_Beta::crypt($s['token'],true);
  $r=wp_safe_remote_post($s['url'].'/v1/stripe/test-portal',['timeout'=>20,'redirection'=>0,'sslverify'=>true,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],'body'=>wp_json_encode(['return_url'=>$return])]);
  if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)throw new RuntimeException((__('Stripeテスト用ポータルを開けません。Stripe側のポータル設定を確認してください。','autorepair-ai-hosting-beta')));
  $data=json_decode(wp_remote_retrieve_body($r),true);$url=is_array($data)?($data['portal_url']??''):'';$p=wp_parse_url($url);
  if(($data['mode']??'')!=='test'||!is_string($url)||!$p||($p['scheme']??'')!=='https'||($p['host']??'')!=='billing.stripe.com'||isset($p['user'])||isset($p['pass']))throw new RuntimeException((__('Stripeテスト用ポータルURLを検証できません。','autorepair-ai-hosting-beta')));
  return $url;
 }
 public static function url($url){$p=wp_parse_url($url);if(!$p||($p['scheme']??'')!=='https'||!wp_http_validate_url($url)||isset($p['user'])||isset($p['pass'])||isset($p['query'])||isset($p['fragment'])||(isset($p['port'])&&$p['port']!==443))throw new RuntimeException((__('公開HTTPSの中央サーバーURLを入力してください。','autorepair-ai-hosting-beta')));return rtrim(esc_url_raw($url),'/');}
 public static function enqueue($ignored=null){
  if(!self::configured())return;
  if(!add_option('aaihb_central_lock',time(),'',false)){update_option('aaihb_central_gap',true,false);return;}
  try{
   $ids=array_keys(AAIHB_Beta::sites());sort($ids);$q=get_option('aaihb_central_queue',[]);
   $last=$q?end($q):null;
   if($last&&$last['sites']===$ids)return;
   $seq=(int)get_option('aaihb_central_seq',0)+1;
   $q[]=['sequence'=>$seq,'sites'=>$ids];
   if(!update_option('aaihb_central_queue',$q,false))throw new RuntimeException((__('利用数の送信待ち記録を保存できません。','autorepair-ai-hosting-beta')));
   update_option('aaihb_central_seq',$seq,false);if(!wp_next_scheduled('aaihb_central_drain'))wp_schedule_single_event(time()+10,'aaihb_central_drain');
  }catch(Throwable $e){update_option('aaihb_central_gap',true,false);$s=self::settings();$s['error']=(__('利用数の記録を確認してください。','autorepair-ai-hosting-beta'));update_option(self::OPT,$s,false);}
  finally{delete_option('aaihb_central_lock');}
 }
 public static function sync(){
  if(!self::configured())return;
  if(!add_option('aaihb_central_send_lock',time(),'',false))return;
  try{
   $s=self::settings();$q=get_option('aaihb_central_queue',[]);$token=AAIHB_Beta::crypt($s['token'],true);
   $batch=$q?[$q[0]]:[];
   $args=['timeout'=>15,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>16000,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json']];
   if($batch){$args['method']='POST';$args['body']=wp_json_encode($batch[0]);$path='/v1/snapshot';}else{$args['method']='GET';$path='/v1/usage';}
   $r=wp_safe_remote_request($s['url'].$path,$args);
   $code=is_wp_error($r)?0:wp_remote_retrieve_response_code($r);
   if($code===401){update_option('aaihb_central_suspended',true,false);throw new RuntimeException((__('中央サーバーが接続を拒否しました(契約停止または認証情報の誤りの可能性)。解消するまで新しいサイトの登録を停止します。','autorepair-ai-hosting-beta')));}
      if($code===409&&$batch){
    // A 409 means the hub has already accepted a higher send number (for example after the local
    // counter was lost together with the connection settings). It is not a user error: read the
    // hub's current number with a plain GET, realign the local counter and retry the same batch.
    // Without this the site stays stuck on the pending queue forever.
    $g=wp_safe_remote_request($s['url'].'/v1/usage',['method'=>'GET','timeout'=>15,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>16000,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json']]);
    $gd=is_wp_error($g)?null:json_decode(wp_remote_retrieve_body($g),true);
    $exp=is_array($gd)?(int)($gd['sequence']??0):0;
    if($exp>0){
     $q2=get_option('aaihb_central_queue',[]);
     if(is_array($q2)&&$q2&&$q2[0]['sequence']===$batch[0]['sequence']){
      $q2[0]['sequence']=$exp+1;update_option('aaihb_central_queue',$q2,false);
      update_option('aaihb_central_seq',$exp+1,false);
      if(!wp_next_scheduled('aaihb_central_drain'))wp_schedule_single_event(time()+10,'aaihb_central_drain');
      return;
     }
    }
    throw new RuntimeException((__('送信番号を自動調整できませんでした。時間をおいて再試行してください。','autorepair-ai-hosting-beta')));
   }
   if(is_wp_error($r)||$code!==200)throw new RuntimeException((__('中央サーバーに反映できません。接続・認証を確認してください。送信待ちは保持します。','autorepair-ai-hosting-beta')));
   update_option('aaihb_central_suspended',false,false);
   $data=json_decode(wp_remote_retrieve_body($r),true);
   $mode=$data['mode']??'';$billable=$data['billable']??null;
   if(!is_array($data)||!(($mode==='live'&&$billable===true)||($mode==='test'&&$billable===false)))throw new RuntimeException((__('中央サーバーの課金状態を検証できません。','autorepair-ai-hosting-beta')));
   $usd=(($data['currency']??'')==='usd');
   $keys=$usd?['current','peak','included_sites','billable_sites','base_usd_cents','unit_usd_cents','estimate_usd_cents','stale_hubs','sequence']:['current','peak','base_yen','unit_yen','estimate_yen','stale_hubs','sequence'];
   foreach($keys as $k)if(!isset($data[$k])||!is_int($data[$k])||$data[$k]<0)throw new RuntimeException((__('集計データの形式が不正です。','autorepair-ai-hosting-beta')));
   if(!is_string($data['observed_at']??null)||strtotime($data['observed_at'])===false||$data['peak']<$data['current'])throw new RuntimeException((__('集計値を検証できません。','autorepair-ai-hosting-beta')));
   if($usd){
    if($data['billable_sites']!==max(0,$data['peak']-$data['included_sites'])||$data['estimate_usd_cents']!==$data['base_usd_cents']+$data['unit_usd_cents']*$data['billable_sites'])throw new RuntimeException((__('集計値を検証できません。','autorepair-ai-hosting-beta')));
   }elseif($data['estimate_yen']!==$data['base_yen']+$data['unit_yen']*max(0,$data['peak']-(int)($data['included_sites']??0)))throw new RuntimeException((__('集計値を検証できません。','autorepair-ai-hosting-beta')));
   if($batch&&$data['sequence']!==$batch[0]['sequence'])throw new RuntimeException((__('送信番号が一致しません。','autorepair-ai-hosting-beta')));
   if($batch){if(!add_option('aaihb_central_lock',time(),'',false))return;try{$q=get_option('aaihb_central_queue',[]);if($q&&$q[0]['sequence']===$batch[0]['sequence']){array_shift($q);update_option('aaihb_central_queue',$q,false);}}finally{delete_option('aaihb_central_lock');}}
   $s['result']=$data;$s['error']='';update_option(self::OPT,$s,false);
   if($q&&!wp_next_scheduled('aaihb_central_drain'))wp_schedule_single_event(time()+10,'aaihb_central_drain');
  }catch(Throwable $e){$s=self::settings();$s['error']=$e->getMessage();update_option(self::OPT,$s,false);}
  finally{delete_option('aaihb_central_send_lock');}
 }
 public static function save(){AAIHB_Beta::allowed();check_admin_referer('aaihb_central');
  try{
   $op=AAIHB_Beta::input('op');
   if($op==='configure'||$op==='replace'){
    if(!is_ssl())throw new RuntimeException((__('管理画面をHTTPSで開いてください。','autorepair-ai-hosting-beta')));
    // Already connected: switching to a new destination token is the same operation as the
    // first connection, so both paths only need the confirmation checkbox. The old split
    // ("configure" refused once connected) left the user looping on the green sync button
    // with a stale token and no way forward except the collapsed reconnect panel.
    if(self::configured()&&AAIHB_Beta::input('replace_confirm')!=='1')throw new RuntimeException((__('接続先を変更する確認にチェックしてください。','autorepair-ai-hosting-beta')));
    $url=self::url(AAIHB_Beta::input('url'));$token=AAIHB_Beta::input('token');if(!preg_match('/^[a-f0-9]{64}$/D',$token))throw new RuntimeException((__('中央サーバーで発行した64桁トークンを入力してください。','autorepair-ai-hosting-beta')));
    update_option(self::OPT,['url'=>$url,'token'=>AAIHB_Beta::crypt($token),'result'=>[],'error'=>''],false);
    update_option('aaihb_central_mirror',['url'=>$url,'token'=>AAIHB_Beta::crypt($token)],false);
   }
   if($op==='hub_revoke'){
    $hub=AAIHB_Beta::input('hub');
    if(!preg_match('/^[a-z0-9_-]{1,64}$/D',$hub))throw new RuntimeException((__('拠点IDを検証できません。','autorepair-ai-hosting-beta')));
    $s=self::settings();$token=AAIHB_Beta::crypt($s['token'],true);
    $r=wp_safe_remote_post($s['url'].'/v1/manage/hubs/revoke',['timeout'=>20,'redirection'=>0,'sslverify'=>true,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],'body'=>wp_json_encode(['hub'=>$hub])]);
    if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)throw new RuntimeException((__('拠点を失効できません。中央サーバーの状態を確認してください。','autorepair-ai-hosting-beta')));
   }
   if($op==='hub_issue'){
    $s=self::settings();$token=AAIHB_Beta::crypt($s['token'],true);
    $r=wp_safe_remote_post($s['url'].'/v1/manage/hubs',['timeout'=>20,'redirection'=>0,'sslverify'=>true,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],'body'=>'{}']);
    if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)throw new RuntimeException((__('拠点トークンを発行できません。中央サーバーの状態を確認してください。','autorepair-ai-hosting-beta')));
    $d=json_decode(wp_remote_retrieve_body($r),true);$hub=is_array($d)?($d['hub']??null):null;$tok=is_array($d)?($d['hub_token']??null):null;
    if(!is_string($hub)||!preg_match('/^[a-z0-9_-]{1,64}$/D',$hub)||!is_string($tok)||!preg_match('/^[a-f0-9]{64}$/D',$tok))throw new RuntimeException((__('発行された拠点トークンを検証できません。','autorepair-ai-hosting-beta')));
    update_option('aaihb_hub_issued',['hub'=>$hub,'token'=>$tok,'at'=>time()],false);
   }
   if($op==='hub_revoke'||$op==='hub_issue'){wp_safe_redirect(admin_url('admin.php?page=aaihb-license'));exit;}
   self::enqueue();self::sync();
  }catch(Throwable $e){$s=self::settings();$s['error']=$e->getMessage();update_option(self::OPT,$s,false);}
  wp_safe_redirect(admin_url('admin.php?page=aaihb-license'));exit;
 }
 public static function jst($iso){
  // Show hub times in the site's own time zone; the raw ISO 8601 value stays in the tooltip.
  if(!is_string($iso)||$iso==='')return '—';
  $t=strtotime($iso);
  if($t===false)return $iso;
  return get_date_from_gmt(gmdate('Y-m-d H:i:s',$t),'Y/m/d H:i');
 }
 public static function hubs(){
  if(!self::configured())return null;
  $s=self::settings();$token=AAIHB_Beta::crypt($s['token'],true);
  $r=wp_safe_remote_get($s['url'].'/v1/manage/hubs',['timeout'=>15,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>64000,'headers'=>['Authorization'=>'Bearer '.$token]]);
  if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)return null;
  $data=json_decode(wp_remote_retrieve_body($r),true);$hubs=is_array($data)?($data['hubs']??null):null;
  if(!is_array($hubs))return null;
  foreach($hubs as $h){if(!is_array($h)||!is_string($h['hub']??null)||!preg_match('/^[a-z0-9_-]{1,64}$/D',$h['hub'])||!is_int($h['sites']??null)||!is_bool($h['revoked']??null)||!is_bool($h['stale']??null))return null;}
  return $hubs;
 }
 /** 中央サーバーの試算を表示用に整形する。USD建てを主、円は参考として併記する。 */
 public static function yen_rate($d){return (float)($d['fx_rate_usd_jpy']??0);}
 public static function yen_base($d){if(($d['currency']??'')==='usd')return (int)round($d['base_usd_cents']*self::yen_rate($d)/100);return (int)$d['base_yen'];}
 public static function yen_unit($d){if(($d['currency']??'')==='usd')return (int)round($d['unit_usd_cents']*self::yen_rate($d)/100);return (int)$d['unit_yen'];}
 public static function yen_total($d){if(($d['currency']??'')==='usd')return self::yen_base($d)+self::yen_unit($d)*(int)$d['billable_sites'];return (int)$d['estimate_yen'];}
 public static function money($d){
  if(($d['currency']??'')==='usd')return '$'.number_format($d['estimate_usd_cents']/100,2);
  return number_format(self::yen_total($d)).(__(' 円','autorepair-ai-hosting-beta'));
 }
 public static function money_note($d){
  if(($d['currency']??'')==='usd'){
   $extra=(int)$d['billable_sites'];
   $line=sprintf(__('基本料金 $%1$s（%2$dサイトまで）','autorepair-ai-hosting-beta'),number_format($d['base_usd_cents']/100,2),(int)$d['included_sites']);
   $line.=$extra>0?sprintf(__(' ＋ 追加1サイトごと $%1$s × %2$dサイト','autorepair-ai-hosting-beta'),number_format($d['unit_usd_cents']/100,2),$extra):__('（追加サイトの課金なし）','autorepair-ai-hosting-beta');
   return $line.sprintf(__('／円換算 約%1$s 円（%2$s 円/USD）','autorepair-ai-hosting-beta'),number_format(self::yen_total($d)),$d['fx_rate_usd_jpy']);
  }
  return sprintf(__('基本料金 %1$s 円 ＋ 追加サイト数 × %2$s 円','autorepair-ai-hosting-beta'),number_format(self::yen_base($d)),number_format(self::yen_unit($d)));
 }
 public static function page(){AAIHB_Beta::allowed();nocache_headers();$s=self::settings();$r=$s['result'];$q=get_option('aaihb_central_queue',[]);
  echo ('<div class="wrap aaihb-app aaihb-selfserve"><header class="ss-hero"><small>ONE PLAN · USAGE</small><h1>'.esc_html__('使った分を、ひとつに。','autorepair-ai-hosting-beta').'</h1><p>'.esc_html__('固定枠をなくし、中央で管理サイト数を合算します。','autorepair-ai-hosting-beta').'</p></header>');AAIHB_Dashboard::nav('aaihb-license');
  $live=($r['mode']??'')==='live'&&($r['billable']??false)===true;
  echo '<section class="ss-result"><strong>'.($live?(__('本番の従量課金','autorepair-ai-hosting-beta')):(__('Stripeテスト接続','autorepair-ai-hosting-beta'))).'</strong><p>'.($live?(__('10サイトまで月額$29。11サイト目以降は1サイトにつき月額$3で、登録時に中央サーバーがStripeの利用量メーターへ報告します。','autorepair-ai-hosting-beta')):(__('本番課金は無効です。新しいサイトの登録は開始できません。','autorepair-ai-hosting-beta'))).('</p></section><div class="ss-grid"><section class="ss-card"><h2>'.esc_html__('中央で集計した利用数','autorepair-ai-hosting-beta').'</h2><p style="font-size:32px;font-weight:800">').($r?number_format($r['current']):'—').(esc_html__(' サイト','autorepair-ai-hosting-beta').'</p><p>'.esc_html__('追加課金対象：','autorepair-ai-hosting-beta')).($r?number_format($r['overage_sites']??0):'—').(esc_html__(' サイト','autorepair-ai-hosting-beta').'</p><p>'.esc_html__('この管理拠点の登録数：','autorepair-ai-hosting-beta')).AAIHB_Beta::sites_count().(__('／送信待ち：','autorepair-ai-hosting-beta')).count($q).(esc_html__(' 件','autorepair-ai-hosting-beta').'</p><p>'.esc_html__('最終観測：','autorepair-ai-hosting-beta')).esc_html(empty($r['observed_at'])?(__('未接続','autorepair-ai-hosting-beta')):self::jst($r['observed_at'])).('</p></section><section class="ss-card"><h2>'.esc_html__('契約料金','autorepair-ai-hosting-beta').'</h2><p style="font-size:32px;font-weight:800">').($r?self::money($r).(__(' / 月','autorepair-ai-hosting-beta')):(__('$29 / 月','autorepair-ai-hosting-beta'))).'</p><p>'.($r?(__('今月の試算：','autorepair-ai-hosting-beta')).self::money_note($r):(__('10サイト込み。11サイト目以降は1サイトにつき$3 / 月です。','autorepair-ai-hosting-beta'))).('</p><p>'.esc_html__('税・Stripe側の日割り計算・通貨換算はStripeの請求内容に従います。','autorepair-ai-hosting-beta').'</p></section></div>');
  if(get_option('aaihb_central_gap',false))echo ('<section class="ss-result">'.esc_html__('利用記録に欠落の可能性があります。運用者による照合が必要です。','autorepair-ai-hosting-beta').'</section>');
  if($s['error'])echo '<section class="ss-result" role="status">'.esc_html($s['error']).'</section>';
  if(get_option('aaihb_central_suspended',false))echo ('<section class="ss-result" role="status"><strong>'.esc_html__('中央サーバーが接続を拒否しています。下の「中央サーバーへ再接続する」を開き、新しい拠点トークンへ切り替えてください。','autorepair-ai-hosting-beta').'</strong></section>');
  if(!empty($r['stale_hubs']))echo ('<section class="ss-result">'.esc_html__('未同期の管理拠点があります。試算を請求に使用しないでください。','autorepair-ai-hosting-beta').'</section>');
  if(!empty($r['over_spending_cap']))echo ('<section class="ss-result">'.esc_html__('月額試算が支出上限(','autorepair-ai-hosting-beta')).number_format($r['spending_cap_yen']??0).(esc_html__(' 円)を超えています。利用は継続されます。','autorepair-ai-hosting-beta').'</section>');
  echo '<section class="ss-card"><h2>'.(self::configured()?(__('利用数を同期する','autorepair-ai-hosting-beta')):(__('中央サーバーに接続する','autorepair-ai-hosting-beta'))).'</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="aaihb_central">';wp_nonce_field('aaihb_central');
  if(!self::configured())echo ('<input type="hidden" name="op" value="configure"><p>'.esc_html__('中央サーバーを別途起動し、この拠点専用のトークンを発行してください。','autorepair-ai-hosting-beta').'</p><label>'.esc_html__('中央サーバーURL','autorepair-ai-hosting-beta').'<input type="url" name="url" required placeholder="https://usage.example.com"></label><label>'.esc_html__('拠点トークン','autorepair-ai-hosting-beta').'<input type="password" name="token" autocomplete="new-password" required></label>');
  else echo ('<input type="hidden" name="op" value="sync"><p>'.esc_html__('送信待ちを1件ずつ順番に反映します。自動処理はWP-Cronに依存します。','autorepair-ai-hosting-beta').'</p><details').(($s['error']||get_option('aaihb_central_suspended',false))?' open':'').('><summary>'.esc_html__('中央サーバーへ再接続する','autorepair-ai-hosting-beta').'</summary><p>'.esc_html__('別の拠点トークンへ切り替える場合だけ使用してください。切り替え後は、現在の登録サイト数を新しい拠点へ同期します。','autorepair-ai-hosting-beta').'</p><input type="hidden" name="replace_url" value=""><label>'.esc_html__('中央サーバーURL','autorepair-ai-hosting-beta').'<input type="url" name="url" value="').esc_attr($s['url']).('" placeholder="https://usage.example.com"></label><label>'.esc_html__('新しい拠点トークン','autorepair-ai-hosting-beta').'<input type="password" name="token" autocomplete="new-password"></label><label><input type="checkbox" name="replace_confirm" value="1">'.esc_html__(' 接続先を変更することを確認しました','autorepair-ai-hosting-beta').'</label><button class="button" type="submit" name="op" value="replace">'.esc_html__('再接続して同期する','autorepair-ai-hosting-beta').'</button></details>');
  submit_button((__('接続・同期を実行','autorepair-ai-hosting-beta')));echo '</form></section>';
 echo ('<section class="ss-card"><h2>'.esc_html__('管理拠点の一覧と失効','autorepair-ai-hosting-beta').'</h2>');
 if(self::configured()){
  $hubs=self::hubs();
  if($hubs===null)echo ('<p>'.esc_html__('拠点一覧を取得できませんでした。中央サーバーへの接続を確認してください。','autorepair-ai-hosting-beta').'</p>');
  elseif(!$hubs)echo ('<p>'.esc_html__('まだ拠点がありません。','autorepair-ai-hosting-beta').'</p>');
  else{
   echo ('<table class="widefat striped"><thead><tr><th>'.esc_html__('拠点ID','autorepair-ai-hosting-beta').'</th><th>'.esc_html__('登録サイト数','autorepair-ai-hosting-beta').'</th><th>'.esc_html__('最終同期','autorepair-ai-hosting-beta').'</th><th>'.esc_html__('状態','autorepair-ai-hosting-beta').'</th><th>'.esc_html__('操作','autorepair-ai-hosting-beta').'</th></tr></thead><tbody>');
   foreach($hubs as $h){
    $state=$h['revoked']?(__('失効済み','autorepair-ai-hosting-beta')):($h['stale']?(__('未同期（2時間以上）','autorepair-ai-hosting-beta')):(__('同期済み','autorepair-ai-hosting-beta')));
    echo '<tr><td><code>'.esc_html($h['hub']).'</code></td><td>'.number_format($h['sites']).'</td><td title="UTC '.esc_attr($h['updated']?:'').'">'.esc_html(self::jst($h['updated'])).'</td><td>'.esc_html($state).'</td><td>';
    if(!$h['revoked'])echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(\''.esc_js(sprintf(__('この拠点 %s を失効させます。よろしいですか？','autorepair-ai-hosting-beta'),$h['hub'])).'\');"><input type="hidden" name="action" value="aaihb_central"><input type="hidden" name="op" value="hub_revoke"><input type="hidden" name="hub" value="'.esc_attr($h['hub']).'">'.wp_nonce_field('aaihb_central','_wpnonce',true,false).('<button class="button" type="submit">'.esc_html__('失効させる','autorepair-ai-hosting-beta').'</button></form>');
    else echo '—';
    echo '</td></tr>';
   }
   echo ('</tbody></table><p>'.esc_html__('失効させた拠点は課金対象から外れ、その拠点からの同期は拒否されます。過去の観測値は書き換えません。','autorepair-ai-hosting-beta').'</p>');
  }
 }
 echo '</section>';
 echo ('<section class="ss-card"><h2>'.esc_html__('別ドメイン用の拠点トークンを発行','autorepair-ai-hosting-beta').'</h2><p>'.esc_html__('新しいWordPress（別ドメイン）を追加するときは、そのサイト専用のトークンをここで発行します。既存のトークンを使い回すと、登録の上書きや送信番号の衝突（409）の原因になります。','autorepair-ai-hosting-beta').'</p>');
 if(self::configured()){
  $issued=get_option('aaihb_hub_issued',[]);
  if(is_array($issued)&&isset($issued['hub'],$issued['token'])){
   echo ('<p><strong>'.esc_html__('このトークンは一度しか表示されません。必ず今コピーしてください。','autorepair-ai-hosting-beta').'</strong></p><p>'.esc_html__('拠点ID：','autorepair-ai-hosting-beta').'<code>').esc_html($issued['hub']).('</code></p><label>'.esc_html__('拠点トークン','autorepair-ai-hosting-beta').'<input type="text" readonly onfocus="this.select()" style="width:100%;max-width:640px;font-family:monospace" value="').esc_attr($issued['token']).'"></label>';
   delete_option('aaihb_hub_issued');
  }
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(\''.esc_js(__('新しい拠点トークンを発行します。よろしいですか？','autorepair-ai-hosting-beta')).'\');"><input type="hidden" name="action" value="aaihb_central"><input type="hidden" name="op" value="hub_issue">'.wp_nonce_field('aaihb_central','_wpnonce',true,false).('<button class="button button-primary" type="submit">'.esc_html__('新しい拠点トークンを発行','autorepair-ai-hosting-beta').'</button></form>');
 }
 echo '</section>';
 echo ('<section class="ss-card"><h2>'.esc_html__('この版での数え方','autorepair-ai-hosting-beta').'</h2><p>'.esc_html__('同じ顧客の複数拠点を合算します。同じ接続URLから作ったサイトIDは重複を除きます。停止中も登録に含め、接続解除が中央に届くまでは登録中です。月はUTCです。遅れて届いた記録は受信月に計上するため、通信遅延がある月は請求用に確定できません。','autorepair-ai-hosting-beta').'</p><p>'.esc_html__('従量プランに10・50・200件の区切りはありません。試作の送信上限は1拠点10万件で、性能保証ではありません。','autorepair-ai-hosting-beta').'</p></section></div>');
 }
}
